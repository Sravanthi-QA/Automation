<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>input_Sign in_idSIButton9</name>
   <tag></tag>
   <elementGuidId>c178ecea-aab5-4f8b-9aea-b3d219a0cded</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//input[@id='idSIButton9']</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#idSIButton9</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>input</value>
      <webElementGuid>f7482242-a272-46ad-b6d7-f72a34ad6ba3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>type</name>
      <type>Main</type>
      <value>submit</value>
      <webElementGuid>1734ff11-1778-4119-b265-49649a096d7f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>idSIButton9</value>
      <webElementGuid>46b325bf-a8f5-43bd-a279-969469afeb15</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>win-button button_primary button ext-button primary ext-primary</value>
      <webElementGuid>fccc5e5d-68d9-463d-831d-2ce6efba0a0b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-report-event</name>
      <type>Main</type>
      <value>Signin_Submit</value>
      <webElementGuid>c02c363c-ef74-4975-833e-7f5b84311cd7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-report-trigger</name>
      <type>Main</type>
      <value>click</value>
      <webElementGuid>b224c40c-0b2f-4d7e-a4c9-71aa2500f950</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-report-value</name>
      <type>Main</type>
      <value>Submit</value>
      <webElementGuid>288c933a-ecd1-493f-95bb-1ba69f366053</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-bind</name>
      <type>Main</type>
      <value>
                attr: primaryButtonAttributes,
                externalCss: {
                    'button': true,
                    'primary': true },
                value: primaryButtonText() || str['CT_PWD_STR_SignIn_Button_Next'],
                hasFocus: focusOnPrimaryButton,
                click: primaryButton_onClick,
                enable: isPrimaryButtonEnabled,
                visible: isPrimaryButtonVisible,
                preventTabbing: primaryButtonPreventTabbing</value>
      <webElementGuid>8e1ba38f-0b87-42e2-a4e2-2cf22f3e7dc3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>value</name>
      <type>Main</type>
      <value>Next</value>
      <webElementGuid>a9688860-3cdf-4886-aed9-59ff445f4399</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;idSIButton9&quot;)</value>
      <webElementGuid>55ad901a-a77d-47bb-b3bc-5c1d323dc3ef</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//input[@id='idSIButton9']</value>
      <webElementGuid>3bfcebbd-5cf5-4ea6-b069-70b6e5916ffe</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='lightbox']/div[3]/div/div/div/div[4]/div/div/div/div[2]/input</value>
      <webElementGuid>558527f1-493e-4a15-b81c-e6f98db2a180</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/input</value>
      <webElementGuid>6e6a3d13-ab60-417d-8ac7-6061c475488b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//input[@type = 'submit' and @id = 'idSIButton9']</value>
      <webElementGuid>21d801d0-c84b-40cf-aa1e-c7d95f46f884</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
