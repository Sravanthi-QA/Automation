<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>object_Combination</name>
   <tag></tag>
   <elementGuidId>4287fed2-3a28-4d4c-9bce-750fc7c98c12</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(//li//div//span[contains(text(),'Combination')])[1]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>span.mx-text.mx-name-text116</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>b56f15da-df22-4ce2-b9ab-754d603f870e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>mx-text mx-name-text116</value>
      <webElementGuid>2ffa6891-aa19-4ba0-916e-89a0bdf06cce</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
Combination: 1000 - 11 - 30</value>
      <webElementGuid>23d5b7e6-1c56-4536-b5e7-2309e4ac0cb5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;mxui_widget_DataView_175&quot;)/div[@class=&quot;mx-dataview-content&quot;]/span[@class=&quot;mx-text mx-name-text116&quot;]</value>
      <webElementGuid>cad71dce-4545-4527-826d-89616a482268</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='mxui_widget_DataView_175']/div/span</value>
      <webElementGuid>c9db45a3-e544-4055-bea8-f98aa3de3e6e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Customer Code exists in SAP with the Name - Albion Laboratories Ltd.'])[1]/following::span[1]</value>
      <webElementGuid>78be8c6a-4ed4-45c7-ac7a-9118648fd017</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Mapping Code'])[1]/following::span[3]</value>
      <webElementGuid>1012f1d3-cc97-45ea-b7d2-43c8741158a1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Combination: 1008 - 11 - 14'])[1]/preceding::span[1]</value>
      <webElementGuid>72ca16c6-7e8c-4b18-8487-8c61541a9a45</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Combination: 1000 - 11 - 30']/parent::*</value>
      <webElementGuid>c4830038-345e-462a-a6fd-5c39860415b4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li/div/div/span</value>
      <webElementGuid>4b30fbf3-4a14-479c-b33b-4a4dfe1b9bbb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = '
Combination: 1000 - 11 - 30' or . = '
Combination: 1000 - 11 - 30')]</value>
      <webElementGuid>8cbf780c-d941-4b72-b6e4-5a5960df68ea</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
