<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>dropdown_Please Select Condition Group 301-Oc_f3ff62</name>
   <tag></tag>
   <elementGuidId>e494d7bd-e208-4f8f-b6ce-488e1a001dfb</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#mxui_widget_ReferenceSelector_14 > select.form-control</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//span[contains(text(),'Condition Group 3')]//../following-sibling::div//select</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>select</value>
      <webElementGuid>1950b69f-8160-4c61-8bc0-21322e64dcbd</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>form-control</value>
      <webElementGuid>4ddaa4aa-74ab-4a22-ae82-df0c29636a5a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Please Select Condition Group 301-Octroi 1%02-Octroi 2%03-Octroi 2.5%04-Octroi 3%05-Oct Ahmedabad Grp06-Oct Baroda Grp07-Oct Bhavnagar Grp08-Oct Jamnagar Grp09-Oct Junagadh Grp10-Oct Rajkot Grp11-Oct Surat Grp12-Oct Nagpur Grp13-Oct Amravati Grp14-Oct Jalgaon Grp15-Oct Akola Grp16-Oct Kolhapur Grp17-Venz 5%Disc group18-Venz 5% Credit Group19-Inst Customers</value>
      <webElementGuid>86432735-7ff9-4640-8fe6-8a48c3c3fe3f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;mxui_widget_ReferenceSelector_14&quot;)/select[@class=&quot;form-control&quot;]</value>
      <webElementGuid>16871f81-6a5b-41ba-8092-1eee353bea8b</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='mxui_widget_ReferenceSelector_14']/select</value>
      <webElementGuid>41041910-052f-4d9b-a757-623f19329a0d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Condition Group 3'])[1]/following::select[1]</value>
      <webElementGuid>c9b18ae1-876b-46ff-9a14-79f09f4b1d1b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Attribute 10'])[1]/following::select[2]</value>
      <webElementGuid>9e3303e1-94cc-46d5-bf4e-9d91d75711f7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Condition Group 5'])[1]/preceding::select[1]</value>
      <webElementGuid>b8091e97-03d1-43d1-9c60-0cbb18605c0f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Recon account *'])[1]/preceding::select[2]</value>
      <webElementGuid>5b1904ae-d9fe-477a-8c15-3825b81abc37</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/div/div[2]/div/select</value>
      <webElementGuid>6aa18f7a-42dc-4c82-bdca-bb5b08f752d2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//select[(text() = 'Please Select Condition Group 301-Octroi 1%02-Octroi 2%03-Octroi 2.5%04-Octroi 3%05-Oct Ahmedabad Grp06-Oct Baroda Grp07-Oct Bhavnagar Grp08-Oct Jamnagar Grp09-Oct Junagadh Grp10-Oct Rajkot Grp11-Oct Surat Grp12-Oct Nagpur Grp13-Oct Amravati Grp14-Oct Jalgaon Grp15-Oct Akola Grp16-Oct Kolhapur Grp17-Venz 5%Disc group18-Venz 5% Credit Group19-Inst Customers' or . = 'Please Select Condition Group 301-Octroi 1%02-Octroi 2%03-Octroi 2.5%04-Octroi 3%05-Oct Ahmedabad Grp06-Oct Baroda Grp07-Oct Bhavnagar Grp08-Oct Jamnagar Grp09-Oct Junagadh Grp10-Oct Rajkot Grp11-Oct Surat Grp12-Oct Nagpur Grp13-Oct Amravati Grp14-Oct Jalgaon Grp15-Oct Akola Grp16-Oct Kolhapur Grp17-Venz 5%Disc group18-Venz 5% Credit Group19-Inst Customers')]</value>
      <webElementGuid>75a11282-a739-4ffd-83ab-d8dceb90bdf3</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
