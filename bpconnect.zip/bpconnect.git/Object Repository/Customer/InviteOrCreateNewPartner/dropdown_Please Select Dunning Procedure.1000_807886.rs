<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>dropdown_Please Select Dunning Procedure.1000_807886</name>
   <tag></tag>
   <elementGuidId>66f83b98-d1d9-48d2-ac19-2e07fb543baf</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#mxui_widget_ReferenceSelector_19 > select.form-control</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//span[contains(text(),'Dunning Procedure')]//../following-sibling::div//select</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>select</value>
      <webElementGuid>158378c8-1b2f-4591-bfc3-f54380a6a017</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>form-control</value>
      <webElementGuid>bad6322f-da78-4359-bb47-de86cc964e7c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Please Select Dunning Procedure.1000 - DRL Dunning Procedure for customers2000 - Dunning Procedure for NAG Customers3004 - Dunning Procedure for Reddy Holding GmbH3005 - Dunning Procedure for Betapharm Arzneimittel GmbH3007 - Dunning Procedure for Beta Institut gemeinnützige GmbH</value>
      <webElementGuid>991989be-8e6a-4e68-bd80-3bf0c6334286</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;mxui_widget_ReferenceSelector_19&quot;)/select[@class=&quot;form-control&quot;]</value>
      <webElementGuid>e330f2ab-f776-48ae-9b1a-4de75ad75ad4</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='mxui_widget_ReferenceSelector_19']/select</value>
      <webElementGuid>91e0dc1e-6e20-4b33-87cc-b9410e0b4545</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Dunning Procedure'])[1]/following::select[1]</value>
      <webElementGuid>dc65731d-d2ac-4eb8-a02d-4b49d516c80e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sales District'])[1]/following::select[2]</value>
      <webElementGuid>3f3a9e1f-a649-44f2-a502-29ebffce0ba8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Corporate Group'])[1]/preceding::select[1]</value>
      <webElementGuid>16c34f87-bc48-46b0-bf10-d6d60251caa8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Dunning Group'])[1]/preceding::select[2]</value>
      <webElementGuid>21f06c58-40ed-4470-8de7-06fafe50473b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/div[4]/div/div[2]/div/select</value>
      <webElementGuid>2e2d1c04-2066-4f96-84d4-92899fb7a8e5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//select[(text() = 'Please Select Dunning Procedure.1000 - DRL Dunning Procedure for customers2000 - Dunning Procedure for NAG Customers3004 - Dunning Procedure for Reddy Holding GmbH3005 - Dunning Procedure for Betapharm Arzneimittel GmbH3007 - Dunning Procedure for Beta Institut gemeinnützige GmbH' or . = 'Please Select Dunning Procedure.1000 - DRL Dunning Procedure for customers2000 - Dunning Procedure for NAG Customers3004 - Dunning Procedure for Reddy Holding GmbH3005 - Dunning Procedure for Betapharm Arzneimittel GmbH3007 - Dunning Procedure for Beta Institut gemeinnützige GmbH')]</value>
      <webElementGuid>09166d6e-4bbd-4739-ac90-decdd3da4b8c</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
