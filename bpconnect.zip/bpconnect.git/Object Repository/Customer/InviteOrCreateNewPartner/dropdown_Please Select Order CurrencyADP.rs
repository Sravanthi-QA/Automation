<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>dropdown_Please Select Order CurrencyADP</name>
   <tag></tag>
   <elementGuidId>c0d1ab49-ff18-4826-8174-5fce45f1608a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#mxui_widget_ReferenceSelector_17 > select.form-control</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//span[contains(text(),'Order Currency')]//../following-sibling::div//select</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>select</value>
      <webElementGuid>aa8583a2-cdf7-42bb-9beb-4bb7968454bb</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>form-control</value>
      <webElementGuid>c2b51bbe-adfb-4ec6-a7fc-88366c95af79</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Please Select Order CurrencyADP - Andoran pesetaAED - United Arab Emirates DirhamAFA - Afghani (Old)AFN - AfghaniALL - Albanian LekAMD - Armenian DramANG - West Indian GuilderAOA - Angolanische KwanzaAON - Angolan New Kwanza (Old)AOR - Angolan Kwanza Reajustado (Old)ARS - Argentine PesoATS - Austrian SchillingAUD - Australian DollarAWG - Aruban GuilderAZM - Azerbaijan ManatBAM - Bosnia and Herzegovina Convertible MarkBBD - Barbados DollarBDT - Bangladesh TakaBEF - Belgian FrancBGN - Bulgarian LevBHD - Bahrain DinarBIF - Burundi FrancBMD - Bermudan DollarBND - Brunei DollarBOB - BolivianoBRL - Brazilian RealBSD - Bahaman DollarBTN - Bhutan NgultrumBWP - Botswana PulaBYB - Belorussian Ruble (Old)BYR - Belorussian RubleBZD - Belize DollarCAD - Canadian DollarCDF - Congolese FrancCFP - French Franc (Pacific Islands)CHF - Swiss FrancCLP - Chilean PesoCNY - Chinesische Renminbi (national)CNY - Chinesische Yuan (international)COP - Colombian PesoCRC - Costa Rica ColonCSD - Serbian DinarCUP - Cuban PesoCVE - Cape Verde EscudoCYP - Cyprus PoundCZK - Czech KronaDEM3 - (Internal) German Mark (3 dec.places)DEM - German MarkDEM - (Internal) German Mark (3 dec.places)DEM - (Internal) German Mark (3 dec.places)DJF - Djibouti FrancDKK - Danish KroneDOP - Dominican PesoDZD - Algerian DinarECS - Ecuadorian Sucre (  > USD)EEK - Estonian KroneEGP - Egyptian PoundERN - Eritrean NafkaESP - Spanish PesetaETB - Ethiopian BirrEUR - European EuroEUR - European EuroEUR - European EuroEUR - Russian Condl Curr EuroFIM - Finnish markkaFJD - Fiji DollarFKP - Falkland PoundFRF - French FrancGBP - British PoundGEL - Georgian LariGHC - Ghanian CediGIP - Gibraltar PoundGMD - Gambian DalasiGNF - Guinean FrancGRD - Greek DrachmaGTQ - Guatemalan QuetzalGWP - Guinea PesoGYD - Guyana DollarHKD - Hong Kong DollarHNL - Honduran LempiraHRK - Croatian KunaHTG - Haitian GourdeHUF - Hungarian ForintIDR - Indonesian RupiahIEP - Irish PuntILS - Israeli ScheckelINR - Indian RupeeIQD - Iraqui DinarIRR - Iranian RialISK - Iceland KronaITL - Italian LiraJMD - Jamaican DollarJOD - Jordanian DinarJPY - Japanese YenKES - Kenyan ShillingKGS - Kyrgyzstan SomKHR - Cambodian RielKMF - Comoros FrancKPW - North Korean WonKRW - South Korean WonKWD - Kuwaiti DinarKYD - Cayman DollarKZT - Kazakstanian TengeLAK - Laotian KipLBP - Lebanese PoundLKR - Sri Lankan RupeeLRD - Liberian DollarLSL - Lesotho LotiLTL - Lithuanian LitaLUF - Luxembourg FrancLVL - Latvian LatLYD - Libyan DinarMAD - Moroccan DirhamMDL - Moldavian LeuMGA - Madagascan Ariary (New)MGF - Madagascan Franc (OldMKD - Macedonian DenarMMK - Myanmar KyatMNT - Mongolian TugrikMOP - Macao PatacaMRO - Mauritanian OuguiyaMTL - Maltese LiraMUR - Mauritian RupeeMVR - Maldive RufiyaaMWK - Malawi KwachaMXN - Mexican PesosMYR - Malaysian RinggitMZM - Mozambique MeticalNAD - Namibian DollarNGN - Nigerian NairaNIO - Nicaraguan Cordoba OroNLG - Dutch GuilderNOK - Norwegian KroneNPR - Nepalese RupeeNZD - New Zealand DollarsOMR - Omani RialPAB - Panamanian BalboaPEN - Peruvian New SolPGK - Papua New Guinea KinaPHP - Philippine PesoPKR - Pakistani RupeePLN - Polish Zloty (new)PTE - Portuguese EscudoPYG - Paraguayan GuaraniQAR - Qatar RialRMB - Chinesische Renminbi (national)ROL - Romanian LeuRON - New Romanian LeuRUB - Russian RubleRUE - Russian Condl Curr EuroRUU - Russian Cond Curr USDRWF - Rwandan FrancSAR - Saudi RiyalSBD - Solomon Islands DollarSCR - Seychelles RupeeSDD - Sudanese DinarSDP - Sudanese PoundSEK - Swedish KronaSGD - Singapore DollarSHP - St.Helena PoundSIT - Slovenian TolarSKK - Slovakian KronaSLL - Sierra Leone LeoneSOS - Somalian ShillingSRD - Surinam DollarSRG - Surinam Guilder (Old)STD - Sao Tome / Principe DobraSVC - El Salvador ColonSYP - Syrian PoundSZL - Swaziland LilangeniTHB - Thailand BahtTJR - Tajikistani Ruble (Old)TJS - Tajikistani SomoniTMM - Turkmenistani ManatTND - Tunisian DinarTOP - Tongan Pa'angaTPE - Timor EscudoTRL - Turkish Lira (Old)TRY - Turkish LiraTTD - Trinidad and Tobago DollarTWD - New Taiwan DollarTZS - Tanzanian ShillingUAH - Ukraine HryvniaUGX - Ugandan ShillingUSD - (Internal) United States Dollar (5 Dec.)USDN - (Internal) United States Dollar (5 Dec.)USD - Russian Cond Curr USDUSD - Russian Cond Curr USDUSD - United States DollarUSD - United States DollarUYU - Uruguayan Peso (new)UZS - Uzbekistan SomVEB - Venezuelan BolivarVEF - Venezuelan BolivarVES - Bolivar SoberanoVND - Vietnamese DongVUV - Vanuatu VatuWST - Samoan TalaXAF - Gabon CFA Franc BEACXCD - East Carribean DollarXDS - St. Christopher DollarXEU - European Currency Unit (E.C.U.)XOF - Benin CFA Franc BCEAOXPF - CFP FrancXPF - French Franc (Pacific Islands)YER - Yemeni RyalYUM - New Yugoslavian Dinar (Old)ZAR - South African RandZEUR - European EuroZMK - Zambian KwachaZRN - Zaire (Old)ZUSD - United States DollarZWD - Zimbabwean Dollar</value>
      <webElementGuid>09be1474-86ea-4868-a519-202158c1efbe</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;mxui_widget_ReferenceSelector_17&quot;)/select[@class=&quot;form-control&quot;]</value>
      <webElementGuid>4998df09-fb88-4a1a-98a9-ac82ad6bb4e8</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='mxui_widget_ReferenceSelector_17']/select</value>
      <webElementGuid>4c5d1888-1951-4c3a-9c66-5278a2165def</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Order Currency *'])[1]/following::select[1]</value>
      <webElementGuid>d72fa1c4-e0c9-4703-b618-cd6367cda477</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Credit Ctrl Area *'])[1]/following::select[2]</value>
      <webElementGuid>de5f6c5a-3041-4b99-ad98-6780a06e3a96</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sales District'])[1]/preceding::select[1]</value>
      <webElementGuid>c5e1f04e-dfec-44fe-92e8-8717ef43426c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Dunning Procedure'])[1]/preceding::select[2]</value>
      <webElementGuid>ffb56820-742e-4100-b2fe-e4b15a6ec360</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div[4]/div/div[2]/div/select</value>
      <webElementGuid>3b3f50cc-55ee-4baa-8094-78891f4746b1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//select[(text() = concat(&quot;Please Select Order CurrencyADP - Andoran pesetaAED - United Arab Emirates DirhamAFA - Afghani (Old)AFN - AfghaniALL - Albanian LekAMD - Armenian DramANG - West Indian GuilderAOA - Angolanische KwanzaAON - Angolan New Kwanza (Old)AOR - Angolan Kwanza Reajustado (Old)ARS - Argentine PesoATS - Austrian SchillingAUD - Australian DollarAWG - Aruban GuilderAZM - Azerbaijan ManatBAM - Bosnia and Herzegovina Convertible MarkBBD - Barbados DollarBDT - Bangladesh TakaBEF - Belgian FrancBGN - Bulgarian LevBHD - Bahrain DinarBIF - Burundi FrancBMD - Bermudan DollarBND - Brunei DollarBOB - BolivianoBRL - Brazilian RealBSD - Bahaman DollarBTN - Bhutan NgultrumBWP - Botswana PulaBYB - Belorussian Ruble (Old)BYR - Belorussian RubleBZD - Belize DollarCAD - Canadian DollarCDF - Congolese FrancCFP - French Franc (Pacific Islands)CHF - Swiss FrancCLP - Chilean PesoCNY - Chinesische Renminbi (national)CNY - Chinesische Yuan (international)COP - Colombian PesoCRC - Costa Rica ColonCSD - Serbian DinarCUP - Cuban PesoCVE - Cape Verde EscudoCYP - Cyprus PoundCZK - Czech KronaDEM3 - (Internal) German Mark (3 dec.places)DEM - German MarkDEM - (Internal) German Mark (3 dec.places)DEM - (Internal) German Mark (3 dec.places)DJF - Djibouti FrancDKK - Danish KroneDOP - Dominican PesoDZD - Algerian DinarECS - Ecuadorian Sucre (  > USD)EEK - Estonian KroneEGP - Egyptian PoundERN - Eritrean NafkaESP - Spanish PesetaETB - Ethiopian BirrEUR - European EuroEUR - European EuroEUR - European EuroEUR - Russian Condl Curr EuroFIM - Finnish markkaFJD - Fiji DollarFKP - Falkland PoundFRF - French FrancGBP - British PoundGEL - Georgian LariGHC - Ghanian CediGIP - Gibraltar PoundGMD - Gambian DalasiGNF - Guinean FrancGRD - Greek DrachmaGTQ - Guatemalan QuetzalGWP - Guinea PesoGYD - Guyana DollarHKD - Hong Kong DollarHNL - Honduran LempiraHRK - Croatian KunaHTG - Haitian GourdeHUF - Hungarian ForintIDR - Indonesian RupiahIEP - Irish PuntILS - Israeli ScheckelINR - Indian RupeeIQD - Iraqui DinarIRR - Iranian RialISK - Iceland KronaITL - Italian LiraJMD - Jamaican DollarJOD - Jordanian DinarJPY - Japanese YenKES - Kenyan ShillingKGS - Kyrgyzstan SomKHR - Cambodian RielKMF - Comoros FrancKPW - North Korean WonKRW - South Korean WonKWD - Kuwaiti DinarKYD - Cayman DollarKZT - Kazakstanian TengeLAK - Laotian KipLBP - Lebanese PoundLKR - Sri Lankan RupeeLRD - Liberian DollarLSL - Lesotho LotiLTL - Lithuanian LitaLUF - Luxembourg FrancLVL - Latvian LatLYD - Libyan DinarMAD - Moroccan DirhamMDL - Moldavian LeuMGA - Madagascan Ariary (New)MGF - Madagascan Franc (OldMKD - Macedonian DenarMMK - Myanmar KyatMNT - Mongolian TugrikMOP - Macao PatacaMRO - Mauritanian OuguiyaMTL - Maltese LiraMUR - Mauritian RupeeMVR - Maldive RufiyaaMWK - Malawi KwachaMXN - Mexican PesosMYR - Malaysian RinggitMZM - Mozambique MeticalNAD - Namibian DollarNGN - Nigerian NairaNIO - Nicaraguan Cordoba OroNLG - Dutch GuilderNOK - Norwegian KroneNPR - Nepalese RupeeNZD - New Zealand DollarsOMR - Omani RialPAB - Panamanian BalboaPEN - Peruvian New SolPGK - Papua New Guinea KinaPHP - Philippine PesoPKR - Pakistani RupeePLN - Polish Zloty (new)PTE - Portuguese EscudoPYG - Paraguayan GuaraniQAR - Qatar RialRMB - Chinesische Renminbi (national)ROL - Romanian LeuRON - New Romanian LeuRUB - Russian RubleRUE - Russian Condl Curr EuroRUU - Russian Cond Curr USDRWF - Rwandan FrancSAR - Saudi RiyalSBD - Solomon Islands DollarSCR - Seychelles RupeeSDD - Sudanese DinarSDP - Sudanese PoundSEK - Swedish KronaSGD - Singapore DollarSHP - St.Helena PoundSIT - Slovenian TolarSKK - Slovakian KronaSLL - Sierra Leone LeoneSOS - Somalian ShillingSRD - Surinam DollarSRG - Surinam Guilder (Old)STD - Sao Tome / Principe DobraSVC - El Salvador ColonSYP - Syrian PoundSZL - Swaziland LilangeniTHB - Thailand BahtTJR - Tajikistani Ruble (Old)TJS - Tajikistani SomoniTMM - Turkmenistani ManatTND - Tunisian DinarTOP - Tongan Pa&quot; , &quot;'&quot; , &quot;angaTPE - Timor EscudoTRL - Turkish Lira (Old)TRY - Turkish LiraTTD - Trinidad and Tobago DollarTWD - New Taiwan DollarTZS - Tanzanian ShillingUAH - Ukraine HryvniaUGX - Ugandan ShillingUSD - (Internal) United States Dollar (5 Dec.)USDN - (Internal) United States Dollar (5 Dec.)USD - Russian Cond Curr USDUSD - Russian Cond Curr USDUSD - United States DollarUSD - United States DollarUYU - Uruguayan Peso (new)UZS - Uzbekistan SomVEB - Venezuelan BolivarVEF - Venezuelan BolivarVES - Bolivar SoberanoVND - Vietnamese DongVUV - Vanuatu VatuWST - Samoan TalaXAF - Gabon CFA Franc BEACXCD - East Carribean DollarXDS - St. Christopher DollarXEU - European Currency Unit (E.C.U.)XOF - Benin CFA Franc BCEAOXPF - CFP FrancXPF - French Franc (Pacific Islands)YER - Yemeni RyalYUM - New Yugoslavian Dinar (Old)ZAR - South African RandZEUR - European EuroZMK - Zambian KwachaZRN - Zaire (Old)ZUSD - United States DollarZWD - Zimbabwean Dollar&quot;) or . = concat(&quot;Please Select Order CurrencyADP - Andoran pesetaAED - United Arab Emirates DirhamAFA - Afghani (Old)AFN - AfghaniALL - Albanian LekAMD - Armenian DramANG - West Indian GuilderAOA - Angolanische KwanzaAON - Angolan New Kwanza (Old)AOR - Angolan Kwanza Reajustado (Old)ARS - Argentine PesoATS - Austrian SchillingAUD - Australian DollarAWG - Aruban GuilderAZM - Azerbaijan ManatBAM - Bosnia and Herzegovina Convertible MarkBBD - Barbados DollarBDT - Bangladesh TakaBEF - Belgian FrancBGN - Bulgarian LevBHD - Bahrain DinarBIF - Burundi FrancBMD - Bermudan DollarBND - Brunei DollarBOB - BolivianoBRL - Brazilian RealBSD - Bahaman DollarBTN - Bhutan NgultrumBWP - Botswana PulaBYB - Belorussian Ruble (Old)BYR - Belorussian RubleBZD - Belize DollarCAD - Canadian DollarCDF - Congolese FrancCFP - French Franc (Pacific Islands)CHF - Swiss FrancCLP - Chilean PesoCNY - Chinesische Renminbi (national)CNY - Chinesische Yuan (international)COP - Colombian PesoCRC - Costa Rica ColonCSD - Serbian DinarCUP - Cuban PesoCVE - Cape Verde EscudoCYP - Cyprus PoundCZK - Czech KronaDEM3 - (Internal) German Mark (3 dec.places)DEM - German MarkDEM - (Internal) German Mark (3 dec.places)DEM - (Internal) German Mark (3 dec.places)DJF - Djibouti FrancDKK - Danish KroneDOP - Dominican PesoDZD - Algerian DinarECS - Ecuadorian Sucre (  > USD)EEK - Estonian KroneEGP - Egyptian PoundERN - Eritrean NafkaESP - Spanish PesetaETB - Ethiopian BirrEUR - European EuroEUR - European EuroEUR - European EuroEUR - Russian Condl Curr EuroFIM - Finnish markkaFJD - Fiji DollarFKP - Falkland PoundFRF - French FrancGBP - British PoundGEL - Georgian LariGHC - Ghanian CediGIP - Gibraltar PoundGMD - Gambian DalasiGNF - Guinean FrancGRD - Greek DrachmaGTQ - Guatemalan QuetzalGWP - Guinea PesoGYD - Guyana DollarHKD - Hong Kong DollarHNL - Honduran LempiraHRK - Croatian KunaHTG - Haitian GourdeHUF - Hungarian ForintIDR - Indonesian RupiahIEP - Irish PuntILS - Israeli ScheckelINR - Indian RupeeIQD - Iraqui DinarIRR - Iranian RialISK - Iceland KronaITL - Italian LiraJMD - Jamaican DollarJOD - Jordanian DinarJPY - Japanese YenKES - Kenyan ShillingKGS - Kyrgyzstan SomKHR - Cambodian RielKMF - Comoros FrancKPW - North Korean WonKRW - South Korean WonKWD - Kuwaiti DinarKYD - Cayman DollarKZT - Kazakstanian TengeLAK - Laotian KipLBP - Lebanese PoundLKR - Sri Lankan RupeeLRD - Liberian DollarLSL - Lesotho LotiLTL - Lithuanian LitaLUF - Luxembourg FrancLVL - Latvian LatLYD - Libyan DinarMAD - Moroccan DirhamMDL - Moldavian LeuMGA - Madagascan Ariary (New)MGF - Madagascan Franc (OldMKD - Macedonian DenarMMK - Myanmar KyatMNT - Mongolian TugrikMOP - Macao PatacaMRO - Mauritanian OuguiyaMTL - Maltese LiraMUR - Mauritian RupeeMVR - Maldive RufiyaaMWK - Malawi KwachaMXN - Mexican PesosMYR - Malaysian RinggitMZM - Mozambique MeticalNAD - Namibian DollarNGN - Nigerian NairaNIO - Nicaraguan Cordoba OroNLG - Dutch GuilderNOK - Norwegian KroneNPR - Nepalese RupeeNZD - New Zealand DollarsOMR - Omani RialPAB - Panamanian BalboaPEN - Peruvian New SolPGK - Papua New Guinea KinaPHP - Philippine PesoPKR - Pakistani RupeePLN - Polish Zloty (new)PTE - Portuguese EscudoPYG - Paraguayan GuaraniQAR - Qatar RialRMB - Chinesische Renminbi (national)ROL - Romanian LeuRON - New Romanian LeuRUB - Russian RubleRUE - Russian Condl Curr EuroRUU - Russian Cond Curr USDRWF - Rwandan FrancSAR - Saudi RiyalSBD - Solomon Islands DollarSCR - Seychelles RupeeSDD - Sudanese DinarSDP - Sudanese PoundSEK - Swedish KronaSGD - Singapore DollarSHP - St.Helena PoundSIT - Slovenian TolarSKK - Slovakian KronaSLL - Sierra Leone LeoneSOS - Somalian ShillingSRD - Surinam DollarSRG - Surinam Guilder (Old)STD - Sao Tome / Principe DobraSVC - El Salvador ColonSYP - Syrian PoundSZL - Swaziland LilangeniTHB - Thailand BahtTJR - Tajikistani Ruble (Old)TJS - Tajikistani SomoniTMM - Turkmenistani ManatTND - Tunisian DinarTOP - Tongan Pa&quot; , &quot;'&quot; , &quot;angaTPE - Timor EscudoTRL - Turkish Lira (Old)TRY - Turkish LiraTTD - Trinidad and Tobago DollarTWD - New Taiwan DollarTZS - Tanzanian ShillingUAH - Ukraine HryvniaUGX - Ugandan ShillingUSD - (Internal) United States Dollar (5 Dec.)USDN - (Internal) United States Dollar (5 Dec.)USD - Russian Cond Curr USDUSD - Russian Cond Curr USDUSD - United States DollarUSD - United States DollarUYU - Uruguayan Peso (new)UZS - Uzbekistan SomVEB - Venezuelan BolivarVEF - Venezuelan BolivarVES - Bolivar SoberanoVND - Vietnamese DongVUV - Vanuatu VatuWST - Samoan TalaXAF - Gabon CFA Franc BEACXCD - East Carribean DollarXDS - St. Christopher DollarXEU - European Currency Unit (E.C.U.)XOF - Benin CFA Franc BCEAOXPF - CFP FrancXPF - French Franc (Pacific Islands)YER - Yemeni RyalYUM - New Yugoslavian Dinar (Old)ZAR - South African RandZEUR - European EuroZMK - Zambian KwachaZRN - Zaire (Old)ZUSD - United States DollarZWD - Zimbabwean Dollar&quot;))]</value>
      <webElementGuid>1aabadec-088b-4c67-893d-695a3ba4f721</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
