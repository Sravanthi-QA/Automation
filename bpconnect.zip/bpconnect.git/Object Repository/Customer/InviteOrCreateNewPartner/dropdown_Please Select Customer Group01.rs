<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>dropdown_Please Select Customer Group01</name>
   <tag></tag>
   <elementGuidId>7f07c037-eba6-49a0-8fce-20231ee35b85</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#mxui_widget_ReferenceSelector_21 > select.form-control</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//span[contains(text(),'Customer Group')]//../following-sibling::div//select</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>select</value>
      <webElementGuid>b31d1363-8558-4011-b779-6d2c3b724be7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>form-control</value>
      <webElementGuid>5cd2a3e9-019d-47a0-9d5f-c28c387b224f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Please Select Customer Group01 - Industry02 - Retail05 - Stockist06 - Inst. Stockist07 - Institution08 - Doctors09 - Hosp &amp; Nursing Home10 - Company11 - Agent12 - Trader13 - Joint Venture14 - UK15 - EU16 - EU others17 - Shortline (DRUK)18 - Mainline (DRUK)20 - National Distributor21 - Reg Dist- W. Filials22 - Reg Dist-W/O Filials23 - Oncology Distributor24 - Hospitals25 - Plants26 - Sales Employee contr60 - Vistara Stockiest61 - Wokhardt Customer69 - PharmacyBenefits Mgr70 - Retail Pharmacy71 - Contracted Pharmacy72 - Clinics73 - Practitioner74 - Hospice75 - Veterinary76 - Federal Supply Schd77 - Fed Supply Schd OGA78 - Fed/City/Cty/State79 - Relabeler80 - Distributor-Direct81 - GPO - Non Hospital82 - Repackager90 - Distributor91 - RetailChain Pharmacy92 - Direct customers93 - Managed Care Org.94 - Mail Order Pharmacy95 - Wholesaler96 - Government/Tender97 - GPO - Hospitals98 - HMO99 - Health PlansA1 - HospitalA2 - Pharmacy Bnft. Mngr.A3 - Public Health SystemA4 - Retail Chain Non-WhsA5 - Staff Model HMOA6 - Long Term CareA7 - Managed Care Org DirA8 - DonationA9 - Vet GPOB0 - Vet DistributorB1 - Speciality PharmacyB2 - BrokerB3 - Buying GroupB4 - Home InfusionB5 - Home HealthCareCH - Corporate HospitalsCS - Common StockiestMC - MedicaidO1 - Oct : MilestoneO2 - Oct : TNMO3 - Oct : DownpaymentPR - PartnerS1 - Strata 1S2 - Strata 2S3 - Strata 3S4 - Other contractsS5 - Hospitals UKS6 - Contracts BeverleyV0 - Hospitals VenezuelaV1 - PRIVATE VenezuelaV2 - EMPLOYEES VenezuelaV3 - OTHER VenezuelaX0 - WholesalerX1 - HospitalX2 - ClinicX3 - Mail Order PharmacyX4 - Managed Care (HMO)X5 - Pharma Ben Mgr (PBM)X6 - FSS EntityX7 - 340B EntityX8 - ChainZ1 - Oct : Hours &amp; PriceZ2 - Oct : Invoice HoursZ3 - Oct :LumP Sum PaymenZ4 - Oct :Charge BackZ5 - Oct : Pre PaymentZ6 - Oct : External ServiZ7 - Oct : Storage HireZ8 - OTC StockistZ9 - GrandEra</value>
      <webElementGuid>d5d035fb-2763-4a38-a448-d1d6b74c35fb</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;mxui_widget_ReferenceSelector_21&quot;)/select[@class=&quot;form-control&quot;]</value>
      <webElementGuid>f4f43cf9-2bf8-4e73-a26c-0efe3349cf09</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='mxui_widget_ReferenceSelector_21']/select</value>
      <webElementGuid>9c68175b-ad37-4435-8539-05684841a67c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Customer Group'])[1]/following::select[1]</value>
      <webElementGuid>bffde167-57d0-4800-bcf2-0d9c5ad5cb3a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Authorization Group'])[1]/following::select[2]</value>
      <webElementGuid>4fa17eaa-3c7e-4083-84f1-7dc940965344</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Incoterms *'])[1]/preceding::select[1]</value>
      <webElementGuid>fa5a6ae1-fd42-4ede-8f06-22d2be1cdc08</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Incoterms Location1 *'])[1]/preceding::select[2]</value>
      <webElementGuid>615e75c1-b338-4691-9d88-d268cd388b7d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[4]/div[4]/div/div[2]/div/select</value>
      <webElementGuid>be955e60-7c1c-4eac-9993-2dbaa8452804</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//select[(text() = 'Please Select Customer Group01 - Industry02 - Retail05 - Stockist06 - Inst. Stockist07 - Institution08 - Doctors09 - Hosp &amp; Nursing Home10 - Company11 - Agent12 - Trader13 - Joint Venture14 - UK15 - EU16 - EU others17 - Shortline (DRUK)18 - Mainline (DRUK)20 - National Distributor21 - Reg Dist- W. Filials22 - Reg Dist-W/O Filials23 - Oncology Distributor24 - Hospitals25 - Plants26 - Sales Employee contr60 - Vistara Stockiest61 - Wokhardt Customer69 - PharmacyBenefits Mgr70 - Retail Pharmacy71 - Contracted Pharmacy72 - Clinics73 - Practitioner74 - Hospice75 - Veterinary76 - Federal Supply Schd77 - Fed Supply Schd OGA78 - Fed/City/Cty/State79 - Relabeler80 - Distributor-Direct81 - GPO - Non Hospital82 - Repackager90 - Distributor91 - RetailChain Pharmacy92 - Direct customers93 - Managed Care Org.94 - Mail Order Pharmacy95 - Wholesaler96 - Government/Tender97 - GPO - Hospitals98 - HMO99 - Health PlansA1 - HospitalA2 - Pharmacy Bnft. Mngr.A3 - Public Health SystemA4 - Retail Chain Non-WhsA5 - Staff Model HMOA6 - Long Term CareA7 - Managed Care Org DirA8 - DonationA9 - Vet GPOB0 - Vet DistributorB1 - Speciality PharmacyB2 - BrokerB3 - Buying GroupB4 - Home InfusionB5 - Home HealthCareCH - Corporate HospitalsCS - Common StockiestMC - MedicaidO1 - Oct : MilestoneO2 - Oct : TNMO3 - Oct : DownpaymentPR - PartnerS1 - Strata 1S2 - Strata 2S3 - Strata 3S4 - Other contractsS5 - Hospitals UKS6 - Contracts BeverleyV0 - Hospitals VenezuelaV1 - PRIVATE VenezuelaV2 - EMPLOYEES VenezuelaV3 - OTHER VenezuelaX0 - WholesalerX1 - HospitalX2 - ClinicX3 - Mail Order PharmacyX4 - Managed Care (HMO)X5 - Pharma Ben Mgr (PBM)X6 - FSS EntityX7 - 340B EntityX8 - ChainZ1 - Oct : Hours &amp; PriceZ2 - Oct : Invoice HoursZ3 - Oct :LumP Sum PaymenZ4 - Oct :Charge BackZ5 - Oct : Pre PaymentZ6 - Oct : External ServiZ7 - Oct : Storage HireZ8 - OTC StockistZ9 - GrandEra' or . = 'Please Select Customer Group01 - Industry02 - Retail05 - Stockist06 - Inst. Stockist07 - Institution08 - Doctors09 - Hosp &amp; Nursing Home10 - Company11 - Agent12 - Trader13 - Joint Venture14 - UK15 - EU16 - EU others17 - Shortline (DRUK)18 - Mainline (DRUK)20 - National Distributor21 - Reg Dist- W. Filials22 - Reg Dist-W/O Filials23 - Oncology Distributor24 - Hospitals25 - Plants26 - Sales Employee contr60 - Vistara Stockiest61 - Wokhardt Customer69 - PharmacyBenefits Mgr70 - Retail Pharmacy71 - Contracted Pharmacy72 - Clinics73 - Practitioner74 - Hospice75 - Veterinary76 - Federal Supply Schd77 - Fed Supply Schd OGA78 - Fed/City/Cty/State79 - Relabeler80 - Distributor-Direct81 - GPO - Non Hospital82 - Repackager90 - Distributor91 - RetailChain Pharmacy92 - Direct customers93 - Managed Care Org.94 - Mail Order Pharmacy95 - Wholesaler96 - Government/Tender97 - GPO - Hospitals98 - HMO99 - Health PlansA1 - HospitalA2 - Pharmacy Bnft. Mngr.A3 - Public Health SystemA4 - Retail Chain Non-WhsA5 - Staff Model HMOA6 - Long Term CareA7 - Managed Care Org DirA8 - DonationA9 - Vet GPOB0 - Vet DistributorB1 - Speciality PharmacyB2 - BrokerB3 - Buying GroupB4 - Home InfusionB5 - Home HealthCareCH - Corporate HospitalsCS - Common StockiestMC - MedicaidO1 - Oct : MilestoneO2 - Oct : TNMO3 - Oct : DownpaymentPR - PartnerS1 - Strata 1S2 - Strata 2S3 - Strata 3S4 - Other contractsS5 - Hospitals UKS6 - Contracts BeverleyV0 - Hospitals VenezuelaV1 - PRIVATE VenezuelaV2 - EMPLOYEES VenezuelaV3 - OTHER VenezuelaX0 - WholesalerX1 - HospitalX2 - ClinicX3 - Mail Order PharmacyX4 - Managed Care (HMO)X5 - Pharma Ben Mgr (PBM)X6 - FSS EntityX7 - 340B EntityX8 - ChainZ1 - Oct : Hours &amp; PriceZ2 - Oct : Invoice HoursZ3 - Oct :LumP Sum PaymenZ4 - Oct :Charge BackZ5 - Oct : Pre PaymentZ6 - Oct : External ServiZ7 - Oct : Storage HireZ8 - OTC StockistZ9 - GrandEra')]</value>
      <webElementGuid>fedcfd71-d413-4fee-81c9-b13cc370ba48</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
