<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>dropdown_Please Select Dunning Group</name>
   <tag></tag>
   <elementGuidId>7ae5da4b-2778-45c2-966c-c62e075bc1a5</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#mxui_widget_ReferenceSelector_20 > select.form-control</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//span[contains(text(),'Dunning Group')]//../following-sibling::div//select</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>select</value>
      <webElementGuid>0b5cb6d0-a316-4d42-b7a2-58ada9a0d408</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>form-control</value>
      <webElementGuid>5c6c6043-a704-4389-983b-d600d7c09490</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Please Select Dunning Group.01 - Contract number/contract type02 - Dunning process for Venezuela03 - Upcountry Customer04 - Local Customer</value>
      <webElementGuid>8389b7a6-1661-49dc-9adc-63e704b92cd3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;mxui_widget_ReferenceSelector_20&quot;)/select[@class=&quot;form-control&quot;]</value>
      <webElementGuid>5731e904-5270-4d8c-83b0-cb1b62c63fd2</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='mxui_widget_ReferenceSelector_20']/select</value>
      <webElementGuid>81ff2862-515f-4885-a0c8-fa702b5f1346</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Dunning Group'])[1]/following::select[1]</value>
      <webElementGuid>3f90ae00-02d7-4dd8-922a-28b15cd43d1c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Corporate Group'])[1]/following::select[2]</value>
      <webElementGuid>a44adf70-5528-4d52-bef5-364df655fd03</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Authorization Group'])[1]/preceding::select[1]</value>
      <webElementGuid>adf543e0-f9d5-4936-8dc4-303cdff439ba</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Customer Group'])[1]/preceding::select[2]</value>
      <webElementGuid>72311744-fd4d-4e0e-97d0-12b0f7107526</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[4]/div[2]/div/div[2]/div/select</value>
      <webElementGuid>9cea7a98-160f-40a0-a91e-c0d132878d3e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//select[(text() = 'Please Select Dunning Group.01 - Contract number/contract type02 - Dunning process for Venezuela03 - Upcountry Customer04 - Local Customer' or . = 'Please Select Dunning Group.01 - Contract number/contract type02 - Dunning process for Venezuela03 - Upcountry Customer04 - Local Customer')]</value>
      <webElementGuid>203ba0b6-477d-48ae-890b-d4793c1dce90</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
