<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>dropdown_Please Select Account Assg Group</name>
   <tag></tag>
   <elementGuidId>7b9edadf-30e0-43fc-b1d4-85002eaa19ad</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#mxui_widget_ReferenceSelector_16 > select.form-control</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//span[contains(text(),'Account Assg Group')]//../following-sibling::div//select</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>select</value>
      <webElementGuid>9c04c8b1-ea7c-4489-be6e-b32655b2fa5f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>form-control</value>
      <webElementGuid>68d55141-53ee-4b16-a03b-cf08698ce0f0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Please Select Account Assg Group01 - Domestic Revenues02 - Foreign Revenues03 - Affiliat Comp Revenu05 - Medicaid Customer06 - Deemed exports Rev.C1 - CM fee ZRA1 processPS - Physician Sam/SparshV1 - Direct RebateV2 - Indirect RebateV3 - Direct Admin FeeV4 - Direct Advrt FeV5 - Direct Sls ComV6 - Direct Growth PayoutV7 - Indirect Growth PayoV8 - Growth manualV9 - Ind to DirVF - Vistex: FTS processVH - D2,D4,D6,D9 directVI - Vistex: ZIOD processVP - Price protection</value>
      <webElementGuid>a679dc79-195e-4402-b1c6-31865566e3f6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;mxui_widget_ReferenceSelector_16&quot;)/select[@class=&quot;form-control&quot;]</value>
      <webElementGuid>b3a45a21-526b-4904-b9eb-17232a6f3326</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='mxui_widget_ReferenceSelector_16']/select</value>
      <webElementGuid>209a0554-35ce-4f28-9215-84c219e05fa7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Account Assg Group *'])[1]/following::select[1]</value>
      <webElementGuid>5d555749-20b6-4f1b-bc16-c2d8692b612e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Recon account *'])[1]/following::select[2]</value>
      <webElementGuid>51352f99-d95c-431d-ae86-eed92fdade05</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Credit Ctrl Area *'])[1]/preceding::select[1]</value>
      <webElementGuid>42096454-28ca-4d27-a17b-8727fbab1996</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Order Currency *'])[1]/preceding::select[2]</value>
      <webElementGuid>b1c33f77-49ec-4922-88b6-3c6528ab13c7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div[2]/div/div[2]/div/select</value>
      <webElementGuid>630d90e5-a574-4936-b5b1-1323bb99e4cc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//select[(text() = 'Please Select Account Assg Group01 - Domestic Revenues02 - Foreign Revenues03 - Affiliat Comp Revenu05 - Medicaid Customer06 - Deemed exports Rev.C1 - CM fee ZRA1 processPS - Physician Sam/SparshV1 - Direct RebateV2 - Indirect RebateV3 - Direct Admin FeeV4 - Direct Advrt FeV5 - Direct Sls ComV6 - Direct Growth PayoutV7 - Indirect Growth PayoV8 - Growth manualV9 - Ind to DirVF - Vistex: FTS processVH - D2,D4,D6,D9 directVI - Vistex: ZIOD processVP - Price protection' or . = 'Please Select Account Assg Group01 - Domestic Revenues02 - Foreign Revenues03 - Affiliat Comp Revenu05 - Medicaid Customer06 - Deemed exports Rev.C1 - CM fee ZRA1 processPS - Physician Sam/SparshV1 - Direct RebateV2 - Indirect RebateV3 - Direct Admin FeeV4 - Direct Advrt FeV5 - Direct Sls ComV6 - Direct Growth PayoutV7 - Indirect Growth PayoV8 - Growth manualV9 - Ind to DirVF - Vistex: FTS processVH - D2,D4,D6,D9 directVI - Vistex: ZIOD processVP - Price protection')]</value>
      <webElementGuid>9f7e0af2-6c1b-419f-8803-90c8c3d61cc5</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
