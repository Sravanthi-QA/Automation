<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>dropdown_Please Select Credit Ctrl Area0001 -_585511</name>
   <tag></tag>
   <elementGuidId>4cde5e2e-d1d9-4e20-8cb8-96254aef4676</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#mxui_widget_ReferenceSelector_24 > select.form-control</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//span[contains(text(),'Credit Ctrl Area')]//../following-sibling::div//select</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>select</value>
      <webElementGuid>4f6207e6-3236-45e1-ae99-2cf99afd152c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>form-control</value>
      <webElementGuid>fda7eba0-558d-4cb7-85d8-0155a96b57a6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Please Select Credit Ctrl Area0001 - Credit control area 0001Z001 - DRL - Credit control areaZ002 - DRL Russia-CCA-RUBZ003 - DRL - Ukraine - UAHZ004 - DRL - CCA- USDZ005 - Área de control de crédito VenezuelZ006 - APSL - Credit control area</value>
      <webElementGuid>5de34377-0eb3-49d2-98be-2d8d2134bd2d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;mxui_widget_ReferenceSelector_24&quot;)/select[@class=&quot;form-control&quot;]</value>
      <webElementGuid>b66fc5c1-ad4d-4f4e-8edd-fa0529134d5e</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='mxui_widget_ReferenceSelector_24']/select</value>
      <webElementGuid>5930be33-15ea-43a5-8501-192e991182c8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Credit Ctrl Area *'])[1]/following::select[1]</value>
      <webElementGuid>b48ce7a1-6a2e-4613-b5fc-1b685d8f4d57</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Account Assg Group *'])[1]/following::select[2]</value>
      <webElementGuid>66c7ac74-c726-44f6-b924-1063d8616141</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Order Currency *'])[1]/preceding::select[1]</value>
      <webElementGuid>b829705d-d958-4340-afb0-241253ad5ba4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sales District'])[1]/preceding::select[2]</value>
      <webElementGuid>fefa62cf-73d1-4dab-a92d-37a159a2d3a6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div[3]/div/div[2]/div/select</value>
      <webElementGuid>e4f2dace-f343-468c-a231-05deef0ddedf</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//select[(text() = 'Please Select Credit Ctrl Area0001 - Credit control area 0001Z001 - DRL - Credit control areaZ002 - DRL Russia-CCA-RUBZ003 - DRL - Ukraine - UAHZ004 - DRL - CCA- USDZ005 - Área de control de crédito VenezuelZ006 - APSL - Credit control area' or . = 'Please Select Credit Ctrl Area0001 - Credit control area 0001Z001 - DRL - Credit control areaZ002 - DRL Russia-CCA-RUBZ003 - DRL - Ukraine - UAHZ004 - DRL - CCA- USDZ005 - Área de control de crédito VenezuelZ006 - APSL - Credit control area')]</value>
      <webElementGuid>fd9d79f7-1f71-4e87-998e-9edd718e1b02</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
