<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>dropdown_Please select Sales Distrcit</name>
   <tag></tag>
   <elementGuidId>5e5cc7ec-4b24-475f-9629-41c2fc1f559f</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#mxui_widget_ReferenceSelector_18 > select.form-control</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//span[contains(text(),'Sales District')]//../following-sibling::div//select</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>select</value>
      <webElementGuid>dc1f2b2d-7cdc-4a10-b313-e2c08e3851ef</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>form-control</value>
      <webElementGuid>e31194f5-e451-4f11-8999-47f8ad318a39</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Please select Sales Distrcit -000001 - Northern region000002 - Southern region3010 - Europe3020 - ROW3030 - SEAMEA3031 - North Asia3032 - Asia Pacific (APAC)3040 - North America3050 - ROW-Regulated Mkts3060 - LATAM3070 - TMEA3080 - OthersB001 - Gebiet B001B002 - Krishna Kishore AdusB003 - Gebiet B003B004 - Gebiet B004B005 - Gebiet B005B006 - Gebiet B006B007 - Gebiet B007B008 - Gebiet B008B009 - Gebiet B009B010 - Gebiet B010B011 - Gebiet B011B012 - Gebiet B012B013 - Gebiet B013B014 - Gebiet B014B015 - Gebiet B015B016 - Gebiet B016B017 - Gebiet B017B018 - Gebiet B018B019 - Gebiet B019B020 - Gebiet B020CENTRE - Lower North IslandDRUS01 - DRL LabelDRUS02 - DRL Partnered LabelDRUSCA - DRUS-CanadaDRUSEU - DRUS-EuropeDRUSNA - DRUS-North AmericaDRUSOT - DRUS-OthersDRUSSA - DRUS-South AmericaDRUSSF - DRUS-South AfricaFTO - FTOGENRIC - GENERICSIPDO - IPDOMEXI - MexicoNORTH - Upper North IslandRPI01 - RPI LabelRPI02 - RPI Partnered LabelRU01 - Far EastRU02 - Moscow RegionRU03 - North-WestRU04 - SiberiaRU05 - Ural 1RU06 - Ural 2RU07 - Central Russia 1RU08 - Central Russia 2RU09 - Central Russia 3RU10 - SouthRU11 - South EastRU13 - West Siberia IIIRU14 - Moscow Region IRU15 - Moscow Region IIRU16 - South CentreSOUTH - South IslandURUGUA - UruguayV001 - COBECAV002 - DROGUERIASV002 - NENAV003 - DROLANCAV004 - FARMATODOV005 - FARVENCAV006 - FUNDAFARMACIAV007 - HOSPITALSV008 - LOCATELV009 - LOCATEL2V010 - LOCATEL3V011 - LOCATEL4V012 - LOCATEL5V013 - LOCATEL6V014 - LOCATEL7V015 - LOCATEL8V016 - LOCATEL9V017 - NENAV017 - RESCARVENV018 - OTROSV019 - PROMOTIONAL MATERIALV020 - DROGUERIAS</value>
      <webElementGuid>2064fb0a-494b-4001-9a46-7007a05e9387</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;mxui_widget_ReferenceSelector_18&quot;)/select[@class=&quot;form-control&quot;]</value>
      <webElementGuid>ad37802c-2aab-461b-9fcc-1b9dfa316d7e</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='mxui_widget_ReferenceSelector_18']/select</value>
      <webElementGuid>db07cb8a-d279-4aa1-a425-01af20c0c167</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sales District'])[1]/following::select[1]</value>
      <webElementGuid>54882af2-bdb9-480b-a8f0-b114180bff75</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Order Currency *'])[1]/following::select[2]</value>
      <webElementGuid>164177a9-381a-444e-9c92-7de1059b521e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Dunning Procedure'])[1]/preceding::select[1]</value>
      <webElementGuid>75109998-c62a-464b-9a6d-fb09985f814a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Corporate Group'])[1]/preceding::select[2]</value>
      <webElementGuid>e9834e2b-7423-4087-8bd6-e0adf5b8803a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[9]/div/div/div/div[2]/div[3]/div/div/div[2]/div/select</value>
      <webElementGuid>dccec460-2ebb-4d42-8186-ddfdf4448f84</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//select[(text() = 'Please select Sales Distrcit -000001 - Northern region000002 - Southern region3010 - Europe3020 - ROW3030 - SEAMEA3031 - North Asia3032 - Asia Pacific (APAC)3040 - North America3050 - ROW-Regulated Mkts3060 - LATAM3070 - TMEA3080 - OthersB001 - Gebiet B001B002 - Krishna Kishore AdusB003 - Gebiet B003B004 - Gebiet B004B005 - Gebiet B005B006 - Gebiet B006B007 - Gebiet B007B008 - Gebiet B008B009 - Gebiet B009B010 - Gebiet B010B011 - Gebiet B011B012 - Gebiet B012B013 - Gebiet B013B014 - Gebiet B014B015 - Gebiet B015B016 - Gebiet B016B017 - Gebiet B017B018 - Gebiet B018B019 - Gebiet B019B020 - Gebiet B020CENTRE - Lower North IslandDRUS01 - DRL LabelDRUS02 - DRL Partnered LabelDRUSCA - DRUS-CanadaDRUSEU - DRUS-EuropeDRUSNA - DRUS-North AmericaDRUSOT - DRUS-OthersDRUSSA - DRUS-South AmericaDRUSSF - DRUS-South AfricaFTO - FTOGENRIC - GENERICSIPDO - IPDOMEXI - MexicoNORTH - Upper North IslandRPI01 - RPI LabelRPI02 - RPI Partnered LabelRU01 - Far EastRU02 - Moscow RegionRU03 - North-WestRU04 - SiberiaRU05 - Ural 1RU06 - Ural 2RU07 - Central Russia 1RU08 - Central Russia 2RU09 - Central Russia 3RU10 - SouthRU11 - South EastRU13 - West Siberia IIIRU14 - Moscow Region IRU15 - Moscow Region IIRU16 - South CentreSOUTH - South IslandURUGUA - UruguayV001 - COBECAV002 - DROGUERIASV002 - NENAV003 - DROLANCAV004 - FARMATODOV005 - FARVENCAV006 - FUNDAFARMACIAV007 - HOSPITALSV008 - LOCATELV009 - LOCATEL2V010 - LOCATEL3V011 - LOCATEL4V012 - LOCATEL5V013 - LOCATEL6V014 - LOCATEL7V015 - LOCATEL8V016 - LOCATEL9V017 - NENAV017 - RESCARVENV018 - OTROSV019 - PROMOTIONAL MATERIALV020 - DROGUERIAS' or . = 'Please select Sales Distrcit -000001 - Northern region000002 - Southern region3010 - Europe3020 - ROW3030 - SEAMEA3031 - North Asia3032 - Asia Pacific (APAC)3040 - North America3050 - ROW-Regulated Mkts3060 - LATAM3070 - TMEA3080 - OthersB001 - Gebiet B001B002 - Krishna Kishore AdusB003 - Gebiet B003B004 - Gebiet B004B005 - Gebiet B005B006 - Gebiet B006B007 - Gebiet B007B008 - Gebiet B008B009 - Gebiet B009B010 - Gebiet B010B011 - Gebiet B011B012 - Gebiet B012B013 - Gebiet B013B014 - Gebiet B014B015 - Gebiet B015B016 - Gebiet B016B017 - Gebiet B017B018 - Gebiet B018B019 - Gebiet B019B020 - Gebiet B020CENTRE - Lower North IslandDRUS01 - DRL LabelDRUS02 - DRL Partnered LabelDRUSCA - DRUS-CanadaDRUSEU - DRUS-EuropeDRUSNA - DRUS-North AmericaDRUSOT - DRUS-OthersDRUSSA - DRUS-South AmericaDRUSSF - DRUS-South AfricaFTO - FTOGENRIC - GENERICSIPDO - IPDOMEXI - MexicoNORTH - Upper North IslandRPI01 - RPI LabelRPI02 - RPI Partnered LabelRU01 - Far EastRU02 - Moscow RegionRU03 - North-WestRU04 - SiberiaRU05 - Ural 1RU06 - Ural 2RU07 - Central Russia 1RU08 - Central Russia 2RU09 - Central Russia 3RU10 - SouthRU11 - South EastRU13 - West Siberia IIIRU14 - Moscow Region IRU15 - Moscow Region IIRU16 - South CentreSOUTH - South IslandURUGUA - UruguayV001 - COBECAV002 - DROGUERIASV002 - NENAV003 - DROLANCAV004 - FARMATODOV005 - FARVENCAV006 - FUNDAFARMACIAV007 - HOSPITALSV008 - LOCATELV009 - LOCATEL2V010 - LOCATEL3V011 - LOCATEL4V012 - LOCATEL5V013 - LOCATEL6V014 - LOCATEL7V015 - LOCATEL8V016 - LOCATEL9V017 - NENAV017 - RESCARVENV018 - OTROSV019 - PROMOTIONAL MATERIALV020 - DROGUERIAS')]</value>
      <webElementGuid>9a5b3419-9dd7-48fe-b55c-a80a541d696b</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
