<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>dropdown_Please Select Condition Group 501-Oc_56342b</name>
   <tag></tag>
   <elementGuidId>59bf4582-f19b-41ac-aff4-d3029cdc59c4</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#mxui_widget_ReferenceSelector_15 > select.form-control</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//span[contains(text(),'Condition Group 5')]//../following-sibling::div//select</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>select</value>
      <webElementGuid>2308c2bd-9133-4d85-96d5-de96c5d4ab9e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>form-control</value>
      <webElementGuid>99142e8a-5a67-49fc-8096-6b347edca097</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Please Select Condition Group 501-Octroi 1%02-Octroi 2%03-Octroi 2.5%04-Octroi 3%05-Oct Ahmedabad Grp06-Oct Baroda Grp07-Oct Bhavnagar Grp08-Oct Jamnagar Grp09-Oct Junagadh Grp10-Oct Rajkot Grp11-Oct Surat Grp12-Oct Nagpur Grp13-Oct Amravati Grp14-Oct Jalgaon Grp15-Oct Akola Grp16-Oct Kolhapur Grp17-Venz 5%Disc group18-Venz 5% Credit Group19-Inst Customers</value>
      <webElementGuid>8868634d-bbf5-429c-a369-ed856fd3915b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;mxui_widget_ReferenceSelector_15&quot;)/select[@class=&quot;form-control&quot;]</value>
      <webElementGuid>6bd3b27a-c983-4bb1-a285-1e2a645bd984</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='mxui_widget_ReferenceSelector_15']/select</value>
      <webElementGuid>93816436-a84c-452c-b289-9e7e62988fc9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Condition Group 5'])[1]/following::select[1]</value>
      <webElementGuid>5d343292-a3d0-446c-a038-0a381b72c3d2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Condition Group 3'])[1]/following::select[2]</value>
      <webElementGuid>7bac0490-c33e-406f-8a46-218b426de4db</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Recon account *'])[1]/preceding::select[1]</value>
      <webElementGuid>7d9eb35d-67ef-4c72-b5d1-30a94b120540</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Account Assg Group *'])[1]/preceding::select[2]</value>
      <webElementGuid>284b4703-65d1-4984-b823-20906a7c5f58</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[4]/div/div[2]/div/select</value>
      <webElementGuid>2ae6d40b-2a8a-4a88-9d35-f05bbde923ca</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//select[(text() = 'Please Select Condition Group 501-Octroi 1%02-Octroi 2%03-Octroi 2.5%04-Octroi 3%05-Oct Ahmedabad Grp06-Oct Baroda Grp07-Oct Bhavnagar Grp08-Oct Jamnagar Grp09-Oct Junagadh Grp10-Oct Rajkot Grp11-Oct Surat Grp12-Oct Nagpur Grp13-Oct Amravati Grp14-Oct Jalgaon Grp15-Oct Akola Grp16-Oct Kolhapur Grp17-Venz 5%Disc group18-Venz 5% Credit Group19-Inst Customers' or . = 'Please Select Condition Group 501-Octroi 1%02-Octroi 2%03-Octroi 2.5%04-Octroi 3%05-Oct Ahmedabad Grp06-Oct Baroda Grp07-Oct Bhavnagar Grp08-Oct Jamnagar Grp09-Oct Junagadh Grp10-Oct Rajkot Grp11-Oct Surat Grp12-Oct Nagpur Grp13-Oct Amravati Grp14-Oct Jalgaon Grp15-Oct Akola Grp16-Oct Kolhapur Grp17-Venz 5%Disc group18-Venz 5% Credit Group19-Inst Customers')]</value>
      <webElementGuid>b794cf48-fb11-40f2-96fd-464c67df8961</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
