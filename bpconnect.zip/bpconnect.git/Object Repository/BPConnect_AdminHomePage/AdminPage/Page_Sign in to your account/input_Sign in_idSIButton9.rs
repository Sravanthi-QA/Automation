<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>input_Sign in_idSIButton9</name>
   <tag></tag>
   <elementGuidId>e36b3188-1067-41b7-82ce-3e59ce33d7f2</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#idSIButton9</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//input[@id='idSIButton9']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>input</value>
      <webElementGuid>b6ade691-b48d-4ae1-8564-fe6e6454f286</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>type</name>
      <type>Main</type>
      <value>submit</value>
      <webElementGuid>74ce196a-f621-4f00-88bc-dcc527ac7fad</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>idSIButton9</value>
      <webElementGuid>363d511f-3cbf-4fde-8db8-246b6f548f8c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>win-button button_primary button ext-button primary ext-primary</value>
      <webElementGuid>36678d3e-c417-4daa-8f97-f329a15c4b17</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-report-event</name>
      <type>Main</type>
      <value>Signin_Submit</value>
      <webElementGuid>248b7c69-fc97-43a7-9748-84e9258045d1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-report-trigger</name>
      <type>Main</type>
      <value>click</value>
      <webElementGuid>7d6d5731-a42f-43b8-9755-a71c50f5ea7d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-report-value</name>
      <type>Main</type>
      <value>Submit</value>
      <webElementGuid>ee96964e-e7cd-4bf5-a2fe-3ca43e73e6d2</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-bind</name>
      <type>Main</type>
      <value>
                attr: primaryButtonAttributes,
                externalCss: {
                    'button': true,
                    'primary': true },
                value: primaryButtonText() || str['CT_PWD_STR_SignIn_Button_Next'],
                hasFocus: focusOnPrimaryButton,
                click: primaryButton_onClick,
                enable: isPrimaryButtonEnabled,
                visible: isPrimaryButtonVisible,
                preventTabbing: primaryButtonPreventTabbing</value>
      <webElementGuid>466a2396-ca9e-4c82-a9de-2027c1e64033</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>value</name>
      <type>Main</type>
      <value>Next</value>
      <webElementGuid>cce7f241-7674-4eff-9089-7b5189430b3b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;idSIButton9&quot;)</value>
      <webElementGuid>8c1904a8-86bf-4bc8-93fd-a0e92459a549</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//input[@id='idSIButton9']</value>
      <webElementGuid>50844eb6-93a7-416f-93ec-6d2bb91b1982</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='lightbox']/div[3]/div/div/div/div[4]/div/div/div/div[2]/input</value>
      <webElementGuid>c5b2d728-8967-4ca4-9e07-2d2f1874c013</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/input</value>
      <webElementGuid>b3410e94-9a6d-404d-8361-8daa031c710c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//input[@type = 'submit' and @id = 'idSIButton9']</value>
      <webElementGuid>eb8b0c21-ef99-4093-8567-0dbd2a4ecb00</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
