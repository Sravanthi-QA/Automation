<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Re enter IBAN number</description>
   <name>textField_ReEnterIBANNumber</name>
   <tag></tag>
   <elementGuidId>cec5bfa6-ec64-4bc2-877d-294d0ed80f35</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//label[text()='Re Enter IBAN Number']/following-sibling::input</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
