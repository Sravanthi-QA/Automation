<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Schema Group Please Select Schema Group_8d5c6d</name>
   <tag></tag>
   <elementGuidId>7d025253-60b5-4367-9a30-36ba7ff6f113</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.mx-name-container168.spacing-outer-right-medium</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//span[contains(text(),'Schema Group')]//..//..//select</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>d697ee5e-5980-4c91-867c-56623f0ef41d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>mx-name-container168 spacing-outer-right-medium</value>
      <webElementGuid>01840462-2962-47ca-98ba-489efb67e145</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Schema Group *Please Select Schema Group01 - Domestic  Vendor02 - Import Vendor03 - Overseas Schema VendorsIM - Import Vendor_OctoPlusIN - Domestic  Vendor_OctoPlus</value>
      <webElementGuid>c943dde6-d90e-4c03-9784-b4ce850e81e0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;114.BusinessPartnerRequest.InviteNewPartner.dataView1_114.BusinessPartnerRequest.InviteNewPartner.groupBox24_body&quot;)/div[@class=&quot;mx-name-container107 spacing-outer-left-medium spacing-outer-top&quot;]/div[@class=&quot;mx-layoutgrid mx-layoutgrid-fluid mx-name-layoutGrid19&quot;]/div[@class=&quot;row no-gutters&quot;]/div[@class=&quot;col-lg-3 col-md col&quot;]/div[@class=&quot;mx-name-container168 spacing-outer-right-medium&quot;]</value>
      <webElementGuid>6a793c44-bc5d-4f22-86b4-5e823da490f4</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='114.BusinessPartnerRequest.InviteNewPartner.dataView1_114.BusinessPartnerRequest.InviteNewPartner.groupBox24_body']/div/div/div[2]/div/div</value>
      <webElementGuid>283c8016-0281-44f1-ad00-46ce99c6ca6a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Recon Account *'])[1]/following::div[5]</value>
      <webElementGuid>d890413c-7767-4dd8-9103-0ada761975d0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Order Currency *'])[1]/following::div[10]</value>
      <webElementGuid>4bfefaa9-62dd-410d-b5cb-7593304124ae</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Authorization Group'])[1]/preceding::div[3]</value>
      <webElementGuid>26896818-d6af-4f6e-9ed0-247ddeaa717b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[7]/div/div/div/div/div[2]/div/div</value>
      <webElementGuid>c293d2d3-0d43-45a8-b464-76d83e79836d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'Schema Group *Please Select Schema Group01 - Domestic  Vendor02 - Import Vendor03 - Overseas Schema VendorsIM - Import Vendor_OctoPlusIN - Domestic  Vendor_OctoPlus' or . = 'Schema Group *Please Select Schema Group01 - Domestic  Vendor02 - Import Vendor03 - Overseas Schema VendorsIM - Import Vendor_OctoPlusIN - Domestic  Vendor_OctoPlus')]</value>
      <webElementGuid>5c63ebdd-07fd-41ba-8c98-4fb8b8dbff49</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
