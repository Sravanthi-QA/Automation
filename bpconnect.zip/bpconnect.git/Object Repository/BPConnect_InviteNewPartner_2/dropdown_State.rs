<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>dropdown_State</name>
   <tag></tag>
   <elementGuidId>54c0294a-bc55-4655-8bb7-3abf36a16fd1</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//span[contains(text(),'State')]//..//..//..//..//select | //span[text()='State/Region/Province/Country']//..//..//..//..//select | //span[contains(text(),'State/Region/Province')]//..//..//..//select</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#mxui_widget_ReferenceSelector_3 > select.form-control</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>select</value>
      <webElementGuid>ecb2c6c6-c878-4789-846f-8ce3c8cd6292</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>form-control</value>
      <webElementGuid>08ed6545-be44-4f66-99c6-a73e9ca0ca12</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Please Select StateAndaman &amp; Nicobar IsAndhra PradeshAndhra Pradesh SEZArunachal PradeshAssamBhutanBiharChandigarhChhattisgarhDadra und Nagar Hav.Daman and DiuDelhiGoaGujaratHaryanaHimachal PradeshJammu and KashmirJharkhandKarnatakaKeralaLakshadweep IslandsMadhya PradeshMaharashtraManipurMeghalayaMizoramNagalandNepalOdishaPondicherryPunjabRajasthanSikkimTamil NaduTelanganaTripuraUttarakhandUttar PradeshWest Bengal</value>
      <webElementGuid>14cb859f-c7eb-4af5-ba69-bd3cd2a77ee4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;mxui_widget_ReferenceSelector_3&quot;)/select[@class=&quot;form-control&quot;]</value>
      <webElementGuid>4e009a55-7a86-4613-a2fd-a2e684910b8c</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//span[contains(text(),'State')]//..//..//..//..//select | //span[text()='State/Region/Province/Country']//..//..//..//..//select | //span[contains(text(),'State/Region/Province')]//..//..//..//select</value>
      <webElementGuid>2fcfeb3d-4976-46fd-94c8-b3721032cf53</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//span[contains(text(),'State')]//..//..//..//..//select | //span[text()='State/Region/Province/Country']//..//..//..//..//select | //span[contains(text(),'State/Region/Province')]//..//..//..//select</value>
      <webElementGuid>b4c019c9-54f0-435a-8fad-1990d92d9527</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='State/Region/Province/Country'])[1]/following::select[1]</value>
      <webElementGuid>d2e20fac-960c-4474-86ac-dba79ca180cc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='City/Town *'])[1]/preceding::select[1]</value>
      <webElementGuid>b7ad730e-9b3b-4c86-98a4-d2919d88c3c3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Room'])[1]/preceding::select[1]</value>
      <webElementGuid>d45e045e-f3cc-4220-918f-ba45c2153886</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/div[2]/div/select</value>
      <webElementGuid>561b03f5-94b5-44b8-9bde-41216f2496dc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//select[(text() = 'Please Select StateAndaman &amp; Nicobar IsAndhra PradeshAndhra Pradesh SEZArunachal PradeshAssamBhutanBiharChandigarhChhattisgarhDadra und Nagar Hav.Daman and DiuDelhiGoaGujaratHaryanaHimachal PradeshJammu and KashmirJharkhandKarnatakaKeralaLakshadweep IslandsMadhya PradeshMaharashtraManipurMeghalayaMizoramNagalandNepalOdishaPondicherryPunjabRajasthanSikkimTamil NaduTelanganaTripuraUttarakhandUttar PradeshWest Bengal' or . = 'Please Select StateAndaman &amp; Nicobar IsAndhra PradeshAndhra Pradesh SEZArunachal PradeshAssamBhutanBiharChandigarhChhattisgarhDadra und Nagar Hav.Daman and DiuDelhiGoaGujaratHaryanaHimachal PradeshJammu and KashmirJharkhandKarnatakaKeralaLakshadweep IslandsMadhya PradeshMaharashtraManipurMeghalayaMizoramNagalandNepalOdishaPondicherryPunjabRajasthanSikkimTamil NaduTelanganaTripuraUttarakhandUttar PradeshWest Bengal')]</value>
      <webElementGuid>f9983756-5837-40e0-9544-746202b1787d</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
