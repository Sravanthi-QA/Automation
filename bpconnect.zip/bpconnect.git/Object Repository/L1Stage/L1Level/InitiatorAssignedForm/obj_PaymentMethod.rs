<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>obj_PaymentMethod</name>
   <tag></tag>
   <elementGuidId>817ed029-4ae8-49f0-a5d3-e0bcebe18f2d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.mx-name-container228.spacing-outer-right-medium > span.mx-text.mx-name-text2</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//span[text()='Payment Method']//../following-sibling::span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>6059098a-c8dc-4baf-9595-b3b93a562dbd</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>mx-text mx-name-text2</value>
      <webElementGuid>cd314979-e51e-4a07-a763-9562ba15e30d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>O - Office Delivery - Check</value>
      <webElementGuid>ffd3991f-f6a2-4552-8da1-1878d4ed3d22</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;142.BusinessPartnerRequest.Snip_PaymentDetails_RO_3CL.groupBox10_ghk_5461_body&quot;)/div[@class=&quot;mx-name-layoutGrid19 mx-layoutgrid mx-layoutgrid-fluid spacing-outer-left-medium spacing-outer-top&quot;]/div[@class=&quot;mx-name-layoutGrid19$row0 row no-gutters&quot;]/div[@class=&quot;mx-name-layoutGrid19$row0$column1 col-lg-4 col-md col&quot;]/div[@class=&quot;mx-name-container228 spacing-outer-right-medium&quot;]/span[@class=&quot;mx-text mx-name-text2&quot;]</value>
      <webElementGuid>924bfc6b-f36a-4505-b622-04b1290d567e</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='142.BusinessPartnerRequest.Snip_PaymentDetails_RO_3CL.groupBox10_ghk_5461_body']/div/div/div[2]/div/span</value>
      <webElementGuid>232414cb-1bcf-4865-8702-103dde23b81b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Payment Method'])[1]/following::span[1]</value>
      <webElementGuid>5e3184a7-548b-4d0d-9538-90ec00c90a39</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Payment Terms'])[1]/following::span[3]</value>
      <webElementGuid>b1e48eb7-b873-402a-8d36-ce2930a10ca0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Credit Memo Payment Method'])[1]/preceding::span[1]</value>
      <webElementGuid>af1b1572-f4fc-4c8b-9342-26f7a77f0c48</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Purchase Area'])[1]/preceding::span[3]</value>
      <webElementGuid>90e0364f-3ec4-49f9-80be-cd886c897a0b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='O - Office Delivery - Check']/parent::*</value>
      <webElementGuid>97c24fc7-d00c-471e-8f1f-af06bee46d57</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[6]/div/div/div/div[2]/div/span</value>
      <webElementGuid>e38340c6-cf23-4aff-a232-e4cb007997d9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'O - Office Delivery - Check' or . = 'O - Office Delivery - Check')]</value>
      <webElementGuid>eda278c3-1685-4695-bd24-7fd70680f38b</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
