<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>obj_Accountgroup</name>
   <tag></tag>
   <elementGuidId>8a4bb0f4-8cbb-4c1e-83ac-d822981a66c5</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.mx-name-container17.spacing-outer-bottom-medium.spacing-outer-right-medium > span.mx-text.mx-name-text6</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//span[text()='Account Group']//..//../following-sibling::span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>81ae0492-3bfd-4096-b00f-9e61c3874a3a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>mx-text mx-name-text6</value>
      <webElementGuid>1bac8d37-acf6-428c-8fbe-6877e2943433</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>2002 - Institutional Vendor</value>
      <webElementGuid>41fd4189-6c86-43aa-a9ff-da1e15847adf</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;142.BusinessPartnerRequest.Snip_SAPBusinessRegistrationForm_RO_3CL.groupBox1_ghk_5515_body&quot;)/div[@class=&quot;mx-name-container126 spacing-outer-left-medium&quot;]/div[@class=&quot;mx-name-layoutGrid1 mx-layoutgrid mx-layoutgrid-fluid&quot;]/div[@class=&quot;mx-name-layoutGrid1$row2 row no-gutters&quot;]/div[@class=&quot;mx-name-layoutGrid1$row2$column0 col-lg-4 col-md col&quot;]/div[@class=&quot;mx-name-container17 spacing-outer-bottom-medium spacing-outer-right-medium&quot;]/span[@class=&quot;mx-text mx-name-text6&quot;]</value>
      <webElementGuid>39304ebb-bc0c-4962-94db-3da7753374f6</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='142.BusinessPartnerRequest.Snip_SAPBusinessRegistrationForm_RO_3CL.groupBox1_ghk_5515_body']/div/div/div[3]/div/div/span</value>
      <webElementGuid>9f4753a6-8d08-4077-ae05-5283d043ad20</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Account Group'])[1]/following::span[1]</value>
      <webElementGuid>23d4e717-16b5-483e-99d5-c259584e810b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Import'])[1]/following::span[2]</value>
      <webElementGuid>b6a946af-85c1-460a-9e18-4119df794c76</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)=concat('Business Partner', &quot;'&quot;, 's Name')])[1]/preceding::span[1]</value>
      <webElementGuid>f630cbed-0f66-4894-941c-4de5a60cfa8d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Supplier Type'])[1]/preceding::span[3]</value>
      <webElementGuid>4694adfa-1f26-4ec6-a21f-41a83f6f2e3e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='2002 - Institutional Vendor']/parent::*</value>
      <webElementGuid>88af2968-efc7-4b82-aaab-b1e8395c04e4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/div/div/div/div[3]/div/div/span</value>
      <webElementGuid>4119227b-cfaa-43b3-9e5c-95c50fe4297a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = '2002 - Institutional Vendor' or . = '2002 - Institutional Vendor')]</value>
      <webElementGuid>e82733f7-00ea-4dbf-8e3a-d57344e66496</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
