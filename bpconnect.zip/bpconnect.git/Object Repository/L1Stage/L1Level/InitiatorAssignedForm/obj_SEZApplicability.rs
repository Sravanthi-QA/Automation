<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>obj_SEZApplicability</name>
   <tag></tag>
   <elementGuidId>43cfe78f-665e-4d15-b59f-e01ecd9a6317</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>span.mx-text.mx-name-text248.text-semibold</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//span[contains(text(),'SEZ Applicability')]//../following-sibling::span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>9716a8d1-a934-40d1-bf75-762b22605de7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>mx-text mx-name-text248 text-semibold</value>
      <webElementGuid>8255ccc0-7163-4efd-986a-33919eed2752</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>SEZ Applicability</value>
      <webElementGuid>c2ef8973-5991-47e3-b42f-57c343481d1d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;142.BusinessPartnerRequest.AssignedToL1.dataView2_142.BusinessPartnerRequest.Snip_SEZ_RO_3CL.groupBox15_body&quot;)/div[@class=&quot;mx-layoutgrid mx-layoutgrid-fluid mx-name-layoutGrid29 spacing-outer-left-medium&quot;]/div[@class=&quot;row no-gutters&quot;]/div[@class=&quot;col-lg-4 col-md col&quot;]/div[@class=&quot;mx-name-container449 spacing-outer-right-medium&quot;]/div[@class=&quot;mx-name-container450 spacing-outer-bottom&quot;]/span[@class=&quot;mx-text mx-name-text248 text-semibold&quot;]</value>
      <webElementGuid>320c1112-3bf2-4db7-91a7-2b20636920e1</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='142.BusinessPartnerRequest.AssignedToL1.dataView2_142.BusinessPartnerRequest.Snip_SEZ_RO_3CL.groupBox15_body']/div/div/div/div/div/span</value>
      <webElementGuid>e0a6d208-15f9-4cb3-bd7c-8a35104111d6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='SEZ Applicability'])[1]/following::span[1]</value>
      <webElementGuid>ee6aeca7-781d-4d64-ad1c-30dbd05599fc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Document Valid To *'])[1]/following::span[2]</value>
      <webElementGuid>60e04446-d053-4f4b-bb5f-8c26d9d5b9c8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='No'])[3]/preceding::span[1]</value>
      <webElementGuid>14e01356-3ba2-480c-9d0f-21fb69b3cdbd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Other Attachments'])[1]/preceding::span[2]</value>
      <webElementGuid>df91e870-f4e9-4104-88aa-b5b334254041</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[10]/div/div/div/div/div/div/div/span</value>
      <webElementGuid>714022c9-37fc-4065-a8d5-85982319aa73</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'SEZ Applicability' or . = 'SEZ Applicability')]</value>
      <webElementGuid>b592e75e-35e3-4d0e-b953-86247e8a0da7</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
