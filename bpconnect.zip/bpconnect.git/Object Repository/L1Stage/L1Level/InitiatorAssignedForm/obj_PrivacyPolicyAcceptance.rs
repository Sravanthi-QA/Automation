<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>obj_PrivacyPolicyAcceptance</name>
   <tag></tag>
   <elementGuidId>ef152ccd-1e7e-4178-ae27-0ea66d538d6d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.col-lg.col-md.col > div.mx-name-container500.spacing-outer-right-medium.spacing-outer-bottom-medium > div.mx-name-container503.spacing-outer-bottom > span.mx-text.mx-name-text223.text-semibold</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//span[contains(text(),'Privacy policy acceptance')]//../following-sibling::span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>94fe9ac1-7ca9-448c-9580-37e9e09a1496</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>mx-text mx-name-text223 text-semibold</value>
      <webElementGuid>ffbc8879-d299-497c-9b47-cee969060d35</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Privacy policy acceptance</value>
      <webElementGuid>a60bfc7a-92b7-462f-8c42-a3cc9908f357</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;142.BusinessPartnerRequest.AssignedToL1.dataView2_142.BusinessPartnerRequest.AssignedToL1.groupBox29_body&quot;)/div[@class=&quot;mx-layoutgrid mx-layoutgrid-fluid mx-name-layoutGrid13 spacing-outer-left-medium&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-lg col-md col&quot;]/div[@class=&quot;mx-name-container500 spacing-outer-right-medium spacing-outer-bottom-medium&quot;]/div[@class=&quot;mx-name-container503 spacing-outer-bottom&quot;]/span[@class=&quot;mx-text mx-name-text223 text-semibold&quot;]</value>
      <webElementGuid>358f34c4-b7dc-40e6-9ea0-f54da96415bd</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='142.BusinessPartnerRequest.AssignedToL1.dataView2_142.BusinessPartnerRequest.AssignedToL1.groupBox29_body']/div/div/div/div/div/span</value>
      <webElementGuid>e1aaee38-2c4d-4940-8665-3978e239422c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Data Consent Form - Attachment'])[1]/following::span[1]</value>
      <webElementGuid>57acff7e-74e2-40d1-acfa-df3f505df589</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='No'])[4]/following::span[1]</value>
      <webElementGuid>c393b29a-43a0-418e-8584-8b215449affd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Yes'])[2]/preceding::span[1]</value>
      <webElementGuid>f0820c50-d91a-4865-bdd7-242182648024</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Privacy policy acceptance']/parent::*</value>
      <webElementGuid>7b34cfb1-9bf4-4e20-809e-7d2f2b87ce61</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[13]/div/div/div/div/div/div/span</value>
      <webElementGuid>1e8bef3f-0cc4-4265-b795-a4d585a0465b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Privacy policy acceptance' or . = 'Privacy policy acceptance')]</value>
      <webElementGuid>e4979fc3-9ceb-4c27-956b-85b6c4b45b5e</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
