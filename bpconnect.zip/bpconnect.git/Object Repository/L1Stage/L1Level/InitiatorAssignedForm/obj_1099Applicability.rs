<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>obj_1099Applicability</name>
   <tag></tag>
   <elementGuidId>57334973-e456-4b20-a3e5-1fe4e536c9e4</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>span.mx-text.mx-name-text248.text-semibold</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//span[text()='1099 Applicability ?']//../following-sibling::span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>e73fc1f7-d733-45ea-ab1d-2c3ee39ab21e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>mx-text mx-name-text248 text-semibold</value>
      <webElementGuid>2cf382cc-4311-4e4a-99f6-c85c85eb766c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>1099 Applicability ?</value>
      <webElementGuid>3d17b64e-26b8-4fad-9cfc-e7fcf5cd90cd</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;142.BusinessPartnerRequest.Snip_1099_RO_3CL.groupBox15_ghk_5670_body&quot;)/div[@class=&quot;mx-name-layoutGrid29 mx-layoutgrid mx-layoutgrid-fluid spacing-outer-left-medium&quot;]/div[@class=&quot;mx-name-layoutGrid29$row0 row no-gutters&quot;]/div[@class=&quot;mx-name-layoutGrid29$row0$column0 col-lg-4 col-md col&quot;]/div[@class=&quot;mx-name-container449 spacing-outer-right-medium&quot;]/div[@class=&quot;mx-name-container450 spacing-outer-bottom&quot;]/span[@class=&quot;mx-text mx-name-text248 text-semibold&quot;]</value>
      <webElementGuid>f255d034-f465-4794-81bc-f1a8dd675dfd</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='142.BusinessPartnerRequest.Snip_1099_RO_3CL.groupBox15_ghk_5670_body']/div/div/div/div/div/span</value>
      <webElementGuid>edfd960e-f269-499f-978a-399d521612c5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='No'])[1]/following::span[1]</value>
      <webElementGuid>eca3bbc5-4ebf-45c1-9b90-c368623e6337</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Are you a U.S. license HCP or HCO ?'])[1]/following::span[2]</value>
      <webElementGuid>2bee6214-9a1e-40c9-bc1d-7704685a2e87</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='No'])[2]/preceding::span[1]</value>
      <webElementGuid>a8ef95bb-558c-4a07-8301-f108879567f2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Other Attachments'])[1]/preceding::span[2]</value>
      <webElementGuid>45232f7c-91f5-49bf-b526-59ed14b3b203</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[10]/div/div/div/div/div/div/div/span</value>
      <webElementGuid>6cdc268b-29fd-4ba8-adf2-48506185ed53</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = '1099 Applicability ?' or . = '1099 Applicability ?')]</value>
      <webElementGuid>b187cd0b-34c6-4324-9c68-db3032ff281e</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
