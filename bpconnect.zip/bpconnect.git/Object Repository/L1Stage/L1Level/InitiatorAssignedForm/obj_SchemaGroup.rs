<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>obj_SchemaGroup</name>
   <tag></tag>
   <elementGuidId>1ecff644-eec1-4bf1-88fa-1de2eb349331</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>span.mx-text.mx-name-text321</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//span[text()='Schema Group']//../following-sibling::span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>88b7ee4a-b158-41df-acd3-e86625ab42dd</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>mx-text mx-name-text321</value>
      <webElementGuid>6ffa1ccc-a302-4a2c-8bc4-c6d12cf8a65f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>01 - Domestic  Vendor</value>
      <webElementGuid>b1417a93-abf3-4f99-8fd6-578eae6b9ab6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;142.BusinessPartnerRequest.AssignedToL1.dataView2_142.BusinessPartnerRequest.Snip_PurchaseAreaSupplier_RO_3CL.groupBox11_body&quot;)/div[@class=&quot;mx-name-container46 spacing-outer-left-medium spacing-outer-top&quot;]/div[@class=&quot;mx-layoutgrid mx-layoutgrid-fluid mx-name-layoutGrid4&quot;]/div[@class=&quot;row no-gutters&quot;]/div[@class=&quot;col-lg-4 col-md col&quot;]/div[@class=&quot;mx-name-container111 spacing-outer-right-medium spacing-outer-bottom-medium&quot;]/span[@class=&quot;mx-text mx-name-text321&quot;]</value>
      <webElementGuid>bd6baf3d-d411-4645-8fde-43955d405619</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='142.BusinessPartnerRequest.AssignedToL1.dataView2_142.BusinessPartnerRequest.Snip_PurchaseAreaSupplier_RO_3CL.groupBox11_body']/div/div/div[3]/div/div/span</value>
      <webElementGuid>a1d5ab83-f62b-472c-87e9-fbcf3f3356d5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Schema Group'])[1]/following::span[1]</value>
      <webElementGuid>3ac2dcf5-3def-4574-8d41-6681a5abca5e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Recon Account'])[1]/following::span[3]</value>
      <webElementGuid>a6cc13f0-0f73-436c-bc50-b80155bcb2e4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Authorization Group'])[1]/preceding::span[1]</value>
      <webElementGuid>1686b8c4-802c-4056-9f62-50e8d9191fe4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='GENL - General'])[1]/preceding::span[2]</value>
      <webElementGuid>fd30b686-95cf-4adc-8828-b39c5b59f651</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[7]/div/div/div/div[3]/div/div/span</value>
      <webElementGuid>656c9412-7788-465e-93af-e55390e1cad5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = '01 - Domestic  Vendor' or . = '01 - Domestic  Vendor')]</value>
      <webElementGuid>23894193-74ba-4f5e-9e7d-b3021fe7cca0</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
