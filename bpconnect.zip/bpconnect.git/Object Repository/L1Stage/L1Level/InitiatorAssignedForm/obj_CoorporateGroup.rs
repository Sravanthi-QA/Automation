<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>obj_CoorporateGroup</name>
   <tag></tag>
   <elementGuidId>0ba93558-6112-4456-a40d-980a6422329e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>span.mx-text.mx-name-text316</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//span[text()='Corporate Group']//../following-sibling::span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>69ce296a-0fa6-47a8-a63d-c5ba6fb7d778</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>mx-text mx-name-text316</value>
      <webElementGuid>3d518abf-3187-428c-bf52-374f246b3038</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>G001 - General</value>
      <webElementGuid>e571eab2-8016-4053-8acc-3c40ad57f4aa</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;142.BusinessPartnerRequest.AssignedToL1.dataView2_142.BusinessPartnerRequest.Snip_PurchaseAreaSupplier_RO_3CL.groupBox11_body&quot;)/div[@class=&quot;mx-name-container46 spacing-outer-left-medium spacing-outer-top&quot;]/div[@class=&quot;mx-layoutgrid mx-layoutgrid-fluid mx-name-layoutGrid4&quot;]/div[@class=&quot;row no-gutters&quot;]/div[@class=&quot;col-lg-4 col-md col&quot;]/div[@class=&quot;mx-name-container698 spacing-outer-right-medium spacing-outer-bottom-medium&quot;]/span[@class=&quot;mx-text mx-name-text316&quot;]</value>
      <webElementGuid>65c38901-57dd-4872-9771-0ef75c5beed3</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='142.BusinessPartnerRequest.AssignedToL1.dataView2_142.BusinessPartnerRequest.Snip_PurchaseAreaSupplier_RO_3CL.groupBox11_body']/div/div/div[3]/div[3]/div/span</value>
      <webElementGuid>9ba7aed1-f6d1-4cb1-bfde-7139c75f4c37</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Corporate Group'])[1]/following::span[1]</value>
      <webElementGuid>e0808cbf-e740-4256-9cfc-5b29a27e0d7d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='GENL - General'])[1]/following::span[2]</value>
      <webElementGuid>b0bd1d64-b817-4401-8667-938e1b099583</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Incoterms'])[1]/preceding::span[1]</value>
      <webElementGuid>8dac0346-01aa-45bb-bc33-b4a9d67ba36f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='CF1 - CFR -AIR'])[1]/preceding::span[2]</value>
      <webElementGuid>0bff0de6-27b0-4001-aab2-f08f9f4ff673</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='G001 - General']/parent::*</value>
      <webElementGuid>3c68e5b0-bb87-45c9-a0d3-a0574c5f7c51</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[7]/div/div/div/div[3]/div[3]/div/span</value>
      <webElementGuid>5c0f7120-a679-4ac5-8c38-8172219ac3e2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'G001 - General' or . = 'G001 - General')]</value>
      <webElementGuid>e75132cf-b64d-4441-acc7-6c1028e023c0</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
