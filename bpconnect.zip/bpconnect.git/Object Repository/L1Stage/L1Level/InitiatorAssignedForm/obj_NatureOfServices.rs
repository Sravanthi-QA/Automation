<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>obj_NatureOfServices</name>
   <tag></tag>
   <elementGuidId>3a1b3512-c57e-4712-b4d2-8dcd9a605141</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>span.mx-text.mx-name-text15</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//span[contains(text(),'Nature of Service/Material')]//..//../following-sibling::span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>b2f8ae6b-8d72-40c9-923a-cf93c8e1458d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>mx-text mx-name-text15</value>
      <webElementGuid>616ec4d5-948f-4372-825a-e0d3525ac70d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>GOODS AND SERVICES</value>
      <webElementGuid>811c7849-013b-43fe-be62-79bd11c7caba</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;142.BusinessPartnerRequest.Snip_SAPBusinessRegistrationForm_RO_3CL.groupBox1_ghk_5515_body&quot;)/div[@class=&quot;mx-name-container126 spacing-outer-left-medium&quot;]/div[@class=&quot;mx-name-layoutGrid1 mx-layoutgrid mx-layoutgrid-fluid&quot;]/div[@class=&quot;mx-name-layoutGrid1$row4 row no-gutters&quot;]/div[@class=&quot;mx-name-layoutGrid1$row4$column1 col-lg-4 col-md col&quot;]/div[@class=&quot;mx-name-container15 spacing-outer-bottom-medium spacing-outer-right-medium&quot;]/span[@class=&quot;mx-text mx-name-text15&quot;]</value>
      <webElementGuid>eb4fd58c-115d-4ff6-a099-02001f546844</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='142.BusinessPartnerRequest.Snip_SAPBusinessRegistrationForm_RO_3CL.groupBox1_ghk_5515_body']/div/div/div[5]/div[2]/div/span</value>
      <webElementGuid>7ac2564d-b08b-4fee-b68a-1de76c39ffc0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Nature of Service/Material'])[1]/following::span[1]</value>
      <webElementGuid>1f25afdb-345d-4365-9d88-382aa00567db</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Both'])[1]/following::span[2]</value>
      <webElementGuid>504d7413-2a54-41ef-8bae-38b32becdad5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Brief Description of Services'])[1]/preceding::span[1]</value>
      <webElementGuid>0006d4f4-d915-4a0b-93a8-ed1267f17662</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='test'])[1]/preceding::span[2]</value>
      <webElementGuid>43c39365-bab8-4191-8ab3-037a3326ba34</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='GOODS AND SERVICES']/parent::*</value>
      <webElementGuid>e58722b7-b170-4d4c-a81e-7d3ffcf0489f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[5]/div[2]/div/span</value>
      <webElementGuid>bf4e3097-b94d-4256-b761-93f4fcee4dca</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'GOODS AND SERVICES' or . = 'GOODS AND SERVICES')]</value>
      <webElementGuid>87cf04f4-d99e-470f-9124-23cc0446c139</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
