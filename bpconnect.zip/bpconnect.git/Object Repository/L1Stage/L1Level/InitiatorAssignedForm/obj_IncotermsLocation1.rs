<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>obj_IncotermsLocation1</name>
   <tag></tag>
   <elementGuidId>e6beff35-672e-4d53-b452-d4aee5b9f959</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>span.mx-text.mx-name-text161.text-semibold</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//span[text()='Incoterms Location1']//../following-sibling::span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>96fa4f72-0e7f-40eb-be2f-959496bfecf8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>mx-text mx-name-text161 text-semibold</value>
      <webElementGuid>4e3b776a-c53f-408e-9603-ff8b4d454201</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Incoterms Location1</value>
      <webElementGuid>2171d666-cc76-4603-b5fd-424a5eeb2372</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;142.BusinessPartnerRequest.AssignedToL1.dataView2_142.BusinessPartnerRequest.Snip_PurchaseAreaSupplier_RO_3CL.groupBox11_body&quot;)/div[@class=&quot;mx-name-container46 spacing-outer-left-medium spacing-outer-top&quot;]/div[@class=&quot;mx-layoutgrid mx-layoutgrid-fluid mx-name-layoutGrid4&quot;]/div[@class=&quot;row no-gutters&quot;]/div[@class=&quot;col-lg-4 col-md col&quot;]/div[@class=&quot;mx-name-container254 spacing-outer-right-medium spacing-outer-bottom-medium&quot;]/div[@class=&quot;mx-name-container255 spacing-outer-bottom&quot;]/span[@class=&quot;mx-text mx-name-text161 text-semibold&quot;]</value>
      <webElementGuid>b7926811-9ddc-4960-98d8-3a9f31ca7ea1</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='142.BusinessPartnerRequest.AssignedToL1.dataView2_142.BusinessPartnerRequest.Snip_PurchaseAreaSupplier_RO_3CL.groupBox11_body']/div/div/div[4]/div[2]/div/div/span</value>
      <webElementGuid>c9e9a0f5-e705-4dda-96d4-8666e4ce52d0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='CF1 - CFR -AIR'])[1]/following::span[1]</value>
      <webElementGuid>2feb96f0-aebb-4094-9ae2-e171bb5429fa</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Incoterms'])[1]/following::span[2]</value>
      <webElementGuid>934d7fd7-94f3-4e67-8c0e-df35f02ca0bd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='test'])[9]/preceding::span[1]</value>
      <webElementGuid>30b4bd23-32c3-421c-b56d-21332d73b910</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Minority Indicator'])[1]/preceding::span[2]</value>
      <webElementGuid>f99c45d8-a97a-4027-8adb-7faa4740fb3f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Incoterms Location1']/parent::*</value>
      <webElementGuid>4318ada9-f1b9-48df-bbc0-a4c658f3c18f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[7]/div/div/div/div[4]/div[2]/div/div/span</value>
      <webElementGuid>ab0f47f5-f32f-4ae0-9756-cbdcca88b92e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Incoterms Location1' or . = 'Incoterms Location1')]</value>
      <webElementGuid>96fa2739-cb22-4158-a5de-d7f9deaa4c31</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
