<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>obj_CompanyName</name>
   <tag></tag>
   <elementGuidId>2d23dfcf-9250-4e68-ab95-baace5326f40</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>span.mx-text.mx-name-text95.text-semibold</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//span[contains(text(),'Company Name')]//..//../following-sibling::span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>216c51df-a46f-4ffd-ab0d-9fc6ad7e82e9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>mx-text mx-name-text95 text-semibold</value>
      <webElementGuid>e98068bc-330d-4371-b0b3-edcb4969d945</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Company Name</value>
      <webElementGuid>c0500bec-a4ed-4344-8625-57a5d0e9b005</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;142.BusinessPartnerRequest.Snip_Address_RO_3CL.groupBox4_ghk_5454_body&quot;)/div[@class=&quot;mx-name-container154 spacing-outer-left-medium spacing-outer-top&quot;]/div[@class=&quot;mx-name-layoutGrid1 mx-layoutgrid mx-layoutgrid-fluid&quot;]/div[@class=&quot;mx-name-layoutGrid1$row1 row no-gutters&quot;]/div[@class=&quot;mx-name-layoutGrid1$row1$column0 col-lg-4 col-md col&quot;]/div[@class=&quot;mx-name-container275 spacing-outer-bottom-medium spacing-outer-right-medium&quot;]/div[@class=&quot;mx-name-container276 spacing-outer-bottom&quot;]/span[@class=&quot;mx-text mx-name-text95 text-semibold&quot;]</value>
      <webElementGuid>3217bbec-4267-4e48-89b2-aa0c4cea8ae1</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='142.BusinessPartnerRequest.Snip_Address_RO_3CL.groupBox4_ghk_5454_body']/div/div/div[2]/div/div/div/span</value>
      <webElementGuid>d6b9f038-7d3b-40e6-b5fd-b3d1658dfb1f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Title'])[1]/following::span[2]</value>
      <webElementGuid>f54f7533-d6d2-4b20-80f8-cea4a7a0d22a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Address'])[1]/following::span[3]</value>
      <webElementGuid>e2b837b3-6c3d-4a9b-b31f-2ed053053e88</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='test'])[2]/preceding::span[1]</value>
      <webElementGuid>3ab4418b-2f38-460c-a7d4-365140dfad63</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Name 2'])[1]/preceding::span[2]</value>
      <webElementGuid>9a631754-8a9e-47da-add3-da872b4b5858</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Company Name']/parent::*</value>
      <webElementGuid>65fe34c0-180f-42a8-b6f7-3c264b2a4b59</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div[2]/div/div/div/div[2]/div/div/div/span</value>
      <webElementGuid>993e7dd3-be76-465a-89f9-e9da6c19a2e6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Company Name' or . = 'Company Name')]</value>
      <webElementGuid>b3117002-3456-49e9-aea5-a7718a951ef2</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
