<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>obj_DocumentValidFrom</name>
   <tag></tag>
   <elementGuidId>3aaf6102-c83e-4007-849a-dd37b0ce2d5a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>span.mx-text.mx-name-text117.text-semibold</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//span[contains(text(),'Document Valid From')]//../following-sibling::span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>a4d338f8-d2e8-4e6a-890e-5aca9154d282</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>mx-text mx-name-text117 text-semibold</value>
      <webElementGuid>c78daf38-94c2-4b7a-9026-dac1ed30bf29</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Document Valid From *</value>
      <webElementGuid>15ed7aa7-83d4-47d6-a07a-2cfc56d33083</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;142.BusinessPartnerRequest.AssignedToL1.dataView2_142.BusinessPartnerRequest.Snip_SEPComp_RO_3CL.groupBox27_body&quot;)/div[@class=&quot;mx-layoutgrid mx-layoutgrid-fluid mx-name-layoutGrid40 spacing-outer-left-medium&quot;]/div[@class=&quot;row no-gutters&quot;]/div[@class=&quot;col-lg-4 col-md col&quot;]/div[@class=&quot;mx-name-container275 spacing-outer-bottom-medium spacing-outer-right-medium&quot;]/div[@class=&quot;mx-name-container276 spacing-outer-bottom&quot;]/span[@class=&quot;mx-text mx-name-text117 text-semibold&quot;]</value>
      <webElementGuid>1c3c5a64-1e82-42ee-9752-38974ef92550</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='142.BusinessPartnerRequest.AssignedToL1.dataView2_142.BusinessPartnerRequest.Snip_SEPComp_RO_3CL.groupBox27_body']/div/div[2]/div[2]/div/div/span</value>
      <webElementGuid>fcc8287f-f256-4315-a28c-dd2e5c999499</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='TDSU/S194Q'])[1]/following::span[1]</value>
      <webElementGuid>7e1b71bc-365e-4e45-8bfc-0a57dce21989</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Exemption Number'])[1]/following::span[2]</value>
      <webElementGuid>ddd9809b-ce5d-4a08-9960-e958981c6b0e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Document Valid To *'])[1]/preceding::span[2]</value>
      <webElementGuid>41122cb8-22fe-4fb8-a37a-f207e35b50d3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='SEZ Applicability'])[1]/preceding::span[4]</value>
      <webElementGuid>70d4a06c-cc1b-4553-abcd-9d33ec8ec6e0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Document Valid From *']/parent::*</value>
      <webElementGuid>168cea18-7060-41c4-8625-af6b050c3bd3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[9]/div/div/div/div[2]/div[2]/div/div/span</value>
      <webElementGuid>eabc700d-17ea-43c0-8c0e-f729eb516c93</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Document Valid From *' or . = 'Document Valid From *')]</value>
      <webElementGuid>30cd862f-ce59-4859-959a-bd33343ba54d</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
