<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>obj_OrderCurrency</name>
   <tag></tag>
   <elementGuidId>c714ce92-a40c-45d0-9fe5-8018337428ea</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>span.mx-text.mx-name-text319</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//span[text()='Order Currency']//../following-sibling::span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>13565592-35a7-4b49-ae8f-d4bdf6a7cc6f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>mx-text mx-name-text319</value>
      <webElementGuid>36902426-06c4-4ed7-9a25-bab989e6d608</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>USD - (Internal) United States Dollar (5 Dec.)</value>
      <webElementGuid>a0cf9c8b-d9fe-4007-9950-1583075d0ad0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;142.BusinessPartnerRequest.AssignedToL1.dataView2_142.BusinessPartnerRequest.Snip_PurchaseAreaSupplier_RO_3CL.groupBox11_body&quot;)/div[@class=&quot;mx-name-container46 spacing-outer-left-medium spacing-outer-top&quot;]/div[@class=&quot;mx-layoutgrid mx-layoutgrid-fluid mx-name-layoutGrid4&quot;]/div[@class=&quot;row no-gutters&quot;]/div[@class=&quot;col-lg-4 col-md col&quot;]/div[@class=&quot;mx-name-container210 spacing-outer-right-medium spacing-outer-bottom-medium&quot;]/span[@class=&quot;mx-text mx-name-text319&quot;]</value>
      <webElementGuid>a940e6ac-4038-4cde-8d89-748d8d610492</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='142.BusinessPartnerRequest.AssignedToL1.dataView2_142.BusinessPartnerRequest.Snip_PurchaseAreaSupplier_RO_3CL.groupBox11_body']/div/div/div[2]/div[2]/div/span</value>
      <webElementGuid>564b6090-5801-4919-a40c-b29cc7353dba</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Order Currency'])[1]/following::span[1]</value>
      <webElementGuid>e332342c-56d0-4dac-b0b8-f2db72fc995c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Purchase Organisation'])[1]/following::span[3]</value>
      <webElementGuid>732f0e6e-8ea0-46f4-bb23-29a2f7d5490d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Recon Account'])[1]/preceding::span[1]</value>
      <webElementGuid>2c612398-6145-4097-84dc-2fee4ebab89e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Schema Group'])[1]/preceding::span[3]</value>
      <webElementGuid>9033f3dc-8392-4254-8e7c-d41cc7cbcf47</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='USD - (Internal) United States Dollar (5 Dec.)']/parent::*</value>
      <webElementGuid>437f776c-9629-4b8d-afb5-78b656158872</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[7]/div/div/div/div[2]/div[2]/div/span</value>
      <webElementGuid>70f944d2-0dfc-469e-a280-3bed18e916b8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'USD - (Internal) United States Dollar (5 Dec.)' or . = 'USD - (Internal) United States Dollar (5 Dec.)')]</value>
      <webElementGuid>bc5126f7-b489-4f38-900c-54f8c7aee603</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
