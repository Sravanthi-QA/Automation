<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>obj_SearchTerm</name>
   <tag></tag>
   <elementGuidId>74445716-bfba-457b-80ce-7a38afe4fa1e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>span.mx-text.mx-name-text232.text-semibold</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//span[contains(text(),'Search Term')]//..//../following-sibling::span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>f24cb641-1ac4-45c9-8e69-aced5b4077c7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>mx-text mx-name-text232 text-semibold</value>
      <webElementGuid>c2c42de1-5081-408e-8cf6-8c3ae50f5bfa</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Search Term</value>
      <webElementGuid>ec967cf9-af0a-4908-8b6d-128e5e61a2eb</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;142.BusinessPartnerRequest.Snip_Address_RO_3CL.groupBox4_ghk_5454_body&quot;)/div[@class=&quot;mx-name-container154 spacing-outer-left-medium spacing-outer-top&quot;]/div[@class=&quot;mx-name-layoutGrid1 mx-layoutgrid mx-layoutgrid-fluid&quot;]/div[@class=&quot;mx-name-layoutGrid1$row2 row no-gutters&quot;]/div[@class=&quot;mx-name-layoutGrid1$row2$column1 col-lg-4 col-md col&quot;]/div[@class=&quot;mx-name-container402 spacing-outer-bottom-medium spacing-outer-right-medium&quot;]/div[@class=&quot;mx-name-container403 spacing-outer-bottom&quot;]/span[@class=&quot;mx-text mx-name-text232 text-semibold&quot;]</value>
      <webElementGuid>3f034e4e-1ec0-41d1-95a9-5365c0bf8367</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='142.BusinessPartnerRequest.Snip_Address_RO_3CL.groupBox4_ghk_5454_body']/div/div/div[3]/div[2]/div/div/span</value>
      <webElementGuid>57db5c26-e21e-44d0-baf2-07a1d555e695</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Name 4'])[1]/following::span[2]</value>
      <webElementGuid>87750671-0038-4ba1-97fe-56063fa9171c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Name 3'])[1]/following::span[4]</value>
      <webElementGuid>c5626238-7f29-4498-81c3-7c684608a077</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='test'])[3]/preceding::span[1]</value>
      <webElementGuid>e796ca46-018f-4087-af20-9df92dff2f4a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='House Number'])[1]/preceding::span[2]</value>
      <webElementGuid>c28a6bf5-b616-4ff2-8eef-a671d0da9527</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Search Term']/parent::*</value>
      <webElementGuid>213e7cf9-6551-4145-b3a3-09e7bb976e02</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/div[2]/div/div/span</value>
      <webElementGuid>267337cd-4378-4ee5-8062-fde96c51b54c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Search Term' or . = 'Search Term')]</value>
      <webElementGuid>cfe47de2-a903-49b6-9f9f-ab36d9e17e10</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
