<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>obj_SSIBP</name>
   <tag></tag>
   <elementGuidId>ef7f6fca-cb75-42e0-835e-d1d95a5f7102</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>span.mx-text.mx-name-text223.text-semibold</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//span[text()='SSI BP']//../following-sibling::span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>1780a0dc-86ec-4932-bc1c-f79f7d70e848</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>mx-text mx-name-text223 text-semibold</value>
      <webElementGuid>058ff06f-ba87-4a7a-bed8-bfb9d0564809</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>SSI BP</value>
      <webElementGuid>13621ab3-35d2-461d-9f15-8ca669bc3751</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;142.BusinessPartnerRequest.AssignedToL1.dataView2_142.BusinessPartnerRequest.Snip_SSIBP_RO_3CL.groupBox26_body&quot;)/div[@class=&quot;mx-layoutgrid mx-layoutgrid-fluid mx-name-layoutGrid39 spacing-outer-left-medium&quot;]/div[@class=&quot;row no-gutters&quot;]/div[@class=&quot;col-lg-4 col-md col&quot;]/div[@class=&quot;mx-name-container500 spacing-outer-right-medium spacing-outer-bottom-medium&quot;]/div[@class=&quot;mx-name-container503 spacing-outer-bottom&quot;]/span[@class=&quot;mx-text mx-name-text223 text-semibold&quot;]</value>
      <webElementGuid>dd799543-ea60-466d-8859-3149789340cf</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='142.BusinessPartnerRequest.AssignedToL1.dataView2_142.BusinessPartnerRequest.Snip_SSIBP_RO_3CL.groupBox26_body']/div/div/div/div/div/span</value>
      <webElementGuid>bc2d9ff4-c10d-4087-990b-6b61884e3c78</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='SSI BP'])[1]/following::span[1]</value>
      <webElementGuid>d8430849-3053-4f00-bc38-b0f03da8daa9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='test'])[8]/following::span[1]</value>
      <webElementGuid>0b403087-3b11-45db-9ba6-417ee8bbbd92</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='No'])[2]/preceding::span[1]</value>
      <webElementGuid>4917d362-483b-436f-b948-e3dd0080b166</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Tax Documents Availability ?'])[1]/preceding::span[2]</value>
      <webElementGuid>a37971c0-159b-4533-972a-32fec3df847d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[8]/div/div/div/div/div/div/span</value>
      <webElementGuid>dba63a35-053e-42e7-b8d3-d3f8c92d6815</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'SSI BP' or . = 'SSI BP')]</value>
      <webElementGuid>1e21f6cb-3799-45ba-a643-200ba7b7828f</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
