<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>obj_Authorizationroup</name>
   <tag></tag>
   <elementGuidId>bb4bcfdf-27d5-4e19-9466-2b1ac1146a3a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>span.mx-text.mx-name-text320</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//span[text()='Authorization Group']//../following-sibling::span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>8008a1ad-d0d4-43dc-aaa7-ddc560f57ea1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>mx-text mx-name-text320</value>
      <webElementGuid>3fc80849-d8b2-428e-8f84-a48b086db138</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>GENL - General</value>
      <webElementGuid>3e956da0-5e7e-4d78-8a23-83cd46adffa9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;142.BusinessPartnerRequest.AssignedToL1.dataView2_142.BusinessPartnerRequest.Snip_PurchaseAreaSupplier_RO_3CL.groupBox11_body&quot;)/div[@class=&quot;mx-name-container46 spacing-outer-left-medium spacing-outer-top&quot;]/div[@class=&quot;mx-layoutgrid mx-layoutgrid-fluid mx-name-layoutGrid4&quot;]/div[@class=&quot;row no-gutters&quot;]/div[@class=&quot;col-lg-4 col-md col&quot;]/div[@class=&quot;mx-name-container696 spacing-outer-right-medium spacing-outer-bottom-medium&quot;]/span[@class=&quot;mx-text mx-name-text320&quot;]</value>
      <webElementGuid>cb018ba4-eec6-4439-8d54-a22b2cae8619</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='142.BusinessPartnerRequest.AssignedToL1.dataView2_142.BusinessPartnerRequest.Snip_PurchaseAreaSupplier_RO_3CL.groupBox11_body']/div/div/div[3]/div[2]/div/span</value>
      <webElementGuid>faaef761-6ccf-41ac-a3c9-1f5bf0b75e22</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Authorization Group'])[1]/following::span[1]</value>
      <webElementGuid>3b26ad11-41d2-4b10-93b0-e08f886fcc5f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Schema Group'])[1]/following::span[3]</value>
      <webElementGuid>eafab1f8-a193-4418-8b87-755e700e8114</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Corporate Group'])[1]/preceding::span[1]</value>
      <webElementGuid>94f4323a-ca5a-4b32-b8c0-3909ca90c2d4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='G001 - General'])[1]/preceding::span[2]</value>
      <webElementGuid>1abfb2d6-25f9-4273-9173-e10b415f6656</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='GENL - General']/parent::*</value>
      <webElementGuid>36a54245-5d51-4005-8139-e8eb62480279</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[7]/div/div/div/div[3]/div[2]/div/span</value>
      <webElementGuid>31e3e121-d7aa-4e56-8888-892734b32105</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'GENL - General' or . = 'GENL - General')]</value>
      <webElementGuid>7565e4f3-0cd8-4c82-81b9-cf5aae6f0605</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
