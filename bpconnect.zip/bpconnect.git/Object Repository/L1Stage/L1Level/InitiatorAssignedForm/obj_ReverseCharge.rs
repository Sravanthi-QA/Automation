<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>obj_ReverseCharge</name>
   <tag></tag>
   <elementGuidId>ad00920f-9288-466d-9e4e-110fc9436f76</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//span[contains(text(),'Reverse Charge')]//../following-sibling::span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>2925a19c-8a2c-49e9-8db5-57e24055f442</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>mx-text mx-name-text223 text-semibold</value>
      <webElementGuid>2e4d434e-6caa-48cb-9e18-fe2d6fb5881e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Reverse Charge</value>
      <webElementGuid>a6bfa6d5-e5b2-427b-8962-f085b984e388</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;142.BusinessPartnerRequest.Snip_ReverseCharge_RO_3CL.groupBox28_ghk_12771_body&quot;)/div[@class=&quot;mx-name-layoutGrid41 mx-layoutgrid mx-layoutgrid-fluid spacing-outer-left-medium&quot;]/div[@class=&quot;mx-name-layoutGrid41$row0 row no-gutters&quot;]/div[@class=&quot;mx-name-layoutGrid41$row0$column0 col-lg-4 col-md col&quot;]/div[@class=&quot;mx-name-container500 spacing-outer-right-medium&quot;]/div[@class=&quot;mx-name-container503 spacing-outer-bottom&quot;]/span[@class=&quot;mx-text mx-name-text223 text-semibold&quot;]</value>
      <webElementGuid>74a7e19a-f0ed-4998-aae7-1eac9eb1e5d5</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='142.BusinessPartnerRequest.Snip_ReverseCharge_RO_3CL.groupBox28_ghk_12771_body']/div/div/div/div/div/span</value>
      <webElementGuid>29ca58b0-e280-4659-99b6-6a94e4323bfa</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Reverse Charge Applicability'])[1]/following::span[1]</value>
      <webElementGuid>d6ffad60-2cc9-42ed-a929-c30bbc72d7d0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='No Data Found'])[1]/following::span[1]</value>
      <webElementGuid>6dca8f9e-8899-4938-99a5-2ddc083a4bcf</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='No'])[4]/preceding::span[1]</value>
      <webElementGuid>7fd38b6b-1cf9-4ae2-a4d4-2b69fb8892e9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Data Consent Form - Attachment'])[1]/preceding::span[2]</value>
      <webElementGuid>35b51cca-061c-4c79-b269-a10355c1d77b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Reverse Charge']/parent::*</value>
      <webElementGuid>999200a9-0112-4d8d-97d9-632267f7b8cf</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[12]/div/div/div/div/div/div/div/span</value>
      <webElementGuid>cba809bf-0c1c-44ea-9ce9-279f85730dff</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Reverse Charge' or . = 'Reverse Charge')]</value>
      <webElementGuid>bfa623af-77cd-4ff3-96e8-920a3444a99b</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
