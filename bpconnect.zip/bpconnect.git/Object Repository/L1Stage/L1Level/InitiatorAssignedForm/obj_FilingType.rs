<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>obj_FilingType</name>
   <tag></tag>
   <elementGuidId>d549ab90-0881-45c0-b203-3bdc183d2ef3</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>span.mx-text.mx-name-text2</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//span[contains(text(),'Filing Type')]//..//../following-sibling::span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>bd74069c-78cb-42a8-b818-ac0485095323</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>mx-text mx-name-text2</value>
      <webElementGuid>cec1a661-498a-4047-bfe3-6763eb0a4e75</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Request Filled by Initiator</value>
      <webElementGuid>d7c26ca0-ff41-4448-ae44-02c71e5daaa1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;142.BusinessPartnerRequest.Snip_SAPBusinessRegistrationForm_RO_3CL.groupBox1_ghk_5515_body&quot;)/div[@class=&quot;mx-name-container126 spacing-outer-left-medium&quot;]/div[@class=&quot;mx-name-layoutGrid1 mx-layoutgrid mx-layoutgrid-fluid&quot;]/div[@class=&quot;mx-name-layoutGrid1$row5 row no-gutters&quot;]/div[@class=&quot;mx-name-layoutGrid1$row5$column0 col-lg-4 col-md col&quot;]/div[@class=&quot;mx-name-container25 spacing-outer-bottom-medium spacing-outer-right-medium&quot;]/span[@class=&quot;mx-text mx-name-text2&quot;]</value>
      <webElementGuid>0da5f538-a75e-4c75-9411-386b0772543c</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='142.BusinessPartnerRequest.Snip_SAPBusinessRegistrationForm_RO_3CL.groupBox1_ghk_5515_body']/div/div/div[6]/div/div/span</value>
      <webElementGuid>2cdf5594-306d-4aa6-9d1b-8d2cd24e65a9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Filing Type'])[1]/following::span[1]</value>
      <webElementGuid>06fff274-e8bf-4e37-900a-b7ce9907ae14</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='test'])[1]/following::span[2]</value>
      <webElementGuid>6646f80f-9670-4917-832f-1631522474e4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='SPOC Email ID'])[1]/preceding::span[1]</value>
      <webElementGuid>14fdc5ad-ba15-47bd-9916-8df31bd85e21</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Address'])[1]/preceding::span[3]</value>
      <webElementGuid>96710c41-9b63-43ec-b635-e487f2e17619</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Request Filled by Initiator']/parent::*</value>
      <webElementGuid>1517e50f-517d-42e5-aafa-e7d7d8683f75</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[6]/div/div/span</value>
      <webElementGuid>b929f51c-5fd2-44ab-a57c-50cf4fbe380f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Request Filled by Initiator' or . = 'Request Filled by Initiator')]</value>
      <webElementGuid>36a4e609-d851-45ce-8f55-191e5edde861</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
