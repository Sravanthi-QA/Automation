<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>obj_PaymentDetails</name>
   <tag></tag>
   <elementGuidId>47ae7227-249d-4c4e-a504-1e39426216b3</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.mx-name-container230.spacing-outer-right-medium > span.mx-text.mx-name-text1</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//span[text()='Payment Terms']//../following-sibling::span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>36889e54-df0a-49f8-9543-7f370ab296dc</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>mx-text mx-name-text1</value>
      <webElementGuid>846eed1c-531c-482d-a715-c7f3e8e47fc7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>10 - within 10 days 1.5 % cash discount</value>
      <webElementGuid>d8d7ce9d-e8d4-4330-94c6-bf713f83b0ef</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;142.BusinessPartnerRequest.Snip_PaymentDetails_RO_3CL.groupBox10_ghk_5461_body&quot;)/div[@class=&quot;mx-name-layoutGrid19 mx-layoutgrid mx-layoutgrid-fluid spacing-outer-left-medium spacing-outer-top&quot;]/div[@class=&quot;mx-name-layoutGrid19$row0 row no-gutters&quot;]/div[@class=&quot;mx-name-layoutGrid19$row0$column0 col-lg-4 col-md col&quot;]/div[@class=&quot;mx-name-container230 spacing-outer-right-medium&quot;]/span[@class=&quot;mx-text mx-name-text1&quot;]</value>
      <webElementGuid>6933bbf6-7c2c-4cfa-a73b-5d4d812cd460</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='142.BusinessPartnerRequest.Snip_PaymentDetails_RO_3CL.groupBox10_ghk_5461_body']/div/div/div/div/span</value>
      <webElementGuid>ea19ffdc-f974-42c4-a783-eb659d7b5e4d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Payment Terms'])[1]/following::span[1]</value>
      <webElementGuid>d006bd28-e1e6-4870-bc24-1ca27258de3b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Payment Details'])[1]/following::span[2]</value>
      <webElementGuid>24bb68eb-8be2-43da-afc5-b07c8764ac67</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Payment Method'])[1]/preceding::span[1]</value>
      <webElementGuid>a78a9a14-98f6-4227-8d21-dc3da35a47b0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='O - Office Delivery - Check'])[1]/preceding::span[2]</value>
      <webElementGuid>a3c9f884-9492-4302-bf0e-ec46d7c47cbf</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='10 - within 10 days 1.5 % cash discount']/parent::*</value>
      <webElementGuid>7a8ceb43-8ca5-47f5-a290-f1dfa5a150e7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[6]/div/div/div/div/div/span</value>
      <webElementGuid>e822dbf5-b33b-43b1-b6b7-6620b1393dae</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = '10 - within 10 days 1.5 % cash discount' or . = '10 - within 10 days 1.5 % cash discount')]</value>
      <webElementGuid>27e7f48e-b757-4231-a1ab-2a97e95a2aaa</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
