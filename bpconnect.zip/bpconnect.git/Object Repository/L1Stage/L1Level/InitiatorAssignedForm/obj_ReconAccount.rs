<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>obj_ReconAccount</name>
   <tag></tag>
   <elementGuidId>6866b9c4-1f19-468a-b8f5-c5f4e5438e11</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>span.mx-text.mx-name-text315</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//span[text()='Recon Account']//../following-sibling::span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>c4995e25-6890-41fb-8d03-2a5aef6a74d6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>mx-text mx-name-text315</value>
      <webElementGuid>61c81912-501d-49e3-883a-683876dc643c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>15010002 - Sundry Creditors - Materials-Indigenous</value>
      <webElementGuid>c4efd8c2-8f51-40e5-b0f6-c6da09e22685</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;142.BusinessPartnerRequest.AssignedToL1.dataView2_142.BusinessPartnerRequest.Snip_PurchaseAreaSupplier_RO_3CL.groupBox11_body&quot;)/div[@class=&quot;mx-name-container46 spacing-outer-left-medium spacing-outer-top&quot;]/div[@class=&quot;mx-layoutgrid mx-layoutgrid-fluid mx-name-layoutGrid4&quot;]/div[@class=&quot;row no-gutters&quot;]/div[@class=&quot;col-lg-4 col-md col&quot;]/div[@class=&quot;mx-name-container360 spacing-outer-right-medium spacing-outer-bottom-medium&quot;]/span[@class=&quot;mx-text mx-name-text315&quot;]</value>
      <webElementGuid>11c4b4db-8fe2-4a74-8b51-e986184e48c8</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='142.BusinessPartnerRequest.AssignedToL1.dataView2_142.BusinessPartnerRequest.Snip_PurchaseAreaSupplier_RO_3CL.groupBox11_body']/div/div/div[2]/div[3]/div/span</value>
      <webElementGuid>bf5087f1-4a0a-40ce-b01b-b03ae69d5383</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Recon Account'])[1]/following::span[1]</value>
      <webElementGuid>304b8c2d-9419-4bfa-847e-f03dd69f34de</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='USD - (Internal) United States Dollar (5 Dec.)'])[1]/following::span[2]</value>
      <webElementGuid>4c15d3cd-2b8f-4148-ba6a-625b10c32d3e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Schema Group'])[1]/preceding::span[1]</value>
      <webElementGuid>bbe70728-166e-46df-8770-858a68481dff</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Authorization Group'])[1]/preceding::span[3]</value>
      <webElementGuid>5b3375f1-d47c-4fa9-8751-9055f582dff7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='15010002 - Sundry Creditors - Materials-Indigenous']/parent::*</value>
      <webElementGuid>099eeb61-36d9-4b6b-b126-9dadf1bddb80</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[7]/div/div/div/div[2]/div[3]/div/span</value>
      <webElementGuid>c0f55922-95ff-4c2b-abfe-fd4fa65fe519</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = '15010002 - Sundry Creditors - Materials-Indigenous' or . = '15010002 - Sundry Creditors - Materials-Indigenous')]</value>
      <webElementGuid>8a3b61b1-fe50-462f-8550-53bba4f798ee</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
