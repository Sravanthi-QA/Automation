<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>obj_DocumentValidTo</name>
   <tag></tag>
   <elementGuidId>261a1294-5dbb-42a4-bcaf-dad543e99a5c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>span.mx-text.mx-name-text123.text-semibold</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//span[contains(text(),'Document Valid To')]//../following-sibling::span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>6ad48dbc-3647-45b4-b008-3ae9d0750b17</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>mx-text mx-name-text123 text-semibold</value>
      <webElementGuid>3c79c915-0e83-48ae-a362-4dcdc3947813</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Document Valid To *</value>
      <webElementGuid>639364d0-2775-440e-944b-9e6225acfa5f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;142.BusinessPartnerRequest.AssignedToL1.dataView2_142.BusinessPartnerRequest.Snip_SEPComp_RO_3CL.groupBox27_body&quot;)/div[@class=&quot;mx-layoutgrid mx-layoutgrid-fluid mx-name-layoutGrid40 spacing-outer-left-medium&quot;]/div[@class=&quot;row no-gutters&quot;]/div[@class=&quot;col-lg-4 col-md col&quot;]/div[@class=&quot;mx-name-container303 spacing-outer-bottom-medium spacing-outer-right-medium&quot;]/div[@class=&quot;mx-name-container304 spacing-outer-bottom&quot;]/span[@class=&quot;mx-text mx-name-text123 text-semibold&quot;]</value>
      <webElementGuid>13f72a46-1700-4a30-a00c-9072b80aa3ad</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='142.BusinessPartnerRequest.AssignedToL1.dataView2_142.BusinessPartnerRequest.Snip_SEPComp_RO_3CL.groupBox27_body']/div/div[2]/div[3]/div/div/span</value>
      <webElementGuid>d34816c0-8646-4fb5-bcb4-2933c9b372a3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Document Valid From *'])[1]/following::span[2]</value>
      <webElementGuid>cd38a246-1297-4cd2-a40e-ea010871b295</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='TDSU/S194Q'])[1]/following::span[3]</value>
      <webElementGuid>b1ed6d41-6ec3-4b0a-ac49-aedde7d79974</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='SEZ Applicability'])[1]/preceding::span[2]</value>
      <webElementGuid>db47ba8a-e29f-462a-af4e-de542e4226f7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='SEZ Applicability'])[2]/preceding::span[2]</value>
      <webElementGuid>75c09a4d-40e7-4b4c-b337-8b6cd14ecdb6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Document Valid To *']/parent::*</value>
      <webElementGuid>53098cc9-9273-4296-ada0-2523bb5f7c57</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[9]/div/div/div/div[2]/div[3]/div/div/span</value>
      <webElementGuid>2d6ed21f-1b71-42f9-b9d2-87844431bd6e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Document Valid To *' or . = 'Document Valid To *')]</value>
      <webElementGuid>618ec160-2939-48c1-9c3b-6c049bea2aaa</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
