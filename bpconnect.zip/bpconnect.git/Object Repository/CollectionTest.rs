<?xml version="1.0" encoding="UTF-8"?>
<WebServiceRequestEntity>
   <description></description>
   <name>CollectionTest</name>
   <tag></tag>
   <elementGuidId>29e61b37-6fe8-437c-94dd-a3608b895a0c</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <connectionTimeout>0</connectionTimeout>
   <followRedirects>false</followRedirects>
   <httpBody></httpBody>
   <httpBodyContent></httpBodyContent>
   <httpBodyType></httpBodyType>
   <httpHeaderProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>Content-Type</name>
      <type>Main</type>
      <value>text/plain</value>
      <webElementGuid>9eb2a34c-bb8c-4231-aad8-14e0dd332693</webElementGuid>
   </httpHeaderProperties>
   <httpHeaderProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>x-api-key</name>
      <type>Main</type>
      <value>AfmXfWZYEr8xEi72YctIP4e0k6AjRCix8eiXDb5n</value>
      <webElementGuid>6a4ebe44-edcb-45d1-a62e-f46ed3460436</webElementGuid>
   </httpHeaderProperties>
   <httpHeaderProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>Authorization</name>
      <type>Main</type>
      <value>Bearer eyJ0eXAiOiJKV1QiLCJub25jZSI6IlZZaHlqcXAtcnl3MmV0emE3U3c2ZTRBVlBybjAycFpZSWp4amtQTWJMOXciLCJhbGciOiJSUzI1NiIsIng1dCI6IjJaUXBKM1VwYmpBWVhZR2FYRUpsOGxWMFRPSSIsImtpZCI6IjJaUXBKM1VwYmpBWVhZR2FYRUpsOGxWMFRPSSJ9.eyJhdWQiOiIwMDAwMDAwMy0wMDAwLTAwMDAtYzAwMC0wMDAwMDAwMDAwMDAiLCJpc3MiOiJodHRwczovL3N0cy53aW5kb3dzLm5ldC82ZDE0NjgyYi02OGE2LTRhMjUtYWYzZC0wNjYxNWUxNDZiMWUvIiwiaWF0IjoxNjU4NDAzNzEwLCJuYmYiOjE2NTg0MDM3MTAsImV4cCI6MTY1ODQwODg3OCwiYWNjdCI6MCwiYWNyIjoiMSIsImFpbyI6IkUyWmdZQWhTdFBqZ016MXJUdkpqWDVuNndGUE1uS0t5cCswdVg5M2JxSzYvYjk3Y0o4SUEiLCJhbXIiOlsicHdkIl0sImFwcF9kaXNwbGF5bmFtZSI6IkdyYXBoIEV4cGxvcmVyIiwiYXBwaWQiOiJkZThiYzhiNS1kOWY5LTQ4YjEtYThhZC1iNzQ4ZGE3MjUwNjQiLCJhcHBpZGFjciI6IjAiLCJmYW1pbHlfbmFtZSI6IlYiLCJnaXZlbl9uYW1lIjoiU3VicmFtYW55YW0iLCJpZHR5cCI6InVzZXIiLCJpcGFkZHIiOiIxNTcuNDcuMTEwLjEyNSIsIm5hbWUiOiJTdWJyYW1hbnlhbSBWIiwib2lkIjoiNjM1NTI2MTktNzY0Ni00YmMyLWE1NjEtZjY5NDYyM2M2MWYyIiwib25wcmVtX3NpZCI6IlMtMS01LTIxLTEwMjAxODg0MDktMzgxNDM1MzIyNC02ODM2MTQyNTItNTQ0MzExMzc5IiwicGxhdGYiOiIzIiwicHVpZCI6IjEwMDMyMDAxRjM4ODVBQzAiLCJwd2RfZXhwIjoiNTc4NzgzIiwicHdkX3VybCI6Imh0dHBzOi8vcG9ydGFsLm1pY3Jvc29mdG9ubGluZS5jb20vQ2hhbmdlUGFzc3dvcmQuYXNweCIsInJoIjoiMC5BU3NBSzJnVWJhWm9KVXF2UFFaaFhoUnJIZ01BQUFBQUFBQUF3QUFBQUFBQUFBQXJBTE0uIiwic2NwIjoiQWNjZXNzUmV2aWV3LlJlYWQuQWxsIEFjY2Vzc1Jldmlldy5SZWFkV3JpdGUuQWxsIEFjY2Vzc1Jldmlldy5SZWFkV3JpdGUuTWVtYmVyc2hpcCBBZG1pbmlzdHJhdGl2ZVVuaXQuUmVhZC5BbGwgQWRtaW5pc3RyYXRpdmVVbml0LlJlYWRXcml0ZS5BbGwgQWdyZWVtZW50LlJlYWQuQWxsIEFncmVlbWVudC5SZWFkV3JpdGUuQWxsIEFncmVlbWVudEFjY2VwdGFuY2UuUmVhZCBBZ3JlZW1lbnRBY2NlcHRhbmNlLlJlYWQuQWxsIEFuYWx5dGljcy5SZWFkIEFQSUNvbm5lY3RvcnMuUmVhZC5BbGwgQVBJQ29ubmVjdG9ycy5SZWFkV3JpdGUuQWxsIEFwcENhdGFsb2cuUmVhZC5BbGwgQXBwQ2F0YWxvZy5SZWFkV3JpdGUuQWxsIEFwcENhdGFsb2cuU3VibWl0IEFwcGxpY2F0aW9uLlJlYWQuQWxsIEFwcGxpY2F0aW9uLlJlYWRXcml0ZS5BbGwgQXBwUm9sZUFzc2lnbm1lbnQuUmVhZFdyaXRlLkFsbCBBdWRpdExvZy5SZWFkLkFsbCBDYWxlbmRhcnMuUmVhZFdyaXRlIENvbnRhY3RzLlJlYWRXcml0ZSBEZXZpY2VNYW5hZ2VtZW50QXBwcy5SZWFkLkFsbCBEZXZpY2VNYW5hZ2VtZW50QXBwcy5SZWFkV3JpdGUuQWxsIERldmljZU1hbmFnZW1lbnRDb25maWd1cmF0aW9uLlJlYWQuQWxsIERldmljZU1hbmFnZW1lbnRDb25maWd1cmF0aW9uLlJlYWRXcml0ZS5BbGwgRGV2aWNlTWFuYWdlbWVudE1hbmFnZWREZXZpY2VzLlByaXZpbGVnZWRPcGVyYXRpb25zLkFsbCBEZXZpY2VNYW5hZ2VtZW50TWFuYWdlZERldmljZXMuUmVhZC5BbGwgRGV2aWNlTWFuYWdlbWVudE1hbmFnZWREZXZpY2VzLlJlYWRXcml0ZS5BbGwgRGV2aWNlTWFuYWdlbWVudFJCQUMuUmVhZC5BbGwgRGV2aWNlTWFuYWdlbWVudFJCQUMuUmVhZFdyaXRlLkFsbCBEZXZpY2VNYW5hZ2VtZW50U2VydmljZUNvbmZpZy5SZWFkLkFsbCBEZXZpY2VNYW5hZ2VtZW50U2VydmljZUNvbmZpZy5SZWFkV3JpdGUuQWxsIERpcmVjdG9yeS5BY2Nlc3NBc1VzZXIuQWxsIERpcmVjdG9yeS5SZWFkLkFsbCBEaXJlY3RvcnkuUmVhZFdyaXRlLkFsbCBGaWxlcy5SZWFkV3JpdGUuQWxsIEdyb3VwLlJlYWRXcml0ZS5BbGwgSWRlbnRpdHlSaXNrRXZlbnQuUmVhZC5BbGwgTWFpbC5SZWFkV3JpdGUgTWFpbGJveFNldHRpbmdzLlJlYWRXcml0ZSBOb3Rlcy5SZWFkV3JpdGUuQWxsIG9wZW5pZCBQZW9wbGUuUmVhZCBwcm9maWxlIFJlcG9ydHMuUmVhZC5BbGwgU2l0ZXMuUmVhZFdyaXRlLkFsbCBUYXNrcy5SZWFkV3JpdGUgVXNlci5SZWFkIFVzZXIuUmVhZEJhc2ljLkFsbCBVc2VyLlJlYWRXcml0ZSBVc2VyLlJlYWRXcml0ZS5BbGwgZW1haWwiLCJzaWduaW5fc3RhdGUiOlsia21zaSJdLCJzdWIiOiJpcS1ITFluNk40TVRMNU5weWFaeEFSbnJBNDVmWnFuVUpYcnpGd2pHRjdJIiwidGVuYW50X3JlZ2lvbl9zY29wZSI6IkFTIiwidGlkIjoiNmQxNDY4MmItNjhhNi00YTI1LWFmM2QtMDY2MTVlMTQ2YjFlIiwidW5pcXVlX25hbWUiOiJzdWJyYW1hbnlhbXZAZHJyZWRkeXMuY29tIiwidXBuIjoic3VicmFtYW55YW12QGRycmVkZHlzLmNvbSIsInV0aSI6IkI4ejgzWU40UDAtYUhZOFk4cWRpQUEiLCJ2ZXIiOiIxLjAiLCJ3aWRzIjpbImI3OWZiZjRkLTNlZjktNDY4OS04MTQzLTc2YjE5NGU4NTUwOSJdLCJ4bXNfc3QiOnsic3ViIjoidUJQRjFaR1Zta1MzQ0l3cUlhcFhtME1jaUkzNGZQNlRGWUhxV2hoNHFoayJ9LCJ4bXNfdGNkdCI6MTM2MzkzMzI5NH0.CbYYRrSG8NA8ekU_hT8_KFWKqEpIp_CSBUDgpraHnDvAKWIt800XLx7ApnZ-2rya8VAke_1QtZ9x7kbKQWE34hCbaQmE1HuJotOxNBakvaogX0OMWBxtcOnilkoKP9K89-Dmm8kXqIxAB-eKqIAmUnhAgJOw5os3h7JV3I8pAEPgLgdhx85FOD1Y71Icume8YA0CnDM3osd-N6wnCf5wiDgRheFszHq6ceThzDjAkv_PP_Hl5pU7phf_YJL5wxPT7JDJccIntkj0TwlhWtYErLxlGtUp5FTzSUKj8RMPVEw-KmXd9jQaZguj77yc-5KIV9301gTCffqo9WoYKNZ8PA</value>
      <webElementGuid>93575436-7ecb-4b67-a1c2-61caf877a0ac</webElementGuid>
   </httpHeaderProperties>
   <katalonVersion>8.4.0</katalonVersion>
   <maxResponseSize>0</maxResponseSize>
   <migratedVersion>5.4.1</migratedVersion>
   <restRequestMethod>GET</restRequestMethod>
   <restUrl>https://wnueu0khgk.execute-api.ap-south-1.amazonaws.com/prod/getproductbyid?Id=DP00051&amp;Name=Australia</restUrl>
   <serviceType>RESTful</serviceType>
   <soapBody></soapBody>
   <soapHeader></soapHeader>
   <soapRequestMethod></soapRequestMethod>
   <soapServiceEndpoint></soapServiceEndpoint>
   <soapServiceFunction></soapServiceFunction>
   <socketTimeout>0</socketTimeout>
   <useServiceInfoFromWsdl>true</useServiceInfoFromWsdl>
   <variables>
      <defaultValue>''</defaultValue>
      <description></description>
      <id>b7962438-a0ed-4dd7-85d0-408f760f6a1f</id>
      <masked>false</masked>
      <name>token1</name>
   </variables>
   <verificationScript>import static org.assertj.core.api.Assertions.*

import com.kms.katalon.core.testobject.RequestObject
import com.kms.katalon.core.testobject.ResponseObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webservice.verification.WSResponseManager

import groovy.json.JsonSlurper
import internal.GlobalVariable as GlobalVariable

RequestObject request = WSResponseManager.getInstance().getCurrentRequest()

ResponseObject response = WSResponseManager.getInstance().getCurrentResponse()

//WS.verifyElementsCount(response, 'Product_Countrys.Launch_Country', '1')

println(&quot;=====&quot;+WS.getElementsCount(response, 'Product_Countrys.Launch_Country.Name'))

println(&quot;=====&quot;+WS.getElementText(response, 'Product_Countrys.Launch_Country.Name'))

if(WS.getElementsCount(response, 'Product_Countrys.Launch_Country.Name') >=1) {
	println(&quot;passed&quot;)
}</verificationScript>
   <wsdlAddress></wsdlAddress>
</WebServiceRequestEntity>
