<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Third party risk management button</description>
   <name>button_ThirdPartyRiskManagememt</name>
   <tag></tag>
   <elementGuidId>b3136e91-c3df-4ffc-9dda-2cf546e85b8f</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//h5[text()='Third Party Risk Management *']//i</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
