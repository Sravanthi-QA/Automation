<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>SAP Business Registration Form icon</description>
   <name>button_SAPBusinessRegistrationFormIcon</name>
   <tag></tag>
   <elementGuidId>fe7b63fe-1859-4560-bd32-8c196e912b66</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//h2[text()='SAP Business Registration Form']//i</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
