package utilities

import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.checkpoint.Checkpoint
import com.kms.katalon.core.checkpoint.CheckpointFactory
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testcase.TestCase
import com.kms.katalon.core.testcase.TestCaseFactory
import com.kms.katalon.core.testdata.TestData
import com.kms.katalon.core.testdata.TestDataFactory
import com.kms.katalon.core.testobject.ObjectRepository
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords
import internal.GlobalVariable
import org.openqa.selenium.WebElement
import org.openqa.selenium.WebDriver
import org.junit.After
import org.openqa.selenium.By
import com.kms.katalon.core.mobile.keyword.internal.MobileDriverFactory
import com.kms.katalon.core.webui.driver.DriverFactory
import com.kms.katalon.core.testobject.RequestObject
import com.kms.katalon.core.testobject.ResponseObject
import com.kms.katalon.core.testobject.ConditionType
import com.kms.katalon.core.testobject.TestObjectProperty
import com.kms.katalon.core.mobile.helper.MobileElementCommonHelper
import com.kms.katalon.core.util.KeywordUtil
import com.kms.katalon.core.webui.exception.WebElementNotFoundException
import static org.assertj.core.api.Assertions.*
import com.kms.katalon.core.webservice.verification.WSResponseManager
import groovy.json.JsonSlurper
import com.kms.katalon.core.testobject.RestRequestObjectBuilder
import com.kms.katalon.core.testobject.impl.HttpTextBodyContent
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.net.URL;
import javax.imageio.ImageIO;
import org.openqa.selenium.chrome.ChromeDriver;
import java.io.File;
import java.util.concurrent.TimeUnit;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.Point;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.Test;
import com.kms.katalon.core.testobject.UrlEncodedBodyParameter
import commonKeywords.ApplicationKeywords
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import com.testwithhari.katalon.plugins.Gmail as gmail
import java.util.ArrayList;

public class OTPRetrieval extends ApplicationKeywords{

	OTPRetrieval(){
		driver = DriverFactory.getWebDriver()
	}

	@Keyword
	public ResponseObject buildApiRequestForOTP(String emailId) {
		String[] fullEmailId = emailId.split("@",2)
		emailId = fullEmailId[0];
		WebUI.delay(10)
		String endpoint = "https://web2.temp-mail.org/messages"
		String requestMethod = "GET"
		TestObjectProperty header1 = new TestObjectProperty("authorization", ConditionType.EQUALS, "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1dWlkIjoiMmUxYjRmMGQ4YmM0NDg0YTk0ZjBiMzdiZGQ4Y2Q4ZDEiLCJtYWlsYm94IjoibWl4b2NpNjE5MUByb3hvYXMuY29tIiwiaWF0IjoxNjUyNzcxOTYwfQ.fkUw5JAnbNvpuzfSL3PdjHQtfGFgeKWv0RMR1MGX74c")
		ArrayList defaultHeaders = Arrays.asList(header1)
		RequestObject ro = new RestRequestObjectBuilder()
				.withRestUrl(endpoint)
				.withHttpHeaders(defaultHeaders)
				.withRestRequestMethod(requestMethod)
				.build()

		ResponseObject respObj = WS.sendRequest(ro)
		println("============================"+respObj.getResponseBodyContent().toString())
		return respObj
	}


	public 	ArrayList<String> getUserNameAndPasswordFromGmail(String email,String password,String requestNum){
		ArrayList<String> credtials = new ArrayList<String>();
		for(int i=0;i<10;i++) {
			WebUI.delay(3)
			String message = gmail.readLatestEMailBodyContent(email, password, 'Inbox').toString()
			if(message.contains(requestNum)) {
				println("========================="+"pass")
				break
			}
		}
		for(int i=0;i<10;i++) {
			try {
				WebUI.delay(5)
				String cred = gmail.readLatestEMailBodyContent(email, password, 'Inbox').toString()
				String[] cred2 = cred.split("Username:",2)
				String[] cred3 = cred2[1].split("Password:",2)
				String userName = cred3[0].trim()
				println("User name : "+userName)
				credtials.add(userName.trim())
				String[] cred4 = cred3[1].split("This",2)
				String passwodd = cred4[0].trim()
				println("Password : "+passwodd)
				credtials.add(passwodd.trim())
				break
			}catch(Exception e) {
				continue
			}
		}
		return credtials
	}

	public void getMsgFromGmail(String email,String password,String requestNum){
		for(int i=0;i<10;i++) {
			WebUI.delay(3)
			String message = gmail.readLatestEMailBodyContent(email, password, 'Inbox').toString()
			if(message.contains(requestNum)) {
				println("========================="+"pass")
				break
			}
		}
	}
}
