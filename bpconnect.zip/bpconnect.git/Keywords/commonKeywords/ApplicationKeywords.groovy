package commonKeywords
import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.checkpoint.Checkpoint
import com.kms.katalon.core.checkpoint.CheckpointFactory
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testcase.TestCase
import com.kms.katalon.core.testcase.TestCaseFactory
import com.kms.katalon.core.testdata.TestData
import com.kms.katalon.core.testdata.TestDataFactory
import com.kms.katalon.core.testobject.ObjectRepository
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords

import internal.GlobalVariable

import org.openqa.selenium.WebElement
import org.openqa.selenium.WebDriver
import org.openqa.selenium.By

import com.kms.katalon.core.mobile.keyword.internal.MobileDriverFactory
import com.kms.katalon.core.webui.driver.DriverFactory

import com.kms.katalon.core.testobject.RequestObject
import com.kms.katalon.core.testobject.ResponseObject
import com.kms.katalon.core.testobject.ConditionType
import com.kms.katalon.core.testobject.TestObjectProperty

import com.kms.katalon.core.mobile.helper.MobileElementCommonHelper
import com.kms.katalon.core.util.KeywordUtil
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

import com.kms.katalon.core.webui.exception.WebElementNotFoundException
import org.openqa.selenium.Keys;
import org.openqa.selenium.JavascriptExecutor;



class ApplicationKeywords {

	public static WebDriver driver;
	String locatorVal;
	public String locatorType;
	public String locatorDescription;
	ApplicationKeywords(){
		driver = DriverFactory.getWebDriver()
	}

	/**
	 * @author Vadisa Subramanyam
	 * @description : This method is used to refresh browser
	 */
	@Keyword
	def refreshBrowser() {
		try {
			KeywordUtil.logInfo("Refreshing")
			WebDriver webDriver = DriverFactory.getWebDriver()
			webDriver.navigate().refresh()
			KeywordUtil.markPassed("Refresh successfully")
		}catch(Exception e) {
			e.printStackTrace()
			KeywordUtil.markFailed("Exception occured while refreshing browser"+e.getLocalizedMessage())
		}
	}

	/**
	 * @author : Vadisa Subramanyam
	 * @description : Method to click element
	 * @param to : 'to' is Katalon test object
	 */
	@Keyword
	def clickElement(TestObject to) {
		try {
			WebElement element = WebUiBuiltInKeywords.findWebElement(to);
			KeywordUtil.logInfo("Clicking element")
			element.click()
			KeywordUtil.markPassed("Element has been clicked")
		} catch (WebElementNotFoundException e) {
			KeywordUtil.markFailed("Element not found")
		} catch (Exception e) {
			KeywordUtil.markFailed("Fail to click on element")
		}
	}

	/**
	 * @author Vadisa Subramanyam
	 * @descrption : Method to get all rows of HTML table
	 * @param : table Katalon test object represent for HTML table
	 * @param  : xpathValue outer tag name of TR tag, usually is TBODY
	 * @return : All rows inside HTML table
	 */
	@Keyword
	def List<WebElement> getHtmlTableRows(TestObject table, String xpathValue) {
		List<WebElement> selectedRows =null;
		try {
			WebElement mailList = WebUiBuiltInKeywords.findWebElement(table)
			selectedRows = mailList.findElements(By.xpath(xpathValue))
		}catch(Exception e) {
			e.printStackTrace()
			KeywordUtil.markFailed("Exception occured while get all rows of HTML table"+e.getLocalizedMessage())
		}
		return selectedRows
	}

	/**
	 * @author Vadisa Subramanyam
	 * @descrption : Method to verify element is displayed or not.
	 * @param testObjectElement : testObjectElement is object that need to perform actions.
	 * @return flag : flag returns true if element is displayed and false if element is not displayed
	 */
	@Keyword
	def boolean isDisplayed(TestObject testObjectElement) {
		boolean flag = false
		try {

			if(WebUI.verifyElementVisible(testObjectElement,FailureHandling.OPTIONAL)) {
				KeywordUtil.logInfo("'"+testObjectElement.getObjectId().split('/').last()+"' is displayed ")
				flag = true
			}else {
				KeywordUtil.logInfo("'"+testObjectElement.getObjectId().split('/').last()+"' is not displayed")
				flag = false
			}
		}catch(Exception e) {
			e.printStackTrace()
			KeywordUtil.markFailed("Exception occured while verifying element is displayed or not."+e.getLocalizedMessage())
		}
		return flag
	}

	/**
	 * @author Vadisa Subramanyam
	 * @descrption : Method to verify element is not editable.
	 * @param testObjectElement : testObjectElement is object that need to perform actions.
	 * @return flag : flag returns true if element is displayed and false if element is not displayed
	 */
	@Keyword
	def boolean verifyElementIsNotEditable(TestObject testObjectElement) {
		boolean flag = false
		try {
			WebElement element = WebUiBuiltInKeywords.findWebElement(testObjectElement)
			String tagName = element.getTagName()
			try {

				element.sendKeys(" ")
				element.click()
				KeywordUtil.markError("'"+testObjectElement.getObjectId().split('/').last()+"' is not editable")
				flag = false
				String enabledValue = element.getAttribute("class")

				if(!enabledValue.equals("filedropper__dropzone")) {
					flag = false
				}else {
					println("'"+testObjectElement.getObjectId().split('/').last()+"' is not editable ")
					flag = true
				}
			}catch(Exception e){
				println("'"+testObjectElement.getObjectId().split('/').last()+"' is not editable ")
				flag = true
			}

			if((!(element.isDisplayed() && element.isEnabled()) || tagName.equals("span") || tagName.equals("div") ||tagName.equals("td")) && flag==true) {
				KeywordUtil.markPassed("'"+testObjectElement.getObjectId().split('/').last()+"' is not editable")
				println("'"+testObjectElement.getObjectId().split('/').last()+"' is not editable ")
				flag = true
			}else {
				KeywordUtil.markError("'"+testObjectElement.getObjectId().split('/').last()+"' is editable ")
				println("'"+testObjectElement.getObjectId().split('/').last()+"' is editable ")
				flag = false
			}
		}catch(Exception e) {
			e.printStackTrace()
			KeywordUtil.markFailed("Exception occured while verifying element is not editable"+e.getLocalizedMessage())
		}
		return flag
	}

	/**
	 * @author Vadisa Subramanyam
	 * @descrption : Method to verify element is enabled
	 * @param testObjectElement : testObjectElement is object that need to perform actions.
	 * @return flag : flag returns true if element is displayed and false if element is not enabled
	 */
	@Keyword
	def boolean isEnabled(TestObject testObjectElement) {
		boolean flag = false
		try {
			WebElement element = WebUiBuiltInKeywords.findWebElement(testObjectElement)
			if(element.isDisplayed()&& element.isEnabled()) {
				KeywordUtil.logInfo("'"+testObjectElement.getObjectId().split('/').last()+"' is enabled ")
				flag = true
			}else {
				KeywordUtil.logInfo("'"+testObjectElement.getObjectId().split('/').last()+"' is not enabled")
				flag = false
			}
		}catch(Exception e) {
			e.printStackTrace()
			KeywordUtil.markFailed("Exception occured while verifying element is enabled or not."+e.getLocalizedMessage())
		}
		return flag
	}


	/**
	 * @author Vadisa Subramanyam
	 * @descrption : Method to verify element is present
	 * @param testObjectElement : testObjectElement is object that need to perform actions.
	 * @return flag : flag returns true if element is displayed and false if element is not present
	 */
	@Keyword
	def boolean isPresent(TestObject testObjectElement) {
		boolean flag = false
		try {

			if(WebUI.verifyElementPresent(testObjectElement, 20,FailureHandling.OPTIONAL)) {
				KeywordUtil.logInfo("'"+testObjectElement.getObjectId().split('/').last()+"' is enabled ")
				flag = true
			}else {
				KeywordUtil.logInfo("'"+testObjectElement.getObjectId().split('/').last()+"' is not enabled")
				flag = false
			}
		}catch(Exception e) {
			e.printStackTrace()
			KeywordUtil.markFailed("Exception occured while verifying element is enabled or not."+e.getLocalizedMessage())
		}
		return flag
	}
	/**
	 * @author Vadisa Subramanyam
	 * @descrption : Method to clear text field.
	 * @param testObjectElement : testObjectElement is object that need to perform actions.
	 * @return flag : flag returns true if element is displayed and false if element is cleared text.
	 */
	@Keyword
	def boolean clearTextField(TestObject testObjectElement) {
		boolean flag = false
		try {
			WebElement element = WebUiBuiltInKeywords.findWebElement(testObjectElement)
			element.sendKeys(Keys.CONTROL + "a");
			element.sendKeys(Keys.DELETE);
			flag = true
		}catch(Exception e) {
			e.printStackTrace()
			KeywordUtil.markFailed("Exception occured while clearing text field."+e.getLocalizedMessage())
		}
		return flag
	}

	public void highLighterMethod(TestObject testObjectElement) {
		try {
			WebElement e = WebUiBuiltInKeywords.findWebElement(testObjectElement)
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: 2px solid red;');", e);
			WebUI.delay(1)
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void highLighterMethod(WebElement webElement) {
		try {
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: 2px solid red;');", webElement);
			WebUI.delay(1)
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}