package pages

import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject

import java.awt.datatransfer.StringSelection
import java.awt.event.KeyEvent
import java.util.concurrent.ConcurrentHashMap.KeySetView

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.checkpoint.Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testcase.TestCase
import com.kms.katalon.core.testdata.TestData
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import com.kms.katalon.core.webui.driver.DriverFactory
import commonKeywords.ApplicationKeywords
import org.openqa.selenium.WebElement
import org.openqa.selenium.interactions.Actions
import org.openqa.selenium.WebDriver
import org.openqa.selenium.By
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords
import com.kms.katalon.core.util.KeywordUtil
import com.kms.katalon.core.mobile.keyword.internal.MobileDriverFactory
import internal.GlobalVariable
import java.awt.AWTException;
import java.awt.Robot
import java.awt.Toolkit;
import org.openqa.selenium.Keys;
import com.kms.katalon.core.testobject.ConditionType



public class BusinessPartnerOnboardingPage extends ApplicationKeywords{
	public String path = System.getProperty("user.dir")+"\\Data Files\\";
	BusinessPartnerOnboardingPage(){
		driver = DriverFactory.getWebDriver()
	}

	/**
	 * @author Vadisa Subramanyam
	 * @description : Method to fill SAP Business registration form.
	 * @param data : data is set that contains data to fill in registration form.
	 */
	@Keyword
	def fillSAPBusinessRegistrationFormForSupplierOnboarding(String companyCode,HashMap<String,String> data) {
		try {
			String companyCodeVal = companyCode.trim().charAt(0)
			WebUI.selectOptionByLabel(findTestObject('BPConnect_InviteNewPartner/dropdown_CompanyCode'),
					data.get("companyCode"), false)

			WebUI.delay(3)

			WebUI.selectOptionByLabel(findTestObject('BPConnect_InviteNewPartner/dropdown_TypeOfPartner'),
					data.get("typeOfPartner"), false)

			if(data.get("typeOfPartner").trim().equalsIgnoreCase("Domestic")&& companyCodeVal.equals("1")) {
				WebUI.selectOptionByLabel(findTestObject('BPConnect_InviteNewPartner/dropdown_PartnersCatagory'),
						data.get("partnersCatagory"), false)
			}

			WebUI.selectOptionByLabel(findTestObject('BPConnect_InviteNewPartner/dropdown_AccountGroup'),
					data.get("accountGroup"), false)

			WebUI.setText(findTestObject('BPConnect_InviteNewPartner/textField_PartnersEmailId'), data.get("partnersEmailId"))

			WebUI.setText(findTestObject('Object Repository/BPConnect_InviteNewPartner/textField_SpcEmailID'), data.get("spocEmailId"))

			WebUI.scrollToElement(findTestObject('Object Repository/BPConnect_InviteNewPartner/textField_PartnersMobileNumber'), 100)

			WebUI.waitForElementVisible(findTestObject('Object Repository/BPConnect_InviteNewPartner/textField_PartnersMobileNumber'), 100)

			WebUI.setText(findTestObject('Object Repository/BPConnect_InviteNewPartner/textField_PartnersMobileNumber'),
					data.get("partnersMobileNumber"))

			TestObject businessPartner = findTestObject('Object Repository/BPConnect_InviteNewPartner/textField_BusinessPartnersName');
			if(isDisplayed(businessPartner))
				WebUI.setText(businessPartner, data.get("businessPartnersName"))

			if(data.get("supplierType").trim().equalsIgnoreCase("Material Supply")) {
				WebUI.click(findTestObject('Object Repository/BPConnect_InviteNewPartner/radioButton_MaterialSupply'))
			}else if(data.get("supplierType").trim().equalsIgnoreCase("Service")) {
				WebUI.click(findTestObject('BPConnect_InviteNewPartner/radioButton_Service'))
			}else if(data.get("supplierType").trim().equalsIgnoreCase("Both")) {
				WebUI.click(findTestObject('BPConnect_InviteNewPartner/radioButton_Both'))
			}

			WebUI.delay(3)

			WebUI.scrollToElement(findTestObject('Object Repository/BPConnect_InviteNewPartner/dropdown_NatureOfService'), 100)

			WebUI.selectOptionByLabel(findTestObject('Object Repository/BPConnect_InviteNewPartner/dropdown_NatureOfService'),
					data.get("natureOfService"), false)
			if(companyCodeVal.equals("1")) {
				WebUI.scrollToElement(findTestObject('Object Repository/BPConnect_InviteNewPartner/radioButton_VIkretaConnectAccess'), 100)
				WebUI.click(findTestObject('Object Repository/BPConnect_InviteNewPartner/radioButton_VIkretaConnectAccess'))
			}

			WebUI.setText(findTestObject('Object Repository/BPConnect_InviteNewPartner/textArea_BriefDescriptionOfServies'),
					data.get("briefDescriptionOfServies"))
		}catch(Exception e) {
			e.printStackTrace()
			KeywordUtil.markFailed("Exception occured while filling SAP Business registration form."+e.getLocalizedMessage())
		}
	}

	/**
	 * @author Vadisa Subramanyam
	 * @description : Method to fill SAP Business registration form to invite partner.
	 * @param data : data is set that contains data to fill in registration form to invite supplier.
	 */
	@Keyword
	def fillSAPBusinessRegistrationFormToInviteSupplier(String companyCode,HashMap<String,String> data) {
		try {
			WebUI.scrollToElement(findTestObject('BPConnect_InviteNewPartner/button_SAPBusinessRegistrationFormIcon'), 100)
			String sapPulsIcon = WebUI.getAttribute(findTestObject('BPConnect_InviteNewPartner/button_SAPBusinessRegistrationFormIcon'),"class").trim()
			if(!sapPulsIcon.contains("minus")) {
				WebUI.click(findTestObject('BPConnect_InviteNewPartner/button_SAPBusinessRegistrationFormIcon'))
			}
			WebUI.waitForElementClickable(findTestObject('BPConnect_InviteNewPartner/radioButton_Supplier'), 100)
			WebUI.click(findTestObject('BPConnect_InviteNewPartner/radioButton_Supplier'))

			WebUI.waitForElementClickable(findTestObject('BPConnect_InviteNewPartner/radioButton_SendInviteToPartner'), 100)
			WebUI.click(findTestObject('BPConnect_InviteNewPartner/radioButton_SendInviteToPartner'))

			fillSAPBusinessRegistrationFormForSupplierOnboarding(companyCode,data)
		}catch(Exception e) {
			e.printStackTrace()
			KeywordUtil.markFailed("Exception occured while filling SAP Business registration form."+e.getLocalizedMessage())
		}
	}

	/**
	 * @author Vadisa Subramanyam
	 * @description : Method to fill third party risk management.
	 * @param data : data is set that contains data to fill in third part risk management.
	 */
	@Keyword
	def fillThirdPartyRiskManagement(HashMap<String,String> data) {
		try {

			WebUI.scrollToElement(findTestObject('Object Repository/BPConnect_InviteNewPartner/button_ThirdPartyRiskManagememt'), 100)
			String sapPulsIcon = WebUI.getAttribute(findTestObject('Object Repository/BPConnect_InviteNewPartner/button_ThirdPartyRiskManagememt'),"class").trim()
			if(!sapPulsIcon.contains("minus")) {
				WebUI.click(findTestObject('Object Repository/BPConnect_InviteNewPartner/button_ThirdPartyRiskManagememt'))
			}

			WebUI.selectOptionByLabel(findTestObject('Object Repository/BPConnect_InviteNewPartner/dropdown_EngagementType'),
					data.get("engagementType"), false)

			WebUI.delay(3)
			WebUI.selectOptionByLabel(findTestObject('Object Repository/BPConnect_InviteNewPartner/dropdown_ServiceCriteria'),data.get("serviceCriteria"), false)
			if(!data.get("serviceCriteria").trim().equalsIgnoreCase("None of the above")) {
				WebUI.selectOptionByLabel(findTestObject('BPConnect_InviteNewPartner/dropdown_GeoLocation'),data.get("geoLocation"), false)
				WebUI.selectOptionByLabel(findTestObject('BPConnect_InviteNewPartner/dropdown_AssesmentType'),data.get("assesmentType"), false)
				if(data.get("ddQuestionnaireFilledBy").trim().equalsIgnoreCase("Initiator")) {
					WebUI.click(findTestObject('BPConnect_InviteNewPartner/radioButton_Initiator'))
				}else {
					WebUI.click(findTestObject('BPConnect_InviteNewPartner/radioButton_ThirdParty'))
				}
			}
		}catch(Exception e) {
			e.printStackTrace()
			KeywordUtil.markFailed("Exception occured while filling third party risk management."+e.getLocalizedMessage())
		}
	}
	/**
	 * @author Vadisa Subramanyam
	 * @description : Method to click on invite partner button
	 */
	@Keyword
	def clickOnInvitePartner() {
		try {
			WebUI.click(findTestObject('BPConnect_InviteNewPartner/button_InvitePartner'))
		}catch(Exception e) {
			e.printStackTrace()
			KeywordUtil.markFailed("Exception occured while clicking on invite partner button"+e.getLocalizedMessage())
		}
	}

	/**
	 * @author Vadisa Subramanyam
	 * @description : Method to click on proceed button
	 */
	@Keyword
	def clickOnProceedButton(String companyCode) {
		try {
			String companyCodeVal = companyCode.trim().charAt(0)
			if(companyCodeVal.equals("1"))  {
				WebUI.delay(3)
				WebUI.click(findTestObject('Object Repository/BPConnect_InviteNewPartner/button_Proceed'))
			}
		}catch(Exception e) {
			e.printStackTrace()
			KeywordUtil.markFailed("Exception occured while clicking on proceed button"+e.getLocalizedMessage())
		}
	}

	/**
	 * @author Vadisa Subramanyam
	 * @description : Method to get request number.
	 */
	@Keyword
	def String getRequestNumber() {
		String requestNumber = null;
		try {
			WebUI.waitForElementVisible(findTestObject('Object Repository/BPConnect_SearchPage/object_GetServiceNumber'),100)
			WebUI.delay(3)
			requestNumber = WebUI.getText(findTestObject('BPConnect_SearchPage/object_GetServiceNumber')).replaceAll("[^0-9]", "")
			KeywordUtil.markPassed("Got request number - '"+requestNumber+"'")
			WebUI.takeFullPageScreenshot()
			WebUI.click(findTestObject('Object Repository/BPConnect_SearchPage/button_OK'))
			KeywordUtil.markPassed("Invited partner successfully")
		}catch(Exception e) {
			e.printStackTrace()
			KeywordUtil.markFailed("Exception occured while getting request number."+e.getLocalizedMessage())
		}
		return requestNumber.substring(0, 7)
	}

	/**
	 * @author Vadisa Subramanyam
	 * @description : Method to fill SAP Business registration.
	 * @param data : data is set that contains data to fill in address.
	 */
	@Keyword
	def fillSAPBusinessRegistrationFormAsSupplier(String companyCode,HashMap<String,String> data) {
		try {

			WebUI.scrollToElement(findTestObject('BPConnect_InviteNewPartner/button_SAPBusinessRegistrationFormIcon'), 100)
			String sapPulsIcon = WebUI.getAttribute(findTestObject('BPConnect_InviteNewPartner/button_SAPBusinessRegistrationFormIcon'),"class").trim()
			if(!sapPulsIcon.contains("minus")) {
				WebUI.click(findTestObject('BPConnect_InviteNewPartner/button_SAPBusinessRegistrationFormIcon'))
			}

			WebUI.waitForElementClickable(findTestObject('BPConnect_InviteNewPartner/radioButton_Supplier'), 100)
			WebUI.click(findTestObject('BPConnect_InviteNewPartner/radioButton_Supplier'))

			WebUI.waitForElementClickable(findTestObject('BPConnect_InviteNewPartner_2/radioButton_FillAllReqiuredDetails'), 100)
			WebUI.click(findTestObject('BPConnect_InviteNewPartner_2/radioButton_FillAllReqiuredDetails'))

			fillSAPBusinessRegistrationFormForSupplierOnboarding(companyCode,data)
		}catch(Exception e) {
			e.printStackTrace()
			KeywordUtil.markFailed("Exception occured while filling SAP Business registration form."+e.getLocalizedMessage())
		}
	}

	/**
	 * @author Vadisa Subramanyam
	 * @description : Method to fill address in on-boarding form.
	 * @param data : data is set that contains data to fill in address.
	 * @param companyCode : companyCode is string value that selected company code while creation.
	 */
	@Keyword
	def fillAddress(String companyCode,HashMap<String,String> data) {
		try {
			String companyCodeVal = companyCode.trim().charAt(0)
			WebUI.scrollToElement(findTestObject('Object Repository/BPConnect_InviteNewPartner_2/header_Address'), 100)
			String sapPulsIcon = WebUI.getAttribute(findTestObject('Object Repository/BPConnect_InviteNewPartner_2/header_Address'),"class").trim()
			if(!sapPulsIcon.contains("minus")) {
				WebUI.click(findTestObject('Object Repository/BPConnect_InviteNewPartner_2/header_Address'))
			}
			WebUI.selectOptionByLabel(findTestObject('BPConnect_InviteNewPartner_2/dropdown_Title'),data.get("title"), false)

			WebUI.setText(findTestObject('BPConnect_InviteNewPartner_2/textField_CompanyName'),
					data.get("companyName"))

			WebUI.setText(findTestObject('Object Repository/BPConnect_InviteNewPartner_2/textField_Name2'),
					data.get("name2"))

			WebUI.setText(findTestObject('Object Repository/BPConnect_InviteNewPartner_2/textField_SearchTerm'),
					data.get("searchTerm"))

			WebUI.setText(findTestObject('Object Repository/BPConnect_InviteNewPartner_2/textField_Street'),
					data.get("street"))

			WebUI.setText(findTestObject('Object Repository/BPConnect_InviteNewPartner_2/textField_Street1'),
					data.get("street1"))

			WebUI.setText(findTestObject('Object Repository/BPConnect_InviteNewPartner_2/textField_HouseNumber'),
					data.get("houseNumber"))


			WebUI.selectOptionByLabel(findTestObject('Object Repository/BPConnect_InviteNewPartner_2/dropdown_Country'),
					data.get("country"), false)


			WebUI.delay(8)

			WebUI.waitForElementVisible(findTestObject('Object Repository/BPConnect_InviteNewPartner_2/dropdown_State'), 100)

			WebUI.selectOptionByLabel(findTestObject('Object Repository/BPConnect_InviteNewPartner_2/dropdown_State'),
					data.get("state"), false)

			WebUI.setText(findTestObject('Object Repository/BPConnect_InviteNewPartner_2/textField_CityTown'),
					data.get("cityTown"))

			WebUI.setText(findTestObject('Object Repository/BPConnect_InviteNewPartner_2/textField_Room'),
					data.get("room"))

			WebUI.setText(findTestObject('Object Repository/BPConnect_InviteNewPartner_2/textField_Floor'),
					data.get("floor"))

			WebUI.setText(findTestObject('Object Repository/BPConnect_InviteNewPartner_2/textField_BuildingName'),data.get("buildingName"))

			if(companyCodeVal.equals("1")) {
				WebUI.setText(findTestObject('BPConnect_InviteNewPartner_2/textField_District'),data.get("district"))
			}

			WebUI.setText(findTestObject('Object Repository/BPConnect_InviteNewPartner_2/textField_ZipOrPostalCode'),data.get("zipOrPostalCode"))

			if(companyCodeVal.equals("2")) {
				WebUI.setText(findTestObject('Object Repository/BPConnect_InviteNewPartner_2/textField_FaxNumber'),data.get("faxNumber"))
			}
		}catch(Exception e) {
			e.printStackTrace()
			KeywordUtil.markFailed("Exception occured while filling address in on-boarding form."+e.getLocalizedMessage())
		}
	}
	/**
	 * @author Vadisa Subramanyam
	 * @description : Method to uplaod file.
	 * @param fileLocation : fileLocation is string value that location of file.
	 */
	@Keyword
	def uploadFile(String fileLocation) {
		try {
			Actions action = new Actions(driver);
			StringSelection str = new StringSelection(fileLocation)
			Toolkit.getDefaultToolkit().getSystemClipboard().setContents(str, null);
			WebUI.delay(9)
			Robot rb = new Robot();
			rb.keyPress(KeyEvent.VK_CONTROL);
			rb.keyPress(KeyEvent.VK_V);
			WebUI.delay(3)
			// release Contol+V for pasting
			rb.keyRelease(KeyEvent.VK_CONTROL);
			WebUI.delay(3)
			rb.keyRelease(KeyEvent.VK_V);
			WebUI.delay(3)
			// for pressing and releasing Enter
			rb.keyPress(KeyEvent.VK_ENTER);
			rb.keyRelease(KeyEvent.VK_ENTER);
			KeywordUtil.markPassed("Uplaod file is successful")
			WebUI.delay(3)
		}catch(Exception e) {
			e.printStackTrace()
			KeywordUtil.markFailed("Exception occured while filling tax details"+e.getLocalizedMessage())
		}
	}

	/**
	 * @author Vadisa Subramanyam
	 * @description : Method to add tax details.
	 * @param data : data is set that contains data to add tax details.
	 * @param taxDocWithExtension : taxDocWithExtension is String value that tax doc file name with extension.
	 */
	@Keyword
	def addBankDetails(HashMap<String,String> data,String taxDocWithExtension) {
		try {
			WebUI.click(findTestObject('Object Repository/BPConnect_InviteNewPartner_2/link_AddTaxDetails'))
			WebUI.delay(4)
			WebUI.waitForElementVisible(findTestObject('Object Repository/BPConnect_InviteNewPartner_2/dropdown_TaxCategory'), 100)
			WebUI.selectOptionByLabel(findTestObject('Object Repository/BPConnect_InviteNewPartner_2/dropdown_TaxCategory'),
					data.get("taxCategory"), false)
			WebUI.setText(findTestObject('Object Repository/BPConnect_InviteNewPartner_2/textField_INNumber'),
					data.get("innNumber"))
			WebUI.click(findTestObject('Object Repository/BPConnect_InviteNewPartner_2/button_Browse'))
			uploadFile(path+taxDocWithExtension)
			WebUI.click(findTestObject('Object Repository/BPConnect_InviteNewPartner_2/button_Save'))
		}catch(Exception e) {
			e.printStackTrace()
			KeywordUtil.markFailed("Exception occured while adding tax details."+e.getLocalizedMessage())
		}
	}


	/**
	 * @author Vadisa Subramanyam
	 * @description : Method to fill address in on-boarding form.
	 * @param companyCode : companyCode is string value that selected company code while creation.
	 * @param data : data is set that contains data to fill tax details.
	 * @param gstCertificateNameWithExtension : gstCertificateNameWithExtension is String value that gst certificate file name with extension.
	 * @param pancardFileNameWithExtension : pancardFileNameWithExtension is String value that pan card file name with extension.
	 * @param taxDocWithExtension : taxDocWithExtension is String value that tax doc file name with extension.
	 */
	@Keyword
	def fillTaxDetails(String companyCode,HashMap<String,String> data,String gstCertificateNameWithExtension,String pancardFileNameWithExtension,String taxDocWithExtension) {
		try {
			String taxType = data.get("taxType").trim()
			String companyCodeVal = companyCode.trim().charAt(0)

			WebUI.scrollToElement(findTestObject('Object Repository/BPConnect_InviteNewPartner_2/header_TaxDetails'), 100)
			String sapPulsIcon = WebUI.getAttribute(findTestObject('Object Repository/BPConnect_InviteNewPartner_2/header_TaxDetails'),"class").trim()
			if(!sapPulsIcon.contains("minus")) {
				WebUI.click(findTestObject('Object Repository/BPConnect_InviteNewPartner_2/header_TaxDetails'))
			}
			if(taxType.equalsIgnoreCase("Tax Registered")&& companyCodeVal.equals("1")) {
				WebUI.click(findTestObject('Object Repository/BPConnect_InviteNewPartner_2/radioButton_TaxRegistered'))
				WebUI.click(findTestObject('Object Repository/BPConnect_InviteNewPartner_2/button_UploadGSTCertificate'))
				WebUI.delay(2)
				WebUI.click(findTestObject('Object Repository/BPConnect_InviteNewPartner_2/button_Browse'))
				uploadFile(path+gstCertificateNameWithExtension)
				WebUI.click(findTestObject('Object Repository/BPConnect_InviteNewPartner_2/uploadedButton'))
				WebUI.waitForElementClickable(findTestObject('Object Repository/BPConnect_InviteNewPartner_2/button_UploadPAN'), 100)
				WebUI.click(findTestObject('Object Repository/BPConnect_InviteNewPartner_2/button_UploadPAN'))
				WebUI.delay(2)
				WebUI.click(findTestObject('Object Repository/BPConnect_InviteNewPartner_2/button_Browse'))
				uploadFile(path+pancardFileNameWithExtension)
				WebUI.click(findTestObject('Object Repository/BPConnect_InviteNewPartner_2/uploadedButton'))
				addBankDetails(data, taxDocWithExtension)
				WebUI.delay(3)
				WebUI.waitForElementVisible(findTestObject('Object Repository/BPConnect_InviteNewPartner_2/textField_PANNumber'), 100)
				WebUI.setText(findTestObject('Object Repository/BPConnect_InviteNewPartner_2/textField_PANNumber'), data.get("panNumber"))
				WebUI.setText(findTestObject('Object Repository/BPConnect_InviteNewPartner_2/textField_TradeName'),data.get("tradeName"))
				WebUI.setText(findTestObject('Object Repository/BPConnect_InviteNewPartner_2/textField_LegalName'),data.get("legalName"))
				if(data.get("gstType").trim().equalsIgnoreCase("Monthly")) {
					WebUI.click(findTestObject('Object Repository/BPConnect_InviteNewPartner_2/radioButton_MonthlyGST'))
				}else {
					WebUI.click(findTestObject('Object Repository/BPConnect_InviteNewPartner_2/radioButton_QuarterlyGST'))
				}
				WebUI.enableSmartWait()
				WebUI.delay(2)
				WebUI.click(findTestObject('Object Repository/BPConnect_InviteNewPartner_2/textField_ReEnterPAN'))
				WebUI.delay(2)
				WebUI.setText(findTestObject('Object Repository/BPConnect_InviteNewPartner_2/textField_ReEnterPAN'),data.get("reEnterPAN"))
				WebUI.disableSmartWait()
			}else if((!taxType.equalsIgnoreCase("Tax Registered"))&& companyCodeVal.equals("1")){
				WebUI.click(findTestObject('Object Repository/BPConnect_InviteNewPartner_2/radioButton_NonTaxRegistered'))
				WebUI.click(findTestObject('Object Repository/BPConnect_InviteNewPartner_2/button_UploadPAN'))
				WebUI.delay(2)
				WebUI.click(findTestObject('Object Repository/BPConnect_InviteNewPartner_2/button_Browse'))
				uploadFile(path+pancardFileNameWithExtension)
				WebUI.click(findTestObject('Object Repository/BPConnect_InviteNewPartner_2/uploadedButton'))
				WebUI.delay(2)
				addBankDetails(data, taxDocWithExtension)
				WebUI.delay(2)
				WebUI.enableSmartWait()
				WebUI.setText(findTestObject('Object Repository/BPConnect_InviteNewPartner_2/textField_PANNumber'), data.get("panNumber"))
				WebUI.click(findTestObject('Object Repository/BPConnect_InviteNewPartner_2/textField_ReEnterPAN'))
				WebUI.setText(findTestObject('Object Repository/BPConnect_InviteNewPartner_2/textField_ReEnterPAN'),data.get("reEnterPAN"))
				WebUI.disableSmartWait()
			}else if(companyCodeVal.equals("3")){
				if(taxType.equalsIgnoreCase("Tax Registered") ) {
					WebUI.click(findTestObject('Object Repository/BPConnect_InviteNewPartner_2/radioButton_TaxRegistered'))
				}else if(!taxType.trim().equalsIgnoreCase("Tax Registered")) {
					WebUI.click(findTestObject('Object Repository/BPConnect_InviteNewPartner_2/radioButton_NonTaxRegistered'))
				}
				addBankDetails(data, taxDocWithExtension)
				WebUI.delay(3)
				WebUI.waitForElementVisible(findTestObject('Object Repository/BPConnect_InviteNewPartner_2/textField_CompanyRegistration'), 100)
				WebUI.setText(findTestObject('Object Repository/BPConnect_InviteNewPartner_2/textField_CompanyRegistration'), data.get("companyRegistration"))
			}else if(companyCodeVal.equals("2") || companyCodeVal.equals("4") || companyCodeVal.equals("5")) {
				if(taxType.equalsIgnoreCase("Tax Registered") ) {
					WebUI.click(findTestObject('Object Repository/BPConnect_InviteNewPartner_2/radioButton_TaxRegistered'))
				}else if(!data.get("taxType").trim().equalsIgnoreCase("Tax Registered")) {
					WebUI.click(findTestObject('Object Repository/BPConnect_InviteNewPartner_2/radioButton_NonTaxRegistered'))
				}
				addBankDetails(data, taxDocWithExtension)
			}
		}catch(Exception e) {
			e.printStackTrace()
			KeywordUtil.markFailed("Exception occured while filling tax details"+e.getLocalizedMessage())
		}
	}

	/**
	 * @author Vadisa Subramanyam
	 * @description : Method to click on purchase organization.
	 * @param purOrganization : purOrganization is string value that name of purchase organization.
	 */
	@Keyword
	def clickOnPurchaseOrganization(String purOrganization) {
		try {
			String xpath = '//ul[@class="multiselect-container dropdown-menu pull-right"]//li//label[contains(text(),"'+purOrganization+'")]//input'
			TestObject to = new TestObject("objectName")
			to.addProperty("xpath", ConditionType.EQUALS, xpath)
			WebUI.delay(2)
			WebUI.click(to)
		}catch(Exception e) {
			e.printStackTrace()
			KeywordUtil.markFailed("Exception occured while clicking on purchse organization."+e.getLocalizedMessage())
		}
	}
}
