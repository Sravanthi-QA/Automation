package pages

import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.checkpoint.Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testcase.TestCase
import com.kms.katalon.core.testdata.TestData
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import com.kms.katalon.core.webui.driver.DriverFactory
import commonKeywords.ApplicationKeywords
import org.openqa.selenium.WebElement
import org.openqa.selenium.WebDriver
import org.openqa.selenium.By
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords
import com.kms.katalon.core.util.KeywordUtil
import com.kms.katalon.core.mobile.keyword.internal.MobileDriverFactory

import internal.GlobalVariable

public class LoginPage extends ApplicationKeywords{

	LoginPage(){
		driver = DriverFactory.getWebDriver()
	}

	/**
	 * @author Vadisa Subramanyam
	 * @description : This method is used to log in as initiator.
	 * @param userName : userName is string value that  user id of initiator
	 * @param password : password is string value that password of initiator
	 */
	@Keyword
	def employeeSignin(String userName,String password) {
		try {
			WebUI.click(findTestObject('Object Repository/BPConnect_LoginPage/button_EmployeeSignin'))
			TestObject userNameTextField = findTestObject('Object Repository/Sign in to teams account/txt_UserName')
			if(isDisplayed(userNameTextField)) {
				WebUI.setText(userNameTextField, userName)
				WebUI.click(findTestObject('Object Repository/Sign in to teams account/button_SignIn'))
				WebUI.delay(3)
				WebUI.waitForElementVisible(findTestObject('Object Repository/Sign in to teams account/txt_Password'), 100)
				WebUI.setText(findTestObject('Object Repository/Sign in to teams account/txt_Password'), password)
				WebUI.click(findTestObject('Object Repository/Sign in to teams account/button_SignIn'))
				WebUI.delay(2)
				TestObject staySigninYesButton = findTestObject('Object Repository/BPConnect_LoginPage/button_StaySignin')
				if(isDisplayed(staySigninYesButton)) {
					WebUI.click(staySigninYesButton)
				}
				WebUI.delay(3)
				TestObject findPartnerButton = findTestObject('Object Repository/BPConnect_AdminHomePage/button_FindPartner')
				WebUI.waitForElementVisible(findPartnerButton, 100)
				if(isDisplayed(findPartnerButton)) {
					KeywordUtil.markPassed("Employee sign in successful")
				}
			}
		}catch(Exception e) {
			e.printStackTrace()
			KeywordUtil.markFailed("Exception occured while log in as initiator."+e.getLocalizedMessage())
		}
	}
}
