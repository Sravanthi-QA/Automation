package pages

import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.checkpoint.Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testcase.TestCase
import com.kms.katalon.core.testdata.TestData
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import com.kms.katalon.core.webui.driver.DriverFactory
import commonKeywords.ApplicationKeywords
import org.openqa.selenium.WebElement
import org.openqa.selenium.WebDriver
import org.openqa.selenium.By
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords
import com.kms.katalon.core.util.KeywordUtil
import com.kms.katalon.core.mobile.keyword.internal.MobileDriverFactory
import internal.GlobalVariable
import org.openqa.selenium.Keys;
import com.kms.katalon.core.testobject.ConditionType

public class AdminHomePage extends ApplicationKeywords{

	AdminHomePage(){
		driver = DriverFactory.getWebDriver()
	}


	/**
	 * @author Vadisa Subramanyam
	 * @description : Method to click on find partner button.
	 */
	@Keyword
	def clickOnFindPartnerButton() {
		try {
			WebUI.waitForElementClickable(findTestObject('BPConnect_AdminHomePage/button_FindPartner'), 100)
			WebUI.click(findTestObject('BPConnect_AdminHomePage/button_FindPartner'))
		}catch(Exception e) {
			e.printStackTrace()
			KeywordUtil.markFailed("Exception occured while clicking on find parner button"+e.getLocalizedMessage())
		}
	}

	/**
	 * @author Vadisa Subramanyam
	 * @description : Method to open approval portal by L1 using request ID.
	 * @param requestID : requestID is string value that request id.
	 */
	@Keyword
	def openApprovalPortalByL1UsingRequestID(String requestID) {
		String xpath = '(//table//tbody//*[text()="' +requestID+'"])[1]'
		TestObject to = new TestObject("objectName")
		to.addProperty("xpath", ConditionType.EQUALS, xpath)
		WebUI.waitForPageLoad(1000)

		try {
			try {
				WebUI.waitForPageLoad(1000)
				WebUI.click(findTestObject('Object Repository/BPConnect_InviteNewPartner/button_Vendor'))
				WebUI.delay(2)
				WebUI.setText(findTestObject('Object Repository/BPConnect_InviteNewPartner/textField_MDMTextField'), requestID)
				WebUI.delay(2)
				WebUI.scrollToElement(to, 100)
				WebUI.delay(2)
				WebUI.doubleClick(to)
			}catch(Exception e) {
				WebUI.delay(3)
				WebUI.waitForPageLoad(100)
				WebUI.waitForElementVisible(findTestObject('Object Repository/BPConnect_AdminHomePage/link_Customer'), 100)
				WebUI.click(findTestObject('Object Repository/BPConnect_AdminHomePage/link_Customer'))
				WebUI.delay(2)
				WebUI.setText(findTestObject('Object Repository/BPConnect_InviteNewPartner/textField_MDMTextField'), requestID)
				WebUI.delay(2)
				WebUI.scrollToElement(to, 100)
				WebUI.delay(2)
				WebUI.doubleClick(to)
			}
		}catch(Exception e) {
			e.printStackTrace()
			KeywordUtil.markFailed("Exception occured while opening approval portal by L1 using request ID."+e.getLocalizedMessage())
		}
	}

	/**
	 * @author Vadisa Subramanyam
	 * @description : Method to click on find partner button.
	 */
	@Keyword
	def getTextByColumnName() {
		int columnNumer = 0
		try {
			String str = "Contract Awarded"
			String vendorName = "AvKARE"
			String xpathStr = "//div[contains(@class,'header-block align-items-start')]//p"
			List<WebElement> columns = driver.findElements(By.xpath(xpathStr))
			for(int i=0;i<columns.size();i++) {
				String columnVal = columns.get(i).getText().trim()
				if(columnVal.trim().equalsIgnoreCase(str)) {
					println(columnVal)
					columnNumer = i
					break
				}
			}

			String xpathStr2 = '//p[text()="' +vendorName+'"]//..//..//.//..//p'
			List<WebElement> rowCol = driver.findElements(By.xpath(xpathStr2))
			String columnVal2 = rowCol.get(columnNumer).getText().trim()
			println(columnVal2)
		}catch(Exception e) {
			e.printStackTrace()
			KeywordUtil.markFailed("Exception occured while clicking on find parner button"+e.getLocalizedMessage())
		}
	}
}
