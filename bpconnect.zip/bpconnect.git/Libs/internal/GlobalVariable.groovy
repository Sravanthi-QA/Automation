package internal

import com.kms.katalon.core.configuration.RunConfiguration
import com.kms.katalon.core.main.TestCaseMain


/**
 * This class is generated automatically by Katalon Studio and should not be modified or deleted.
 */
public class GlobalVariable {
     
    /**
     * <p></p>
     */
    public static Object BPConnectURL
     
    /**
     * <p></p>
     */
    public static Object employeeUserName
     
    /**
     * <p></p>
     */
    public static Object employeePassword
     
    /**
     * <p></p>
     */
    public static Object companyCode1s
     
    /**
     * <p></p>
     */
    public static Object typeOfPartner
     
    /**
     * <p></p>
     */
    public static Object partnersCatagory
     
    /**
     * <p></p>
     */
    public static Object accountGroup
     
    /**
     * <p></p>
     */
    public static Object partnersEmailId
     
    /**
     * <p></p>
     */
    public static Object spocEmailID
     
    /**
     * <p></p>
     */
    public static Object partnersMobileNumber
     
    /**
     * <p></p>
     */
    public static Object businessPartnersName
     
    /**
     * <p></p>
     */
    public static Object supplierType
     
    /**
     * <p></p>
     */
    public static Object natureOfService
     
    /**
     * <p></p>
     */
    public static Object briefDescriptionOfServies
     
    /**
     * <p></p>
     */
    public static Object engagementType
     
    /**
     * <p></p>
     */
    public static Object serviceCriteria
     
    /**
     * <p></p>
     */
    public static Object geoLocation
     
    /**
     * <p></p>
     */
    public static Object assesmentType
     
    /**
     * <p></p>
     */
    public static Object ddQuestionnaireFilledBy
     
    /**
     * <p></p>
     */
    public static Object title
     
    /**
     * <p></p>
     */
    public static Object companyName
     
    /**
     * <p></p>
     */
    public static Object name2
     
    /**
     * <p></p>
     */
    public static Object searchTerm
     
    /**
     * <p></p>
     */
    public static Object street
     
    /**
     * <p></p>
     */
    public static Object street1
     
    /**
     * <p></p>
     */
    public static Object houseNumber
     
    /**
     * <p></p>
     */
    public static Object country
     
    /**
     * <p></p>
     */
    public static Object state
     
    /**
     * <p></p>
     */
    public static Object cityTown
     
    /**
     * <p></p>
     */
    public static Object room
     
    /**
     * <p></p>
     */
    public static Object floor
     
    /**
     * <p></p>
     */
    public static Object buildingName
     
    /**
     * <p></p>
     */
    public static Object district
     
    /**
     * <p></p>
     */
    public static Object zipOrPostalCode
     
    /**
     * <p></p>
     */
    public static Object taxType
     
    /**
     * <p></p>
     */
    public static Object taxCategory
     
    /**
     * <p></p>
     */
    public static Object innNumber
     
    /**
     * <p></p>
     */
    public static Object panNumber
     
    /**
     * <p></p>
     */
    public static Object tradeName
     
    /**
     * <p></p>
     */
    public static Object legalName
     
    /**
     * <p></p>
     */
    public static Object gstType
     
    /**
     * <p></p>
     */
    public static Object reEnterPAN
     
    /**
     * <p></p>
     */
    public static Object gstCertificateNameWithExtension
     
    /**
     * <p></p>
     */
    public static Object pancardFileNameWithExtension
     
    /**
     * <p></p>
     */
    public static Object taxDocWithExtension
     
    /**
     * <p></p>
     */
    public static Object faxNumber
     
    /**
     * <p></p>
     */
    public static Object companyRegistration
     
    /**
     * <p></p>
     */
    public static Object customerName
     
    /**
     * <p></p>
     */
    public static Object role
     
    /**
     * <p></p>
     */
    public static Object customerEmail
     
    /**
     * <p></p>
     */
    public static Object customerMobileNumber
     
    /**
     * <p></p>
     */
    public static Object department
     
    /**
     * <p></p>
     */
    public static Object paymentTerms
     
    /**
     * <p></p>
     */
    public static Object paymentMethod1s
     
    /**
     * <p></p>
     */
    public static Object cancelCheqWithExtension
     
    /**
     * <p></p>
     */
    public static Object bankCountry
     
    /**
     * <p></p>
     */
    public static Object bankRegion
     
    /**
     * <p></p>
     */
    public static Object bankAccountNumber
     
    /**
     * <p></p>
     */
    public static Object bankName
     
    /**
     * <p></p>
     */
    public static Object bankBranch
     
    /**
     * <p></p>
     */
    public static Object city
     
    /**
     * <p></p>
     */
    public static Object bankStreet
     
    /**
     * <p></p>
     */
    public static Object swiftBICNumber
     
    /**
     * <p></p>
     */
    public static Object ibanNumber
     
    /**
     * <p></p>
     */
    public static Object ifscCode
     
    /**
     * <p></p>
     */
    public static Object reEnterIFSCCode
     
    /**
     * <p></p>
     */
    public static Object bankKey
     
    /**
     * <p></p>
     */
    public static Object bankRoutingNumber3S
     
    /**
     * <p></p>
     */
    public static Object bankRoutingNumber
     
    /**
     * <p></p>
     */
    public static Object contactNameOfBank
     
    /**
     * <p></p>
     */
    public static Object contactNumberOfBank
     
    /**
     * <p></p>
     */
    public static Object bankCtry
     
    /**
     * <p></p>
     */
    public static Object sortCode
     
    /**
     * <p></p>
     */
    public static Object reEnterSwiftBICNumber
     
    /**
     * <p></p>
     */
    public static Object reEnterIBANNumber
     
    /**
     * <p></p>
     */
    public static Object reEnterbankAccountNumber
     
    /**
     * <p></p>
     */
    public static Object id
     
    /**
     * <p></p>
     */
    public static Object purchaseOrganization
     
    /**
     * <p></p>
     */
    public static Object orderCurency
     
    /**
     * <p></p>
     */
    public static Object reconAccount
     
    /**
     * <p></p>
     */
    public static Object schemaGroup
     
    /**
     * <p></p>
     */
    public static Object autorizationGroup
     
    /**
     * <p></p>
     */
    public static Object corporateGroup
     
    /**
     * <p></p>
     */
    public static Object incoterms
     
    /**
     * <p></p>
     */
    public static Object incotermsLocation1
     
    /**
     * <p></p>
     */
    public static Object minorityIndicator
     
    /**
     * <p></p>
     */
    public static Object mobileNumber
     
    /**
     * <p></p>
     */
    public static Object email
     
    /**
     * <p></p>
     */
    public static Object paymentMethod2
     
    /**
     * <p></p>
     */
    public static Object otherOttachmentsDocument
     
    /**
     * <p></p>
     */
    public static Object ssiBPCondition
     
    /**
     * <p></p>
     */
    public static Object ssiCerWithEx
     
    /**
     * <p></p>
     */
    public static Object caCerWithEx
     
    /**
     * <p></p>
     */
    public static Object selfDecCerWithEx
     
    /**
     * <p></p>
     */
    public static Object sezCondition
     
    /**
     * <p></p>
     */
    public static Object sezCerWithEx
     
    /**
     * <p></p>
     */
    public static Object sezValueFrom
     
    /**
     * <p></p>
     */
    public static Object sezValueUpto
     
    /**
     * <p></p>
     */
    public static Object reverseChargeCondition
     
    /**
     * <p></p>
     */
    public static Object rptStatus
     
    /**
     * <p></p>
     */
    public static Object relatedEmployeeCode
     
    /**
     * <p></p>
     */
    public static Object relatedName
     
    /**
     * <p></p>
     */
    public static Object relatedDesignation
     
    /**
     * <p></p>
     */
    public static Object relatedJoiningDate
     
    /**
     * <p></p>
     */
    public static Object relatedToDRLLab
     
    /**
     * <p></p>
     */
    public static Object consentFormWithEx
     
    /**
     * <p></p>
     */
    public static Object applicability1099Condition
     
    /**
     * <p></p>
     */
    public static Object poBox
     
    /**
     * <p></p>
     */
    public static Object postalCodePoBox
     
    /**
     * <p></p>
     */
    public static Object nationalProviderIdentifier
     
    /**
     * <p></p>
     */
    public static Object stateLicenseNumber
     
    /**
     * <p></p>
     */
    public static Object nameOfStateInLicense
     
    /**
     * <p></p>
     */
    public static Object hcpOrHCOCondition
     
    /**
     * <p></p>
     */
    public static Object companyCode2Series
     
    /**
     * <p></p>
     */
    public static Object paymentTerms2Series
     
    /**
     * <p></p>
     */
    public static Object paymentMethod2Series
     
    /**
     * <p></p>
     */
    public static Object comment
     
    /**
     * <p></p>
     */
    public static Object companyCode3s
     
    /**
     * <p></p>
     */
    public static Object paymentMethod3s
     
    /**
     * <p></p>
     */
    public static Object companyCode4s
     
    /**
     * <p></p>
     */
    public static Object paymentMethod4s
     
    /**
     * <p></p>
     */
    public static Object companyCode5s
     
    /**
     * <p></p>
     */
    public static Object paymentMethod5s
     
    /**
     * <p></p>
     */
    public static Object companyCode1010
     
    /**
     * <p></p>
     */
    public static Object companyCode3028
     
    /**
     * <p></p>
     */
    public static Object materialSupplierType
     
    /**
     * <p></p>
     */
    public static Object importPartnerType
     
    /**
     * <p></p>
     */
    public static Object NoSSI
     
    /**
     * <p></p>
     */
    public static Object paymentMethod3028
     
    /**
     * <p></p>
     */
    public static Object ediCustomerTypeCondition
     
    /**
     * <p></p>
     */
    public static Object locationCode
     
    /**
     * <p></p>
     */
    public static Object foodLicenseNumber
     
    /**
     * <p></p>
     */
    public static Object foodLicenseValidFrom
     
    /**
     * <p></p>
     */
    public static Object customerVATStatus
     
    /**
     * <p></p>
     */
    public static Object drugLicense
     
    /**
     * <p></p>
     */
    public static Object drugLicenseNumber20B
     
    /**
     * <p></p>
     */
    public static Object drugLicenseNumber21B
     
    /**
     * <p></p>
     */
    public static Object drugLicenseValidFrom
     
    /**
     * <p></p>
     */
    public static Object drugLicenseValidTo
     
    /**
     * <p></p>
     */
    public static Object foodLicense
     
    /**
     * <p></p>
     */
    public static Object foodLicenseValidTo
     
    /**
     * <p></p>
     */
    public static Object narcoticLicenseNumber
     
    /**
     * <p></p>
     */
    public static Object narcoticLicenseValidFrom
     
    /**
     * <p></p>
     */
    public static Object validFrom
     
    /**
     * <p></p>
     */
    public static Object daLicenseNumber
     
    /**
     * <p></p>
     */
    public static Object validUpto
     
    /**
     * <p></p>
     */
    public static Object daLicenseClass
     
    /**
     * <p></p>
     */
    public static Object taxIDNumber
     
    /**
     * <p></p>
     */
    public static Object dUNSNumber
     
    /**
     * <p></p>
     */
    public static Object accountGroup2
     
    /**
     * <p></p>
     */
    public static Object l1UserName
     
    /**
     * <p></p>
     */
    public static Object l1Password
     
    /**
     * <p></p>
     */
    public static Object taxationUserName
     
    /**
     * <p></p>
     */
    public static Object taxationPassword
     
    /**
     * <p></p>
     */
    public static Object tdsUserName
     
    /**
     * <p></p>
     */
    public static Object tdsPassword
     
    /**
     * <p></p>
     */
    public static Object gbsUsername
     
    /**
     * <p></p>
     */
    public static Object gbsPassword
     
    /**
     * <p></p>
     */
    public static Object financeUsername
     
    /**
     * <p></p>
     */
    public static Object financePassword
     
    /**
     * <p></p>
     */
    public static Object financeSpocUsername
     
    /**
     * <p></p>
     */
    public static Object financeSpocPassword
     
    /**
     * <p></p>
     */
    public static Object financeHeadUsername
     
    /**
     * <p></p>
     */
    public static Object financeheadPassword
     
    /**
     * <p></p>
     */
    public static Object genpactUsername
     
    /**
     * <p></p>
     */
    public static Object genpactPassword
     
    /**
     * <p></p>
     */
    public static Object qaUsername
     
    /**
     * <p></p>
     */
    public static Object qaPassword
     
    /**
     * <p></p>
     */
    public static Object naghoUsername
     
    /**
     * <p></p>
     */
    public static Object naghoPassword
     
    /**
     * <p></p>
     */
    public static Object mdmUserName
     
    /**
     * <p></p>
     */
    public static Object mdmPassword
     
    /**
     * <p></p>
     */
    public static Object bankRoutingNumber5S
     
    /**
     * <p></p>
     */
    public static Object serviceSupplierType
     
    /**
     * <p></p>
     */
    public static Object companyCode3028s
     
    /**
     * <p></p>
     */
    public static Object paymentMethod3028s
     
    /**
     * <p></p>
     */
    public static Object yesSSIBPCondition
     
    /**
     * <p></p>
     */
    public static Object partnerEmailInvite
     
    /**
     * <p></p>
     */
    public static Object demoEmailPassword
     
    /**
     * <p></p>
     */
    public static Object companyCodeFieldName
     
    /**
     * <p></p>
     */
    public static Object comapanyCodeFieldValue
     
    /**
     * <p></p>
     */
    public static Object statusValue
     
    /**
     * <p></p>
     */
    public static Object statusFieldName
     
    /**
     * <p></p>
     */
    public static Object supplierCodeFieldName
     
    /**
     * <p></p>
     */
    public static Object supplierCodeFieldValue
     
    /**
     * <p></p>
     */
    public static Object customerCodeFieldName
     
    /**
     * <p></p>
     */
    public static Object customerCodeFieldValue
     
    /**
     * <p></p>
     */
    public static Object requestNumberFieldName
     
    /**
     * <p></p>
     */
    public static Object requestNumberFieldValue
     
    /**
     * <p></p>
     */
    public static Object customerAccountGroup
     
    /**
     * <p></p>
     */
    public static Object salesOrganisation
     
    /**
     * <p></p>
     */
    public static Object supplierVendorCode
     
    /**
     * <p></p>
     */
    public static Object extensionPurchaseOrg
     
    /**
     * <p></p>
     */
    public static Object ext1SeriesCompCode
     
    /**
     * <p></p>
     */
    public static Object ext1SeriesEmail
     
    /**
     * <p></p>
     */
    public static Object ext1SeriesPartnerType
     
    /**
     * <p></p>
     */
    public static Object ext1SeriesNatureOfService
     
    /**
     * <p></p>
     */
    public static Object ext1SeriesBriefDescription
     
    /**
     * <p></p>
     */
    public static Object ext1SeriesPaymentMethod
     
    /**
     * <p></p>
     */
    public static Object ext1SeriesPurchaseOrganization
     
    /**
     * <p></p>
     */
    public static Object ext1SeriesOrderCurrency
     
    /**
     * <p></p>
     */
    public static Object ext1SeriesReconAccount
     
    /**
     * <p></p>
     */
    public static Object ext1SeriesSchemaGroup
     
    /**
     * <p></p>
     */
    public static Object ext1SeriesAutorizationGroup
     
    /**
     * <p></p>
     */
    public static Object ext1SeriesCorporateGroup
     
    /**
     * <p></p>
     */
    public static Object ext1SeriesIncoterms
     
    /**
     * <p></p>
     */
    public static Object ext1SeriesIncotermsLocation1
     
    /**
     * <p></p>
     */
    public static Object ext1SeriesComment
     
    /**
     * <p></p>
     */
    public static Object ext2SeriesCompCode
     
    /**
     * <p></p>
     */
    public static Object ext2SeriesEmail
     
    /**
     * <p></p>
     */
    public static Object ext2SeriesPartnerType
     
    /**
     * <p></p>
     */
    public static Object ext2SeriesNatureOfService
     
    /**
     * <p></p>
     */
    public static Object ext2SeriesBriefDescription
     
    /**
     * <p></p>
     */
    public static Object ext2SeriesPaymentMethod
     
    /**
     * <p></p>
     */
    public static Object ext2SeriesPurchaseOrganization
     
    /**
     * <p></p>
     */
    public static Object ext2SeriesOrderCurrency
     
    /**
     * <p></p>
     */
    public static Object ext2SeriesReconAccount
     
    /**
     * <p></p>
     */
    public static Object ext2SeriesSchemaGroup
     
    /**
     * <p></p>
     */
    public static Object ext2SeriesAutorizationGroup
     
    /**
     * <p></p>
     */
    public static Object ext2SeriesCorporateGroup
     
    /**
     * <p></p>
     */
    public static Object ext2SeriesIncoterms
     
    /**
     * <p></p>
     */
    public static Object ext2SeriesIncotermsLocation1
     
    /**
     * <p></p>
     */
    public static Object ext2SeriesComment
     
    /**
     * <p></p>
     */
    public static Object ext3SeriesCompCode
     
    /**
     * <p></p>
     */
    public static Object ext3SeriesEmail
     
    /**
     * <p></p>
     */
    public static Object ext3SeriesPartnerType
     
    /**
     * <p></p>
     */
    public static Object ext3SeriesNatureOfService
     
    /**
     * <p></p>
     */
    public static Object ext3SeriesBriefDescription
     
    /**
     * <p></p>
     */
    public static Object ext3SeriesPaymentMethod
     
    /**
     * <p></p>
     */
    public static Object ext3SeriesPurchaseOrganization
     
    /**
     * <p></p>
     */
    public static Object ext3SeriesOrderCurrency
     
    /**
     * <p></p>
     */
    public static Object ext3SeriesReconAccount
     
    /**
     * <p></p>
     */
    public static Object ext3SeriesSchemaGroup
     
    /**
     * <p></p>
     */
    public static Object ext3SeriesAutorizationGroup
     
    /**
     * <p></p>
     */
    public static Object ext3SeriesCorporateGroup
     
    /**
     * <p></p>
     */
    public static Object ext3SeriesIncoterms
     
    /**
     * <p></p>
     */
    public static Object ext3SeriesIncotermsLocation1
     
    /**
     * <p></p>
     */
    public static Object ext3SeriesComment
     
    /**
     * <p></p>
     */
    public static Object ext4SeriesCompCode
     
    /**
     * <p></p>
     */
    public static Object ext4SeriesEmail
     
    /**
     * <p></p>
     */
    public static Object ext4SeriesPartnerType
     
    /**
     * <p></p>
     */
    public static Object ext4SeriesNatureOfService
     
    /**
     * <p></p>
     */
    public static Object ext4SeriesBriefDescription
     
    /**
     * <p></p>
     */
    public static Object ext4SeriesPaymentMethod
     
    /**
     * <p></p>
     */
    public static Object ext4SeriesPurchaseOrganization
     
    /**
     * <p></p>
     */
    public static Object ext4SeriesOrderCurrency
     
    /**
     * <p></p>
     */
    public static Object ext4SeriesReconAccount
     
    /**
     * <p></p>
     */
    public static Object ext4SeriesSchemaGroup
     
    /**
     * <p></p>
     */
    public static Object ext4SeriesAutorizationGroup
     
    /**
     * <p></p>
     */
    public static Object ext4SeriesCorporateGroup
     
    /**
     * <p></p>
     */
    public static Object ext4SeriesIncoterms
     
    /**
     * <p></p>
     */
    public static Object ext4SeriesIncotermsLocation1
     
    /**
     * <p></p>
     */
    public static Object ext4SeriesComment
     
    /**
     * <p></p>
     */
    public static Object ext5SeriesCompCode
     
    /**
     * <p></p>
     */
    public static Object ext5SeriesEmail
     
    /**
     * <p></p>
     */
    public static Object ext5SeriesPartnerType
     
    /**
     * <p></p>
     */
    public static Object ext5SeriesNatureOfService
     
    /**
     * <p></p>
     */
    public static Object ext5SeriesBriefDescription
     
    /**
     * <p></p>
     */
    public static Object ext5SeriesPaymentMethod
     
    /**
     * <p></p>
     */
    public static Object ext5SeriesPurchaseOrganization
     
    /**
     * <p></p>
     */
    public static Object ext5SeriesOrderCurrency
     
    /**
     * <p></p>
     */
    public static Object ext5SeriesReconAccount
     
    /**
     * <p></p>
     */
    public static Object ext5SeriesSchemaGroup
     
    /**
     * <p></p>
     */
    public static Object ext5SeriesAutorizationGroup
     
    /**
     * <p></p>
     */
    public static Object ext5SeriesCorporateGroup
     
    /**
     * <p></p>
     */
    public static Object ext5SeriesIncoterms
     
    /**
     * <p></p>
     */
    public static Object ext5SeriesIncotermsLocation1
     
    /**
     * <p></p>
     */
    public static Object ext5SeriesComment
     
    /**
     * <p></p>
     */
    public static Object ext3028SeriesCompCode
     
    /**
     * <p></p>
     */
    public static Object ext3028SeriesEmail
     
    /**
     * <p></p>
     */
    public static Object ext3028SeriesPartnerType
     
    /**
     * <p></p>
     */
    public static Object ext3028SeriesNatureOfService
     
    /**
     * <p></p>
     */
    public static Object ext3028SeriesBriefDescription
     
    /**
     * <p></p>
     */
    public static Object ext3028SeriesPaymentMethod
     
    /**
     * <p></p>
     */
    public static Object ext3028SeriesPurchaseOrganization
     
    /**
     * <p></p>
     */
    public static Object ext3028SeriesOrderCurrency
     
    /**
     * <p></p>
     */
    public static Object ext3028SeriesReconAccount
     
    /**
     * <p></p>
     */
    public static Object ext3028SeriesSchemaGroup
     
    /**
     * <p></p>
     */
    public static Object ext3028SeriesAutorizationGroup
     
    /**
     * <p></p>
     */
    public static Object ext3028SeriesCorporateGroup
     
    /**
     * <p></p>
     */
    public static Object ext3028SeriesIncoterms
     
    /**
     * <p></p>
     */
    public static Object ext3028SeriesIncotermsLocation1
     
    /**
     * <p></p>
     */
    public static Object ext3028SeriesComment
     

    static {
        try {
            def selectedVariables = TestCaseMain.getGlobalVariables("default")
			selectedVariables += TestCaseMain.getGlobalVariables(RunConfiguration.getExecutionProfile())
            selectedVariables += TestCaseMain.getParsedValues(RunConfiguration.getOverridingParameters(), selectedVariables)
    
            BPConnectURL = selectedVariables['BPConnectURL']
            employeeUserName = selectedVariables['employeeUserName']
            employeePassword = selectedVariables['employeePassword']
            companyCode1s = selectedVariables['companyCode1s']
            typeOfPartner = selectedVariables['typeOfPartner']
            partnersCatagory = selectedVariables['partnersCatagory']
            accountGroup = selectedVariables['accountGroup']
            partnersEmailId = selectedVariables['partnersEmailId']
            spocEmailID = selectedVariables['spocEmailID']
            partnersMobileNumber = selectedVariables['partnersMobileNumber']
            businessPartnersName = selectedVariables['businessPartnersName']
            supplierType = selectedVariables['supplierType']
            natureOfService = selectedVariables['natureOfService']
            briefDescriptionOfServies = selectedVariables['briefDescriptionOfServies']
            engagementType = selectedVariables['engagementType']
            serviceCriteria = selectedVariables['serviceCriteria']
            geoLocation = selectedVariables['geoLocation']
            assesmentType = selectedVariables['assesmentType']
            ddQuestionnaireFilledBy = selectedVariables['ddQuestionnaireFilledBy']
            title = selectedVariables['title']
            companyName = selectedVariables['companyName']
            name2 = selectedVariables['name2']
            searchTerm = selectedVariables['searchTerm']
            street = selectedVariables['street']
            street1 = selectedVariables['street1']
            houseNumber = selectedVariables['houseNumber']
            country = selectedVariables['country']
            state = selectedVariables['state']
            cityTown = selectedVariables['cityTown']
            room = selectedVariables['room']
            floor = selectedVariables['floor']
            buildingName = selectedVariables['buildingName']
            district = selectedVariables['district']
            zipOrPostalCode = selectedVariables['zipOrPostalCode']
            taxType = selectedVariables['taxType']
            taxCategory = selectedVariables['taxCategory']
            innNumber = selectedVariables['innNumber']
            panNumber = selectedVariables['panNumber']
            tradeName = selectedVariables['tradeName']
            legalName = selectedVariables['legalName']
            gstType = selectedVariables['gstType']
            reEnterPAN = selectedVariables['reEnterPAN']
            gstCertificateNameWithExtension = selectedVariables['gstCertificateNameWithExtension']
            pancardFileNameWithExtension = selectedVariables['pancardFileNameWithExtension']
            taxDocWithExtension = selectedVariables['taxDocWithExtension']
            faxNumber = selectedVariables['faxNumber']
            companyRegistration = selectedVariables['companyRegistration']
            customerName = selectedVariables['customerName']
            role = selectedVariables['role']
            customerEmail = selectedVariables['customerEmail']
            customerMobileNumber = selectedVariables['customerMobileNumber']
            department = selectedVariables['department']
            paymentTerms = selectedVariables['paymentTerms']
            paymentMethod1s = selectedVariables['paymentMethod1s']
            cancelCheqWithExtension = selectedVariables['cancelCheqWithExtension']
            bankCountry = selectedVariables['bankCountry']
            bankRegion = selectedVariables['bankRegion']
            bankAccountNumber = selectedVariables['bankAccountNumber']
            bankName = selectedVariables['bankName']
            bankBranch = selectedVariables['bankBranch']
            city = selectedVariables['city']
            bankStreet = selectedVariables['bankStreet']
            swiftBICNumber = selectedVariables['swiftBICNumber']
            ibanNumber = selectedVariables['ibanNumber']
            ifscCode = selectedVariables['ifscCode']
            reEnterIFSCCode = selectedVariables['reEnterIFSCCode']
            bankKey = selectedVariables['bankKey']
            bankRoutingNumber3S = selectedVariables['bankRoutingNumber3S']
            bankRoutingNumber = selectedVariables['bankRoutingNumber']
            contactNameOfBank = selectedVariables['contactNameOfBank']
            contactNumberOfBank = selectedVariables['contactNumberOfBank']
            bankCtry = selectedVariables['bankCtry']
            sortCode = selectedVariables['sortCode']
            reEnterSwiftBICNumber = selectedVariables['reEnterSwiftBICNumber']
            reEnterIBANNumber = selectedVariables['reEnterIBANNumber']
            reEnterbankAccountNumber = selectedVariables['reEnterbankAccountNumber']
            id = selectedVariables['id']
            purchaseOrganization = selectedVariables['purchaseOrganization']
            orderCurency = selectedVariables['orderCurency']
            reconAccount = selectedVariables['reconAccount']
            schemaGroup = selectedVariables['schemaGroup']
            autorizationGroup = selectedVariables['autorizationGroup']
            corporateGroup = selectedVariables['corporateGroup']
            incoterms = selectedVariables['incoterms']
            incotermsLocation1 = selectedVariables['incotermsLocation1']
            minorityIndicator = selectedVariables['minorityIndicator']
            mobileNumber = selectedVariables['mobileNumber']
            email = selectedVariables['email']
            paymentMethod2 = selectedVariables['paymentMethod2']
            otherOttachmentsDocument = selectedVariables['otherOttachmentsDocument']
            ssiBPCondition = selectedVariables['ssiBPCondition']
            ssiCerWithEx = selectedVariables['ssiCerWithEx']
            caCerWithEx = selectedVariables['caCerWithEx']
            selfDecCerWithEx = selectedVariables['selfDecCerWithEx']
            sezCondition = selectedVariables['sezCondition']
            sezCerWithEx = selectedVariables['sezCerWithEx']
            sezValueFrom = selectedVariables['sezValueFrom']
            sezValueUpto = selectedVariables['sezValueUpto']
            reverseChargeCondition = selectedVariables['reverseChargeCondition']
            rptStatus = selectedVariables['rptStatus']
            relatedEmployeeCode = selectedVariables['relatedEmployeeCode']
            relatedName = selectedVariables['relatedName']
            relatedDesignation = selectedVariables['relatedDesignation']
            relatedJoiningDate = selectedVariables['relatedJoiningDate']
            relatedToDRLLab = selectedVariables['relatedToDRLLab']
            consentFormWithEx = selectedVariables['consentFormWithEx']
            applicability1099Condition = selectedVariables['applicability1099Condition']
            poBox = selectedVariables['poBox']
            postalCodePoBox = selectedVariables['postalCodePoBox']
            nationalProviderIdentifier = selectedVariables['nationalProviderIdentifier']
            stateLicenseNumber = selectedVariables['stateLicenseNumber']
            nameOfStateInLicense = selectedVariables['nameOfStateInLicense']
            hcpOrHCOCondition = selectedVariables['hcpOrHCOCondition']
            companyCode2Series = selectedVariables['companyCode2Series']
            paymentTerms2Series = selectedVariables['paymentTerms2Series']
            paymentMethod2Series = selectedVariables['paymentMethod2Series']
            comment = selectedVariables['comment']
            companyCode3s = selectedVariables['companyCode3s']
            paymentMethod3s = selectedVariables['paymentMethod3s']
            companyCode4s = selectedVariables['companyCode4s']
            paymentMethod4s = selectedVariables['paymentMethod4s']
            companyCode5s = selectedVariables['companyCode5s']
            paymentMethod5s = selectedVariables['paymentMethod5s']
            companyCode1010 = selectedVariables['companyCode1010']
            companyCode3028 = selectedVariables['companyCode3028']
            materialSupplierType = selectedVariables['materialSupplierType']
            importPartnerType = selectedVariables['importPartnerType']
            NoSSI = selectedVariables['NoSSI']
            paymentMethod3028 = selectedVariables['paymentMethod3028']
            ediCustomerTypeCondition = selectedVariables['ediCustomerTypeCondition']
            locationCode = selectedVariables['locationCode']
            foodLicenseNumber = selectedVariables['foodLicenseNumber']
            foodLicenseValidFrom = selectedVariables['foodLicenseValidFrom']
            customerVATStatus = selectedVariables['customerVATStatus']
            drugLicense = selectedVariables['drugLicense']
            drugLicenseNumber20B = selectedVariables['drugLicenseNumber20B']
            drugLicenseNumber21B = selectedVariables['drugLicenseNumber21B']
            drugLicenseValidFrom = selectedVariables['drugLicenseValidFrom']
            drugLicenseValidTo = selectedVariables['drugLicenseValidTo']
            foodLicense = selectedVariables['foodLicense']
            foodLicenseValidTo = selectedVariables['foodLicenseValidTo']
            narcoticLicenseNumber = selectedVariables['narcoticLicenseNumber']
            narcoticLicenseValidFrom = selectedVariables['narcoticLicenseValidFrom']
            validFrom = selectedVariables['validFrom']
            daLicenseNumber = selectedVariables['daLicenseNumber']
            validUpto = selectedVariables['validUpto']
            daLicenseClass = selectedVariables['daLicenseClass']
            taxIDNumber = selectedVariables['taxIDNumber']
            dUNSNumber = selectedVariables['dUNSNumber']
            accountGroup2 = selectedVariables['accountGroup2']
            l1UserName = selectedVariables['l1UserName']
            l1Password = selectedVariables['l1Password']
            taxationUserName = selectedVariables['taxationUserName']
            taxationPassword = selectedVariables['taxationPassword']
            tdsUserName = selectedVariables['tdsUserName']
            tdsPassword = selectedVariables['tdsPassword']
            gbsUsername = selectedVariables['gbsUsername']
            gbsPassword = selectedVariables['gbsPassword']
            financeUsername = selectedVariables['financeUsername']
            financePassword = selectedVariables['financePassword']
            financeSpocUsername = selectedVariables['financeSpocUsername']
            financeSpocPassword = selectedVariables['financeSpocPassword']
            financeHeadUsername = selectedVariables['financeHeadUsername']
            financeheadPassword = selectedVariables['financeheadPassword']
            genpactUsername = selectedVariables['genpactUsername']
            genpactPassword = selectedVariables['genpactPassword']
            qaUsername = selectedVariables['qaUsername']
            qaPassword = selectedVariables['qaPassword']
            naghoUsername = selectedVariables['naghoUsername']
            naghoPassword = selectedVariables['naghoPassword']
            mdmUserName = selectedVariables['mdmUserName']
            mdmPassword = selectedVariables['mdmPassword']
            bankRoutingNumber5S = selectedVariables['bankRoutingNumber5S']
            serviceSupplierType = selectedVariables['serviceSupplierType']
            companyCode3028s = selectedVariables['companyCode3028s']
            paymentMethod3028s = selectedVariables['paymentMethod3028s']
            yesSSIBPCondition = selectedVariables['yesSSIBPCondition']
            partnerEmailInvite = selectedVariables['partnerEmailInvite']
            demoEmailPassword = selectedVariables['demoEmailPassword']
            companyCodeFieldName = selectedVariables['companyCodeFieldName']
            comapanyCodeFieldValue = selectedVariables['comapanyCodeFieldValue']
            statusValue = selectedVariables['statusValue']
            statusFieldName = selectedVariables['statusFieldName']
            supplierCodeFieldName = selectedVariables['supplierCodeFieldName']
            supplierCodeFieldValue = selectedVariables['supplierCodeFieldValue']
            customerCodeFieldName = selectedVariables['customerCodeFieldName']
            customerCodeFieldValue = selectedVariables['customerCodeFieldValue']
            requestNumberFieldName = selectedVariables['requestNumberFieldName']
            requestNumberFieldValue = selectedVariables['requestNumberFieldValue']
            customerAccountGroup = selectedVariables['customerAccountGroup']
            salesOrganisation = selectedVariables['salesOrganisation']
            supplierVendorCode = selectedVariables['supplierVendorCode']
            extensionPurchaseOrg = selectedVariables['extensionPurchaseOrg']
            ext1SeriesCompCode = selectedVariables['ext1SeriesCompCode']
            ext1SeriesEmail = selectedVariables['ext1SeriesEmail']
            ext1SeriesPartnerType = selectedVariables['ext1SeriesPartnerType']
            ext1SeriesNatureOfService = selectedVariables['ext1SeriesNatureOfService']
            ext1SeriesBriefDescription = selectedVariables['ext1SeriesBriefDescription']
            ext1SeriesPaymentMethod = selectedVariables['ext1SeriesPaymentMethod']
            ext1SeriesPurchaseOrganization = selectedVariables['ext1SeriesPurchaseOrganization']
            ext1SeriesOrderCurrency = selectedVariables['ext1SeriesOrderCurrency']
            ext1SeriesReconAccount = selectedVariables['ext1SeriesReconAccount']
            ext1SeriesSchemaGroup = selectedVariables['ext1SeriesSchemaGroup']
            ext1SeriesAutorizationGroup = selectedVariables['ext1SeriesAutorizationGroup']
            ext1SeriesCorporateGroup = selectedVariables['ext1SeriesCorporateGroup']
            ext1SeriesIncoterms = selectedVariables['ext1SeriesIncoterms']
            ext1SeriesIncotermsLocation1 = selectedVariables['ext1SeriesIncotermsLocation1']
            ext1SeriesComment = selectedVariables['ext1SeriesComment']
            ext2SeriesCompCode = selectedVariables['ext2SeriesCompCode']
            ext2SeriesEmail = selectedVariables['ext2SeriesEmail']
            ext2SeriesPartnerType = selectedVariables['ext2SeriesPartnerType']
            ext2SeriesNatureOfService = selectedVariables['ext2SeriesNatureOfService']
            ext2SeriesBriefDescription = selectedVariables['ext2SeriesBriefDescription']
            ext2SeriesPaymentMethod = selectedVariables['ext2SeriesPaymentMethod']
            ext2SeriesPurchaseOrganization = selectedVariables['ext2SeriesPurchaseOrganization']
            ext2SeriesOrderCurrency = selectedVariables['ext2SeriesOrderCurrency']
            ext2SeriesReconAccount = selectedVariables['ext2SeriesReconAccount']
            ext2SeriesSchemaGroup = selectedVariables['ext2SeriesSchemaGroup']
            ext2SeriesAutorizationGroup = selectedVariables['ext2SeriesAutorizationGroup']
            ext2SeriesCorporateGroup = selectedVariables['ext2SeriesCorporateGroup']
            ext2SeriesIncoterms = selectedVariables['ext2SeriesIncoterms']
            ext2SeriesIncotermsLocation1 = selectedVariables['ext2SeriesIncotermsLocation1']
            ext2SeriesComment = selectedVariables['ext2SeriesComment']
            ext3SeriesCompCode = selectedVariables['ext3SeriesCompCode']
            ext3SeriesEmail = selectedVariables['ext3SeriesEmail']
            ext3SeriesPartnerType = selectedVariables['ext3SeriesPartnerType']
            ext3SeriesNatureOfService = selectedVariables['ext3SeriesNatureOfService']
            ext3SeriesBriefDescription = selectedVariables['ext3SeriesBriefDescription']
            ext3SeriesPaymentMethod = selectedVariables['ext3SeriesPaymentMethod']
            ext3SeriesPurchaseOrganization = selectedVariables['ext3SeriesPurchaseOrganization']
            ext3SeriesOrderCurrency = selectedVariables['ext3SeriesOrderCurrency']
            ext3SeriesReconAccount = selectedVariables['ext3SeriesReconAccount']
            ext3SeriesSchemaGroup = selectedVariables['ext3SeriesSchemaGroup']
            ext3SeriesAutorizationGroup = selectedVariables['ext3SeriesAutorizationGroup']
            ext3SeriesCorporateGroup = selectedVariables['ext3SeriesCorporateGroup']
            ext3SeriesIncoterms = selectedVariables['ext3SeriesIncoterms']
            ext3SeriesIncotermsLocation1 = selectedVariables['ext3SeriesIncotermsLocation1']
            ext3SeriesComment = selectedVariables['ext3SeriesComment']
            ext4SeriesCompCode = selectedVariables['ext4SeriesCompCode']
            ext4SeriesEmail = selectedVariables['ext4SeriesEmail']
            ext4SeriesPartnerType = selectedVariables['ext4SeriesPartnerType']
            ext4SeriesNatureOfService = selectedVariables['ext4SeriesNatureOfService']
            ext4SeriesBriefDescription = selectedVariables['ext4SeriesBriefDescription']
            ext4SeriesPaymentMethod = selectedVariables['ext4SeriesPaymentMethod']
            ext4SeriesPurchaseOrganization = selectedVariables['ext4SeriesPurchaseOrganization']
            ext4SeriesOrderCurrency = selectedVariables['ext4SeriesOrderCurrency']
            ext4SeriesReconAccount = selectedVariables['ext4SeriesReconAccount']
            ext4SeriesSchemaGroup = selectedVariables['ext4SeriesSchemaGroup']
            ext4SeriesAutorizationGroup = selectedVariables['ext4SeriesAutorizationGroup']
            ext4SeriesCorporateGroup = selectedVariables['ext4SeriesCorporateGroup']
            ext4SeriesIncoterms = selectedVariables['ext4SeriesIncoterms']
            ext4SeriesIncotermsLocation1 = selectedVariables['ext4SeriesIncotermsLocation1']
            ext4SeriesComment = selectedVariables['ext4SeriesComment']
            ext5SeriesCompCode = selectedVariables['ext5SeriesCompCode']
            ext5SeriesEmail = selectedVariables['ext5SeriesEmail']
            ext5SeriesPartnerType = selectedVariables['ext5SeriesPartnerType']
            ext5SeriesNatureOfService = selectedVariables['ext5SeriesNatureOfService']
            ext5SeriesBriefDescription = selectedVariables['ext5SeriesBriefDescription']
            ext5SeriesPaymentMethod = selectedVariables['ext5SeriesPaymentMethod']
            ext5SeriesPurchaseOrganization = selectedVariables['ext5SeriesPurchaseOrganization']
            ext5SeriesOrderCurrency = selectedVariables['ext5SeriesOrderCurrency']
            ext5SeriesReconAccount = selectedVariables['ext5SeriesReconAccount']
            ext5SeriesSchemaGroup = selectedVariables['ext5SeriesSchemaGroup']
            ext5SeriesAutorizationGroup = selectedVariables['ext5SeriesAutorizationGroup']
            ext5SeriesCorporateGroup = selectedVariables['ext5SeriesCorporateGroup']
            ext5SeriesIncoterms = selectedVariables['ext5SeriesIncoterms']
            ext5SeriesIncotermsLocation1 = selectedVariables['ext5SeriesIncotermsLocation1']
            ext5SeriesComment = selectedVariables['ext5SeriesComment']
            ext3028SeriesCompCode = selectedVariables['ext3028SeriesCompCode']
            ext3028SeriesEmail = selectedVariables['ext3028SeriesEmail']
            ext3028SeriesPartnerType = selectedVariables['ext3028SeriesPartnerType']
            ext3028SeriesNatureOfService = selectedVariables['ext3028SeriesNatureOfService']
            ext3028SeriesBriefDescription = selectedVariables['ext3028SeriesBriefDescription']
            ext3028SeriesPaymentMethod = selectedVariables['ext3028SeriesPaymentMethod']
            ext3028SeriesPurchaseOrganization = selectedVariables['ext3028SeriesPurchaseOrganization']
            ext3028SeriesOrderCurrency = selectedVariables['ext3028SeriesOrderCurrency']
            ext3028SeriesReconAccount = selectedVariables['ext3028SeriesReconAccount']
            ext3028SeriesSchemaGroup = selectedVariables['ext3028SeriesSchemaGroup']
            ext3028SeriesAutorizationGroup = selectedVariables['ext3028SeriesAutorizationGroup']
            ext3028SeriesCorporateGroup = selectedVariables['ext3028SeriesCorporateGroup']
            ext3028SeriesIncoterms = selectedVariables['ext3028SeriesIncoterms']
            ext3028SeriesIncotermsLocation1 = selectedVariables['ext3028SeriesIncotermsLocation1']
            ext3028SeriesComment = selectedVariables['ext3028SeriesComment']
            
        } catch (Exception e) {
            TestCaseMain.logGlobalVariableError(e)
        }
    }
}
