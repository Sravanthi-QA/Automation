
/**
 * This class is generated automatically by Katalon Studio and should not be modified or deleted.
 */

import java.lang.String

import com.kms.katalon.core.testobject.TestObject

import java.util.HashMap

import com.applitools.eyes.selenium.Eyes

import org.openqa.selenium.WebElement

import com.applitools.eyes.RectangleSize


 /**
	 * @author Vadisa Subramanyam
	 * @description : This method is used to log in as initiator.
	 * @param userName : userName is string value that  user id of initiator
	 * @param password : password is string value that password of initiator
	 */ 
def static "pages.LoginPage.employeeSignin"(
    	String userName	
     , 	String password	) {
    (new pages.LoginPage()).employeeSignin(
        	userName
         , 	password)
}

 /**
	 * @author Vadisa Subramanyam
	 * @description : Method to click on add new partner partner button.
	 */ 
def static "pages.SearchPage.clickOnAddNewPartnerButton"() {
    (new pages.SearchPage()).clickOnAddNewPartnerButton()
}

 /**
	 * @author Vadisa Subramanyam
	 * @description : Method to click on find partner button.
	 */ 
def static "pages.AdminHomePage.clickOnFindPartnerButton"() {
    (new pages.AdminHomePage()).clickOnFindPartnerButton()
}

 /**
	 * @author Vadisa Subramanyam
	 * @description : Method to open approval portal by L1 using request ID.
	 * @param requestID : requestID is string value that request id.
	 */ 
def static "pages.AdminHomePage.openApprovalPortalByL1UsingRequestID"(
    	String requestID	) {
    (new pages.AdminHomePage()).openApprovalPortalByL1UsingRequestID(
        	requestID)
}

 /**
	 * @author Vadisa Subramanyam
	 * @description : Method to click on find partner button.
	 */ 
def static "pages.AdminHomePage.getTextByColumnName"() {
    (new pages.AdminHomePage()).getTextByColumnName()
}


def static "utilities.OTPRetrieval.buildApiRequestForOTP"(
    	String emailId	) {
    (new utilities.OTPRetrieval()).buildApiRequestForOTP(
        	emailId)
}

 /**
	 * @author Vadisa Subramanyam
	 * @description : This method is used to refresh browser
	 */ 
def static "commonKeywords.ApplicationKeywords.refreshBrowser"() {
    (new commonKeywords.ApplicationKeywords()).refreshBrowser()
}

 /**
	 * @author : Vadisa Subramanyam
	 * @description : Method to click element
	 * @param to : 'to' is Katalon test object
	 */ 
def static "commonKeywords.ApplicationKeywords.clickElement"(
    	TestObject to	) {
    (new commonKeywords.ApplicationKeywords()).clickElement(
        	to)
}

 /**
	 * @author Vadisa Subramanyam
	 * @descrption : Method to get all rows of HTML table
	 * @param : table Katalon test object represent for HTML table
	 * @param  : xpathValue outer tag name of TR tag, usually is TBODY
	 * @return : All rows inside HTML table
	 */ 
def static "commonKeywords.ApplicationKeywords.getHtmlTableRows"(
    	TestObject table	
     , 	String xpathValue	) {
    (new commonKeywords.ApplicationKeywords()).getHtmlTableRows(
        	table
         , 	xpathValue)
}

 /**
	 * @author Vadisa Subramanyam
	 * @descrption : Method to verify element is displayed or not.
	 * @param testObjectElement : testObjectElement is object that need to perform actions.
	 * @return flag : flag returns true if element is displayed and false if element is not displayed
	 */ 
def static "commonKeywords.ApplicationKeywords.isDisplayed"(
    	TestObject testObjectElement	) {
    (new commonKeywords.ApplicationKeywords()).isDisplayed(
        	testObjectElement)
}

 /**
	 * @author Vadisa Subramanyam
	 * @descrption : Method to verify element is not editable.
	 * @param testObjectElement : testObjectElement is object that need to perform actions.
	 * @return flag : flag returns true if element is displayed and false if element is not displayed
	 */ 
def static "commonKeywords.ApplicationKeywords.verifyElementIsNotEditable"(
    	TestObject testObjectElement	) {
    (new commonKeywords.ApplicationKeywords()).verifyElementIsNotEditable(
        	testObjectElement)
}

 /**
	 * @author Vadisa Subramanyam
	 * @descrption : Method to verify element is enabled
	 * @param testObjectElement : testObjectElement is object that need to perform actions.
	 * @return flag : flag returns true if element is displayed and false if element is not enabled
	 */ 
def static "commonKeywords.ApplicationKeywords.isEnabled"(
    	TestObject testObjectElement	) {
    (new commonKeywords.ApplicationKeywords()).isEnabled(
        	testObjectElement)
}

 /**
	 * @author Vadisa Subramanyam
	 * @descrption : Method to verify element is present
	 * @param testObjectElement : testObjectElement is object that need to perform actions.
	 * @return flag : flag returns true if element is displayed and false if element is not present
	 */ 
def static "commonKeywords.ApplicationKeywords.isPresent"(
    	TestObject testObjectElement	) {
    (new commonKeywords.ApplicationKeywords()).isPresent(
        	testObjectElement)
}

 /**
	 * @author Vadisa Subramanyam
	 * @descrption : Method to clear text field.
	 * @param testObjectElement : testObjectElement is object that need to perform actions.
	 * @return flag : flag returns true if element is displayed and false if element is cleared text.
	 */ 
def static "commonKeywords.ApplicationKeywords.clearTextField"(
    	TestObject testObjectElement	) {
    (new commonKeywords.ApplicationKeywords()).clearTextField(
        	testObjectElement)
}

 /**
	 * @author Vadisa Subramanyam
	 * @description : Method to fill SAP Business registration form.
	 * @param data : data is set that contains data to fill in registration form.
	 */ 
def static "pages.BusinessPartnerOnboardingPage.fillSAPBusinessRegistrationFormForSupplierOnboarding"(
    	String companyCode	
     , 	java.util.HashMap<String, String> data	) {
    (new pages.BusinessPartnerOnboardingPage()).fillSAPBusinessRegistrationFormForSupplierOnboarding(
        	companyCode
         , 	data)
}

 /**
	 * @author Vadisa Subramanyam
	 * @description : Method to fill SAP Business registration form to invite partner.
	 * @param data : data is set that contains data to fill in registration form to invite supplier.
	 */ 
def static "pages.BusinessPartnerOnboardingPage.fillSAPBusinessRegistrationFormToInviteSupplier"(
    	String companyCode	
     , 	java.util.HashMap<String, String> data	) {
    (new pages.BusinessPartnerOnboardingPage()).fillSAPBusinessRegistrationFormToInviteSupplier(
        	companyCode
         , 	data)
}

 /**
	 * @author Vadisa Subramanyam
	 * @description : Method to fill third party risk management.
	 * @param data : data is set that contains data to fill in third part risk management.
	 */ 
def static "pages.BusinessPartnerOnboardingPage.fillThirdPartyRiskManagement"(
    	java.util.HashMap<String, String> data	) {
    (new pages.BusinessPartnerOnboardingPage()).fillThirdPartyRiskManagement(
        	data)
}

 /**
	 * @author Vadisa Subramanyam
	 * @description : Method to click on invite partner button
	 */ 
def static "pages.BusinessPartnerOnboardingPage.clickOnInvitePartner"() {
    (new pages.BusinessPartnerOnboardingPage()).clickOnInvitePartner()
}

 /**
	 * @author Vadisa Subramanyam
	 * @description : Method to click on proceed button
	 */ 
def static "pages.BusinessPartnerOnboardingPage.clickOnProceedButton"(
    	String companyCode	) {
    (new pages.BusinessPartnerOnboardingPage()).clickOnProceedButton(
        	companyCode)
}

 /**
	 * @author Vadisa Subramanyam
	 * @description : Method to get request number.
	 */ 
def static "pages.BusinessPartnerOnboardingPage.getRequestNumber"() {
    (new pages.BusinessPartnerOnboardingPage()).getRequestNumber()
}

 /**
	 * @author Vadisa Subramanyam
	 * @description : Method to fill SAP Business registration.
	 * @param data : data is set that contains data to fill in address.
	 */ 
def static "pages.BusinessPartnerOnboardingPage.fillSAPBusinessRegistrationFormAsSupplier"(
    	String companyCode	
     , 	java.util.HashMap<String, String> data	) {
    (new pages.BusinessPartnerOnboardingPage()).fillSAPBusinessRegistrationFormAsSupplier(
        	companyCode
         , 	data)
}

 /**
	 * @author Vadisa Subramanyam
	 * @description : Method to fill address in on-boarding form.
	 * @param data : data is set that contains data to fill in address.
	 * @param companyCode : companyCode is string value that selected company code while creation.
	 */ 
def static "pages.BusinessPartnerOnboardingPage.fillAddress"(
    	String companyCode	
     , 	java.util.HashMap<String, String> data	) {
    (new pages.BusinessPartnerOnboardingPage()).fillAddress(
        	companyCode
         , 	data)
}

 /**
	 * @author Vadisa Subramanyam
	 * @description : Method to uplaod file.
	 * @param fileLocation : fileLocation is string value that location of file.
	 */ 
def static "pages.BusinessPartnerOnboardingPage.uploadFile"(
    	String fileLocation	) {
    (new pages.BusinessPartnerOnboardingPage()).uploadFile(
        	fileLocation)
}

 /**
	 * @author Vadisa Subramanyam
	 * @description : Method to add tax details.
	 * @param data : data is set that contains data to add tax details.
	 * @param taxDocWithExtension : taxDocWithExtension is String value that tax doc file name with extension.
	 */ 
def static "pages.BusinessPartnerOnboardingPage.addBankDetails"(
    	java.util.HashMap<String, String> data	
     , 	String taxDocWithExtension	) {
    (new pages.BusinessPartnerOnboardingPage()).addBankDetails(
        	data
         , 	taxDocWithExtension)
}

 /**
	 * @author Vadisa Subramanyam
	 * @description : Method to fill address in on-boarding form.
	 * @param companyCode : companyCode is string value that selected company code while creation.
	 * @param data : data is set that contains data to fill tax details.
	 * @param gstCertificateNameWithExtension : gstCertificateNameWithExtension is String value that gst certificate file name with extension.
	 * @param pancardFileNameWithExtension : pancardFileNameWithExtension is String value that pan card file name with extension.
	 * @param taxDocWithExtension : taxDocWithExtension is String value that tax doc file name with extension.
	 */ 
def static "pages.BusinessPartnerOnboardingPage.fillTaxDetails"(
    	String companyCode	
     , 	java.util.HashMap<String, String> data	
     , 	String gstCertificateNameWithExtension	
     , 	String pancardFileNameWithExtension	
     , 	String taxDocWithExtension	) {
    (new pages.BusinessPartnerOnboardingPage()).fillTaxDetails(
        	companyCode
         , 	data
         , 	gstCertificateNameWithExtension
         , 	pancardFileNameWithExtension
         , 	taxDocWithExtension)
}

 /**
	 * @author Vadisa Subramanyam
	 * @description : Method to click on purchase organization.
	 * @param purOrganization : purOrganization is string value that name of purchase organization.
	 */ 
def static "pages.BusinessPartnerOnboardingPage.clickOnPurchaseOrganization"(
    	String purOrganization	) {
    (new pages.BusinessPartnerOnboardingPage()).clickOnPurchaseOrganization(
        	purOrganization)
}


def static "com.testwithhari.katalon.plugins.Gmail.readLatestEMailBodyContent"(
    	String emailID	
     , 	String password	
     , 	String folderLableName	) {
    (new com.testwithhari.katalon.plugins.Gmail()).readLatestEMailBodyContent(
        	emailID
         , 	password
         , 	folderLableName)
}


def static "com.testwithhari.katalon.plugins.Gmail.deleteAllEMails"(
    	String emailID	
     , 	String password	
     , 	String folderLableName	) {
    (new com.testwithhari.katalon.plugins.Gmail()).deleteAllEMails(
        	emailID
         , 	password
         , 	folderLableName)
}


def static "com.testwithhari.katalon.plugins.Gmail.sendEmail"(
    	String from_emailaddress	
     , 	String email_password	
     , 	String to_emailaddress	
     , 	String email_subject	
     , 	String email_body	) {
    (new com.testwithhari.katalon.plugins.Gmail()).sendEmail(
        	from_emailaddress
         , 	email_password
         , 	to_emailaddress
         , 	email_subject
         , 	email_body)
}


def static "com.testwithhari.katalon.plugins.Gmail.getEmailsCount"(
    	String emailID	
     , 	String password	
     , 	String folderLableName	) {
    (new com.testwithhari.katalon.plugins.Gmail()).getEmailsCount(
        	emailID
         , 	password
         , 	folderLableName)
}


def static "com.kms.katalon.keyword.applitools.BasicKeywords.checkElement"(
    	Eyes eyes	
     , 	WebElement element	) {
    (new com.kms.katalon.keyword.applitools.BasicKeywords()).checkElement(
        	eyes
         , 	element)
}


def static "com.kms.katalon.keyword.applitools.BasicKeywords.checkTestObject"(
    	TestObject testObject	
     , 	String testName	) {
    (new com.kms.katalon.keyword.applitools.BasicKeywords()).checkTestObject(
        	testObject
         , 	testName)
}


def static "com.kms.katalon.keyword.applitools.BasicKeywords.checkWindow"(
    	String testName	) {
    (new com.kms.katalon.keyword.applitools.BasicKeywords()).checkWindow(
        	testName)
}


def static "com.kms.katalon.keyword.applitools.EyesKeywords.eyesOpen"(
    	String testName	
     , 	RectangleSize viewportSize	) {
    (new com.kms.katalon.keyword.applitools.EyesKeywords()).eyesOpen(
        	testName
         , 	viewportSize)
}


def static "com.kms.katalon.keyword.applitools.EyesKeywords.eyesClose"(
    	Eyes eyes	) {
    (new com.kms.katalon.keyword.applitools.EyesKeywords()).eyesClose(
        	eyes)
}


def static "com.kms.katalon.keyword.applitools.EyesKeywords.eyesInit"() {
    (new com.kms.katalon.keyword.applitools.EyesKeywords()).eyesInit()
}


def static "com.kms.katalon.keyword.applitools.EyesKeywords.eyesOpenWithBaseline"(
    	String baselineName	
     , 	String testName	
     , 	RectangleSize viewportSize	) {
    (new com.kms.katalon.keyword.applitools.EyesKeywords()).eyesOpenWithBaseline(
        	baselineName
         , 	testName
         , 	viewportSize)
}
