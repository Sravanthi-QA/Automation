package flightaware
import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.checkpoint.Checkpoint
import com.kms.katalon.core.checkpoint.CheckpointFactory
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testcase.TestCase
import com.kms.katalon.core.testcase.TestCaseFactory
import com.kms.katalon.core.testdata.TestData
import com.kms.katalon.core.testdata.TestDataFactory
import com.kms.katalon.core.testobject.ObjectRepository
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

import internal.GlobalVariable

import org.openqa.selenium.WebElement
import org.openqa.selenium.WebDriver
import org.openqa.selenium.By

import com.kms.katalon.core.mobile.keyword.internal.MobileDriverFactory
import com.kms.katalon.core.webui.driver.DriverFactory
import com.kms.katalon.core.util.KeywordUtil
import com.kms.katalon.core.testobject.RequestObject
import com.kms.katalon.core.testobject.ResponseObject
import com.kms.katalon.core.testobject.ConditionType
import com.kms.katalon.core.testobject.TestObjectProperty
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.helper.MobileElementCommonHelper
import com.kms.katalon.core.util.KeywordUtil

import com.kms.katalon.core.webui.exception.WebElementNotFoundException

import com.kms.katalon.core.webui.keyword.internal.WebUIAbstractKeyword
import cucumber.api.java.en.And
import cucumber.api.java.en.Given
import cucumber.api.java.en.Then
import cucumber.api.java.en.When



class Flightaware {
	static String Place='BANGALORE'


	@Given("user is in flightaware landing page")
	def NavigationtoFlightawareLandingPage() {
		WebUI.openBrowser('https://flightaware.com/')
		WebUI.maximizeWindow()
	}

	@When("user search for any place")
	def Search() {
		WebUI.setText(findTestObject('Object Repository/Flightaware/Search_text'), Place)
		WebUI.delay(5)
		WebUI.click(findTestObject('Object Repository/Flightaware/Search_options'))
	}

	@Then("user should see searched result")
	def SearchedResult() {

		String SearchedResult=WebUI.getText(findTestObject('Object Repository/Flightaware/SearchedResult_title'))
		if(SearchedResult.contains(Place)) {
			KeywordUtil.markPassed('Searched result is displayed :' +SearchedResult)
		}
		else {
			KeywordUtil.markFailed('Searched result is not displayed')
		}
	}

	@Given("user searched for a place and is in flight tracker page")
	def FlightTrackerPage() {
		CucumberKW.runFeatureFileWithTags('Include/features/Flightaware/Flightaware.feature', '@Verify_Search')
	}
	@When("user want to check any flight arrival details")
	def Check_FlightArrival() {
		WebUI.scrollToElement(findTestObject('Object Repository/Flightaware/Arrival_text'), 0)

	}
	@And("user click on any ident link under arrivals")
	def public static Identlink() {
		List<WebElement> ArrivalList=WebUIAbstractKeyword.findWebElements(findTestObject('Object Repository/Flightaware/ArrivalsList'), 2)
		int list=ArrivalList.size()
		println list
		for(int i=1;i<list;i++) {
			Object obj =new TestObject()
			obj.addProperty("xpath", ConditionType.EQUALS, "((//tbody)[1]/tr/td[@class=' flight-ident'])["+i+"]")
			WebUI.verifyElementVisible(obj, FailureHandling.STOP_ON_FAILURE)
			String Linkname=WebUI.getText(obj)
			println Linkname
			WebUI.click(obj)
			break;

		}
	}
	@Then("user should see destination place matching with searched place")
	def FlightDetails() {


		String Identtext=WebUI.getText(findTestObject('Object Repository/Flightaware/Ident_text'))
		println Identtext
		String Destination=WebUI.getText(findTestObject('Object Repository/Flightaware/Destination'))
		println Destination
		if(Destination.contains(Place)) {
			KeywordUtil.markPassed('Destination place is matching with searched place :: PASSED')
		}
		else {
			KeywordUtil.markFailed('Destination place is not matching with searched place :: FAILED')
		}
			

	}
}

