<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>SearchedResult_title</name>
   <tag></tag>
   <elementGuidId>75a185b6-b7de-42ae-8d64-fe661cc0c4ae</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//h1[contains(@class,'mainHeader airportTrackerTitle airportTrackerTitleText')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//h1[contains(@class,'mainHeader airportTrackerTitle airportTrackerTitleText')]</value>
   </webElementProperties>
</WebElementEntity>
