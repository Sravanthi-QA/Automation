<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Arrival_text</name>
   <tag></tag>
   <elementGuidId>31ee9d73-5158-4a42-8f5e-afb39f06c238</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//h2[contains(text(),'Arrivals')] </value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//h2[contains(text(),'Arrivals')] </value>
   </webElementProperties>
</WebElementEntity>
